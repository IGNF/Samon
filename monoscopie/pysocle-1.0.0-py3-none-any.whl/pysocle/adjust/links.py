import sys
import time
import warnings
from pathlib import Path

import pandas as pd
from osgeo import ogr, osr

# Import PySocle
from pysocle.photogrammetry.ta import Ta


def create_links(path_ori, dir_out, dir_mes, opt={}, callback=None):
    ogr_driver = opt.get("OGR_DRIVER", "GPKG")
    dir_out, dir_mes = Path(dir_out), Path(dir_mes)
    drv = ogr.GetDriverByName(ogr_driver)
    path_links = dir_out.joinpath("links").with_suffix("." + drv.GetMetadata()['DMD_EXTENSION'])
    path_visi = dir_out.joinpath("visibility").with_suffix("." + drv.GetMetadata()['DMD_EXTENSION'])

    # Lecture du fichier d'orientation
    ta = Ta.from_file(path_ori, calib_cam=False, path_dem=None, opt=opt, callback=callback)
    dest_srs = osr.SpatialReference()
    dest_srs.ImportFromWkt(ta.project.proj_engine.crs.to_wkt())

    if callback is not None:
        callback("Chargement des données MES ...", 0)
    df_mes = pd.DataFrame([], columns=["pnt", "img"])
    for file in dir_mes.glob("*"):
        if file.suffix.lower() == ".mes":
            df_mes = df_mes.append(pd.read_csv(str(file), sep="\s+", names=["pnt", "img"],
                                               converters={"pnt": str, "img": str},
                                               usecols=[0,1], nrows=100000,
                                               skiprows=1))

    if callback is not None:
        callback("Calcul des liaisons ...", 0)

    df_mes["strip"] = df_mes["img"].apply(lambda x: int(x.split("_")[0].split("x")[1] if "x" in x else x.split("_")[0]))
    df_mes = df_mes.merge(df_mes, on="pnt", suffixes=("_1", "_2"), copy=False)
    df_mes = df_mes[df_mes["img_1"] < df_mes["img_2"]]
    df_mes = df_mes.groupby(["img_1", "img_2", "strip_1", "strip_2"], as_index=False).count()
    df_visi = df_mes.groupby(["img_1"])["pnt"].count().rename("seen_img")
    df_visi_strip = df_mes.groupby(["img_1"])["strip_2"].nunique().rename("seen_strip")
    df_visi_in_strip = df_mes[df_mes["strip_1"] == df_mes["strip_2"]].groupby(["img_1"])["pnt"].count().rename("in_strip")
    df_visi_other_strip = df_mes[df_mes["strip_1"] != df_mes["strip_2"]].groupby(["img_1"])["pnt"].count().rename("other_strip")
    df_visi = pd.concat([df_visi, df_visi_strip, df_visi_in_strip, df_visi_other_strip], axis=1)

    # Creation du shp
    memdriver = ogr.GetDriverByName('MEMORY')
    data_source = memdriver.CreateDataSource('memData')
    # Creation du layer
    layer = data_source.CreateLayer("Links", dest_srs, ogr.wkbLineString)
    # Creation des champs du shp
    field_name = ogr.FieldDefn("Img1", ogr.OFTString)
    field_name.SetWidth(24)
    layer.CreateField(field_name)
    field_name2 = ogr.FieldDefn("Img2", ogr.OFTString)
    field_name2.SetWidth(24)
    layer.CreateField(field_name2)
    layer.CreateField(ogr.FieldDefn("links", ogr.OFTInteger))
    nbr_links = len(df_mes)
    for index, (_, val) in enumerate(df_mes.iterrows()):
        if callback is not None:
            callback(f"Creation fichier links",  index/nbr_links)
        img1 = ta.project.find_shot(val["img_1"])
        img2 = ta.project.find_shot(val["img_2"])
        links = val["pnt"]
        if img1 is None:
            continue
        if img2 is None:
            continue
        # Creation de la feature et geometrie
        feature = ogr.Feature(layer.GetLayerDefn())
        feature.SetField("Img1", img1.image)
        feature.SetField("Img2", img2.image)
        feature.SetField("links", links)
        line = ogr.Geometry(ogr.wkbLineString)
        line.AddPoint(img1.imc.x_pos, img1.imc.y_pos)
        line.AddPoint(img2.imc.x_pos, img2.imc.y_pos)
        feature.SetGeometry(line)
        layer.CreateFeature(feature)
        feature = None
    drv.CopyDataSource(data_source, str(path_links))

    #Creation graphe de visibilité
    memdriver = ogr.GetDriverByName('MEMORY')
    data_source = memdriver.CreateDataSource('memData')
    layer = data_source.CreateLayer("Visibility", dest_srs, ogr.wkbPoint)
    field_name = ogr.FieldDefn("Img", ogr.OFTString)
    field_name.SetWidth(24)
    layer.CreateField(field_name)
    layer.CreateField(ogr.FieldDefn("SeenImg", ogr.OFTInteger))
    layer.CreateField(ogr.FieldDefn("SeenStrip", ogr.OFTInteger))
    layer.CreateField(ogr.FieldDefn("InStrip", ogr.OFTInteger))
    layer.CreateField(ogr.FieldDefn("OtherStrip", ogr.OFTInteger))
    nbr_shot = ta.project.nbr_shot()
    for ind_shot, shot in enumerate(ta.project.get_shots()):
        # Creation de la feature et géométrie
        if callback is not None:
            callback(f"Creation fichier visibility", ind_shot/nbr_shot)
        try:
            seen_shot, seen_strip, seen_shot_in_strip, seen_shot_other_strip = df_visi.loc[shot.image]
        except KeyError:
            seen_shot, seen_strip, seen_shot_in_strip, seen_shot_other_strip = 0, 0, 0, 0

        feature = ogr.Feature(layer.GetLayerDefn())
        feature.SetField("Img", shot.image)
        feature.SetField("SeenImg", seen_shot)
        feature.SetField("SeenStrip", seen_strip)
        feature.SetField("InStrip", seen_shot_in_strip)
        feature.SetField("OtherStrip", seen_shot_other_strip)
        point = ogr.Geometry(ogr.wkbPoint)
        point.AddPoint(shot.imc.x_pos, shot.imc.y_pos)
        feature.SetGeometry(point)
        layer.CreateFeature(feature)
        feature = None
    drv.CopyDataSource(data_source, str(path_visi))

def create_links_gpd(path_ori, dir_out, dir_mes, opt={}, callback=None):
    from shapely.geometry import Point, LineString
    import geopandas as gpd
    from shapely.errors import ShapelyDeprecationWarning

    ogr_driver = opt.get("OGR_DRIVER", "GPKG")
    drv = ogr.GetDriverByName(ogr_driver)
    dir_out, dir_mes = Path(dir_out), Path(dir_mes)
    path_links = dir_out.joinpath("links1").with_suffix("." + drv.GetMetadata()['DMD_EXTENSION'])
    path_visi = dir_out.joinpath("visibility1").with_suffix("." + drv.GetMetadata()['DMD_EXTENSION'])

    # Lecture du fichier d'orientation
    ta = Ta.from_file(path_ori, calib_cam=False, path_dem=None, opt=opt, callback=callback)
    dest_srs = osr.SpatialReference()
    dest_srs.ImportFromWkt(ta.project.proj_engine.crs.to_wkt())

    # Lecture du fichier d'orientation
    data = {"img": [shot.image for shot in ta.project.get_shots()],
            "geometry": [Point(shot.imc.x_pos, shot.imc.y_pos) for shot in ta.project.get_shots()]}
    gdf_img = gpd.GeoDataFrame(data, crs=ta.project.proj_engine.crs.to_wkt()).set_index("img")

    if callback is not None:
        callback("Chargement des données MES ...", 0)
    # Chargement des données MES
    df_mes = gpd.GeoDataFrame([], columns=["pnt", "img"])
    for file in dir_mes.glob("*"):
        if file.suffix.lower() == ".mes":
            df_mes = df_mes.append(
                pd.read_csv(str(file), sep="\s+", names=["pnt", "img"], converters={"pnt": str, "img": str},
                            usecols=[0, 1], nrows=100000, skiprows=1))
    df_mes["strip"] = df_mes["img"].apply(lambda x: int(x.split("_")[0].split("x")[1] if "x" in x else x.split("_")[0]))

    # Calcul des liaisons
    print("Calcul des liaisons ...")
    df_mes = df_mes.merge(df_mes, on="pnt", suffixes=("_1", "_2"), copy=False)
    df_mes = df_mes[df_mes["img_1"] < df_mes["img_2"]]
    df_mes = df_mes.groupby(["img_1", "img_2", "strip_1", "strip_2"], as_index=False).count() \
        .merge(gdf_img, left_on="img_1", right_on="img").merge(gdf_img, left_on="img_2", right_on="img")

    # Creation des linestrings
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=ShapelyDeprecationWarning)
        df_mes["geometry"] = df_mes.apply(lambda row: LineString([row['geometry_x'], row['geometry_y']]), axis=1)

    # Sauvegarde du diagramme de liens
    df_mes.set_geometry("geometry") \
        .set_crs(ta.project.proj_engine.crs.to_wkt()) \
        .drop(["geometry_x", "geometry_y", "strip_1", "strip_2"], axis=1) \
        .to_file(path_links, OVERWRITE="YES")

    # Calcul des indicateurs de visibilité
    df_visi = df_mes.groupby(["img_1"])["pnt"].count().rename("seen_img")
    df_visi_strip = df_mes.groupby(["img_1"])["strip_2"].nunique().rename("seen_strip")
    df_visi_in_strip = df_mes[df_mes["strip_1"] == df_mes["strip_2"]].groupby(["img_1"])["pnt"].count().rename(
        "in_strip")
    df_visi_other_strip = df_mes[df_mes["strip_1"] != df_mes["strip_2"]].groupby(["img_1"])["pnt"].count().rename(
        "other_strip")

    # Sauvegarde du diagramme de visibilité
    gdf_img.assign(seen_img=df_visi) \
        .assign(seen_strip=df_visi_strip) \
        .assign(in_strip=df_visi_in_strip) \
        .assign(other_strip=df_visi_other_strip) \
        .fillna(0) \
        .to_file(path_visi, OVERWRITE="YES")


if __name__ == "__main__":
    path_ori = r"D:\Projet_python\Pysocle_test_data\links\data\21FD1105B.OPK"
    dir_out = r"D:\Projet_python\Pysocle_test_data\links\data\test"
    dir_mes = r"D:\Projet_python\Pysocle_test_data\links\data\MES"
    opt = {"OPK_IN": "ori", "SKIPROW": 1}

    start = time.time()
    create_links(path_ori, dir_out, dir_mes, opt)
    print("end", time.time() - start)