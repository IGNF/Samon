from datetime import datetime
import numpy as np
from pysocle.photogrammetry.ta import Ta


def block_check(path_ori, list_camera, path_dem, dir_mes, path_app, dir_out, correct_atm, opt, callback):
    # Lecture du fichier d'orientation
    ta = Ta.from_file(path_ori, calib_cam=list_camera, path_dem=path_dem, opt=opt, callback=callback)

    # Passage dans un repère unique barycentrique
    if callback is not None:
        callback("Passage dans le repère barycentrique", np.nan)
    ta.project.to_system_barycentrique()

    # Chargement des coordonnées images
    if callback is not None:
        callback("Chargement des données MES ...", np.nan)

    file_mes = [file for file in dir_mes.glob("*") if file.suffix.lower() == ".mes"]
    dict_pnt = {}
    for file in file_mes:
        cont_mes = file.read_text().split("\n")
        for ind, line in enumerate(cont_mes):
            line_split = line.split()
            try:
                name_pnt = line_split[0]
                name_img = line_split[1]
                bande_img = name_img.split("_")[0]
                x = float(line_split[2])
                y = float(line_split[3])

                if correct_atm:
                    img = ta.project.find_shot(name_img)
                    H = img.imc.z_pos / 1000
                    h = (img.imc.z_pos - ta.project.dem.get(img.imc.x_pos,
                                                            img.imc.y_pos)) / 1000 if ta.project.dem is not None else 0  # hauteur au dessus du sol en km
                    K = (2410. * H / (H * H - 6. * H + 250.) - 2410. * h * h / (h * h - 6. * h + 250.) * H) * 1.e-6
                    dx = x - img.imc.camera.x_ppa
                    dy = y - img.imc.camera.y_ppa
                    r = (dx ** 2 + dy ** 2) ** 0.5
                    dr = K * (r + r ** 3 / img.imc.camera.focal ** 2)
                    x -= dx * dr / r
                    y -= dy * dr / r

                if name_pnt in dict_pnt:
                    if bande_img in dict_pnt[name_pnt]['geom_img']:
                        dict_pnt[name_pnt]['geom_img'][bande_img] += [
                            {"img": name_img, "coord_image_mes": np.array([x, y])}]
                    else:
                        dict_pnt[name_pnt]['geom_img'][bande_img] = [{"img": name_img, "coord_image_mes": np.array([x, y])}]
                else:
                    dict_pnt[name_pnt] = {"coord_terrain_mes": np.full(3, np.nan),
                                          "geom_img": {bande_img: [{"img": name_img, "coord_image_mes": np.array([x, y])}]}}
            except (IndexError, ValueError):
                print(f"Impossible de lire la ligne {ind} du fichier {file}")
                continue

    if callback is not None:
        callback("Chargement des données APP ...", np.nan)
    cont_app = path_app.read_text().split("\n")
    for ind, line in enumerate(cont_app):
        line_split = line.split()
        try:
            name = line_split[0]
            t = int(line_split[1])
            x = float(line_split[2])
            y = float(line_split[3])
            z = float(line_split[4])
            dict_pnt[name]["coord_terrain_mes"] = np.array([x, y, z])
            dict_pnt[name]["type"] = t
        except (IndexError, ValueError, KeyError):
            print(f"Impossible de lire la ligne {ind} du fichier {path_app}")

    if callback is not None:
        callback("Calcul des coordonnées images estimées des points terrains ...", np.nan)
    list_img_res = ["ID", "Img", "Col_mes", "Lig_mes", "Col_esti", "Lig_esti", "Col_mes-Col_esti ", "Lig_mes-Lig_esti"]
    for name_pnt, infos_pnt in dict_pnt.items():
        for mes_bande in infos_pnt["geom_img"].values():
            for mes in mes_bande:
                img = ta.project.find_shot(mes["img"])
                if img is None:
                    print(f"L'image {mes['img']} n'a pas d'orientation")
                    continue
                mes_image_esti = np.round(
                    img.imc.world_to_image(infos_pnt["coord_terrain_mes"][0], infos_pnt["coord_terrain_mes"][1],
                                           infos_pnt["coord_terrain_mes"][2]), 2)
                res_image_esti = mes['coord_image_mes'] - mes_image_esti
                list_img_res += ["\n" + name_pnt, mes['img'], f"{mes['coord_image_mes'][0]:.3f}",
                                 f"{mes['coord_image_mes'][1]:.3f}", f"{mes_image_esti[0]:.3f}", f"{mes_image_esti[1]:.3f}",
                                 f"{res_image_esti[0]:.3f}", f"{res_image_esti[1]:.3f}"]

    if callback is not None:
        callback("Calcul des coordonnées terrains estimées des points images ...", 0)
    tabl_gnd_res = []
    tabl_img_res = []
    list_gnd_res = ["ID", "X", "Y", "Z", "X_esti", "Y_esti", "Z_esti", "X-X_esti", "Y-Y_esti", "Z-Z_esti", "Mes"]
    list_img_res_gnd = ["ID", "Img", "Col_mes", "Lig_mes", "Col_esti", "Lig_esti", "Col_mes-Col_esti", "Lig_mes-Lig_esti"]
    for name_pnt, infos_pnt in dict_pnt.items():
        if infos_pnt["geom_img"]:
            name_img = [mes["img"] for mes_bande in infos_pnt["geom_img"].values() for mes in mes_bande]
            c = [mes["coord_image_mes"][0] for mes_bande in infos_pnt["geom_img"].values() for mes in mes_bande]
            l = [mes["coord_image_mes"][1] for mes_bande in infos_pnt["geom_img"].values() for mes in mes_bande]
            nbr_mes = len(name_img)
            ptCoord = ta.project.compute_intersection(name_img, c, l)

            # Différence avec coord terrain
            pnt_gnd = infos_pnt['coord_terrain_mes']
            res_gnd = pnt_gnd - ptCoord

            if infos_pnt["type"] == 1 or infos_pnt["type"] == 11:
                res_gnd[0:2] = [np.nan, np.nan]
            elif infos_pnt["type"] == 2 or infos_pnt["type"] == 12:
                res_gnd[2] = np.nan

            tabl_gnd_res += [res_gnd]
            list_gnd_res += ["\n" + name_pnt,
                             f"{pnt_gnd[0]:.3f}", f"{pnt_gnd[1]:.3f}", f"{pnt_gnd[2]:.3f}",
                             f"{ptCoord[0]:.3f}", f"{ptCoord[1]:.2f}", f"{ptCoord[2]:.3f}",
                             f"{res_gnd[0]:.3f}", f"{res_gnd[1]:.3f}", f"{res_gnd[2]:.3f}",
                             f"{nbr_mes}"]

            # Différence des points images
            for mes_bande in infos_pnt["geom_img"].values():
                for mes in mes_bande:
                    img = ta.project.find_shot(mes["img"])
                    if img is None:
                        print(f"L'image {mes['img']} n'a pas d'orientation")
                        continue
                    mes_image_esti = np.round(img.imc.world_to_image(*ptCoord), 2)
                    res_image_esti = mes['coord_image_mes'] - mes_image_esti
                    tabl_img_res += [res_image_esti]
                    list_img_res_gnd += ["\n" + name_pnt, mes['img'],
                                         f"{mes['coord_image_mes'][0]:.3f}", f"{mes['coord_image_mes'][1]:.3f}", f"{mes_image_esti[0]:.3f}",
                                         f"{mes_image_esti[1]:.3f}", f"{res_image_esti[0]:.3f}", f"{res_image_esti[1]:.3f}"]

    # Calcul des coordonnées terrains estimées
    if callback is not None:
        callback("Calcul des coordonnées terrains estimées des points images par bandes ...", np.nan)
    list_gnd_res_bande = ["ID", "Bande", "X", "Y", "Z", "X_esti", "Y_esti", "Z_esti", "X-X_esti", "Y-Y_esti", "Z-Z_esti",
                          "Mes"]
    for name_pnt, infos_pnt in dict_pnt.items():
        if infos_pnt["geom_img"]:
            for num_bande, mes_bande in infos_pnt["geom_img"].items():
                name_img = [mes["img"] for mes in mes_bande]
                c = [mes["coord_image_mes"][0] for mes in mes_bande]
                l = [mes["coord_image_mes"][1] for mes in mes_bande]
                ptCoord = ta.project.compute_intersection(name_img, c, l)

                pnt_gnd = infos_pnt['coord_terrain_mes']
                res_gnd = infos_pnt['coord_terrain_mes'] - ptCoord

                if infos_pnt["type"] == 1 or infos_pnt["type"] == 11:
                    res_gnd[0:2] = [np.nan, np.nan]
                elif infos_pnt["type"] == 2 or infos_pnt["type"] == 12:
                    res_gnd[2] = np.nan

                list_gnd_res_bande += ["\n" + name_pnt, num_bande,
                                       f"{pnt_gnd[0]:.3f}", f"{pnt_gnd[1]:.3f}", f"{pnt_gnd[2]:.3f}",
                                       f"{ptCoord[0]:.3f}", f"{ptCoord[1]:.2f}", f"{ptCoord[2]:.3f}",
                                       f"{res_gnd[0]:.3f}", f"{res_gnd[1]:.3f}", f"{res_gnd[2]:.3f}",
                                       f"{len(mes_bande)}"]

    tabl_gnd_res = np.array(tabl_gnd_res)
    tabl_gnd_res_nbr = np.count_nonzero(~np.isnan(tabl_gnd_res), axis=0)
    tabl_gnd_res_min = np.nanmin(tabl_gnd_res, axis=0)
    tabl_gnd_res_max = np.nanmax(tabl_gnd_res, axis=0)
    tabl_gnd_res_moy = np.nanmean(tabl_gnd_res, axis=0)
    tabl_gnd_res_std = np.nanstd(tabl_gnd_res, axis=0)
    tabl_gnd_res_rms = np.sqrt(np.nanmean(tabl_gnd_res ** 2, axis=0))

    tabl_img_res = np.array(tabl_img_res)
    tabl_img_res_min = np.nanmin(tabl_img_res, axis=0)
    tabl_img_res_max = np.nanmax(tabl_img_res, axis=0)
    tabl_img_res_moy = np.nanmean(tabl_img_res, axis=0)
    tabl_img_res_std = np.nanstd(tabl_img_res, axis=0)
    tabl_img_res_rms = np.sqrt(np.nanmean(tabl_img_res ** 2, axis=0))

    stats = f"Controle bloc {ta.project.nom}\n\n" + \
            f"{datetime.now().strftime('%d/%m/%Y %H:%M:%S')}\n\n" + \
            f"Donnees chargee : \n" + \
            f"  - TA : {path_ori}\n" + \
            f"  - Mesures images :{dir_mes}\n" + \
            f"  - Points terrain : {path_app}\n\n" + \
            f"Points terrain\n" + \
            f"NB = {tabl_gnd_res_nbr[0]} {tabl_gnd_res_nbr[1]} {tabl_gnd_res_nbr[2]}\n" + \
            f"MIN = {tabl_gnd_res_min[0]:.3f} {tabl_gnd_res_min[1]:.3f} {tabl_gnd_res_min[2]:.3f}\n" + \
            f"MAX = {tabl_gnd_res_max[0]:.3f} {tabl_gnd_res_max[1]:.3f} {tabl_gnd_res_max[2]:.3f}\n" + \
            f"MOY = {tabl_gnd_res_moy[0]:.3f} {tabl_gnd_res_moy[1]:.3f} {tabl_gnd_res_moy[2]:.3f}\n" + \
            f"SIG = {tabl_gnd_res_std[0]:.3f} {tabl_gnd_res_std[1]:.3f} {tabl_gnd_res_std[2]:.3f}\n" + \
            f"EMQ = {tabl_gnd_res_rms[0]:.3f} {tabl_gnd_res_rms[1]:.3f} {tabl_gnd_res_rms[2]:.3f}\n\n" + \
            f"Mesures image\n" + \
            f"NB = {len(tabl_img_res)}\n" + \
            f"MIN = {tabl_img_res_min[0]:.3f} {tabl_img_res_min[1]:.3f}\n" + \
            f"MAX = {tabl_img_res_max[0]:.3f} {tabl_img_res_max[1]:.3f}\n" + \
            f"MOY = {tabl_img_res_moy[0]:.3f} {tabl_img_res_moy[1]:.3f}\n" + \
            f"SIG = {tabl_img_res_std[0]:.3f} {tabl_img_res_std[1]:.3f}\n" + \
            f"EMQ = {tabl_img_res_rms[0]:.3f} {tabl_img_res_rms[1]:.3f}\n\n"

    # Save
    dir_out.joinpath("gnd_res.txt").write_text(" ".join(list_gnd_res))
    dir_out.joinpath("gnd_res_bande.txt").write_text(" ".join(list_gnd_res_bande))
    dir_out.joinpath("img_res.txt").write_text(" ".join(list_img_res))
    dir_out.joinpath("img_res_gnd.txt").write_text(" ".join(list_img_res_gnd))
    dir_out.joinpath("stats.txt").write_text(stats)