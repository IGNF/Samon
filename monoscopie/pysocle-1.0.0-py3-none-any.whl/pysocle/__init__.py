"""
This package contains class and functions to manipulate geographic data.
"""