"""A module for manipulating a opi geometry."""

from __future__ import annotations
from typing import Union, Any, Tuple
import numpy as np
from copy import deepcopy


class Opi:
    """
    A class for manipulating an opi geometry.

    .. note::
         :class:`Opi` is not supposed to be instantiated directly via :func:`Opi`.
         To create a :class:`Opi` objects use from methods.

    """

    def __init__(self):
        self.gt = None

    @classmethod
    def from_gt(cls, gt: list) -> Opi:
        """
        Create an opi geometry from an opk (cartographic system).

        :param gt: geotransform.

        :return: opi geometry of the object.
        """
        obj = cls()
        obj.gt = gt
        return obj

    def image_to_world(self, c: Union[int, float, list, np.ndarray], l: Union[int, float, list, np.ndarray]) -> Tuple[Any, Any]:
        """
            Compute world coordinates from image coordinates

            :param c: column coordinates
            :param l: line coordinates
            :return: x, y world coordinates
        """
        x = np.array(c) * self.gt[1] + self.gt[0]
        y = np.array(l) * self.gt[5] + self.gt[3]
        return x, y

    def world_to_image(self, x: Union[int, float, list, np.ndarray], y: Union[int, float, list, np.ndarray]) -> Tuple[Any, Any]:
        """
            Compute image coordinates from world coordinates

            :param x: x world coordinate
            :param y: y world coordinate
            :return: image coordinates
        """
        c = (np.array(x) - self.gt[0])/self.gt[1]
        l = (np.array(y) - self.gt[3])/self.gt[5]
        return c, l

    def __deepcopy__(self, memodict):
        cls = self.__class__
        result = cls.__new__(cls)
        memodict[id(self)] = result
        for k, v in self.__dict__.items():
            setattr(result, k, deepcopy(v, memodict))
        return result