import numpy as np
from pysocle.orientation.image_conical import ImageConical
from scipy.spatial.transform import Rotation as R

def space_resection(shot, dem, size_grid=100, method=1):
    # Creation grille
    x_min, x_max, y_min, y_max = shot.extent.GetEnvelope()
    x, y = np.mgrid[int(x_min):int(x_max) + size_grid:size_grid, int(y_min):int(y_max) + size_grid:size_grid]
    x, y = x.ravel(), y.ravel()
    z = dem.get(x, y)
    xe, ye, ze = shot.imc.system.world_to_euclidean(x, y, z)
    c_obs, l_obs = shot.imc.world_to_image(x, y, z)

    imc_adjust = ImageConical.from_mat_eucli(x_pos=shot.imc.x_pos, y_pos=shot.imc.y_pos, z_pos=shot.imc.z_pos,
                                             mat_eucli=shot.imc.mat_eucli, system=shot.imc.system, camera=shot.imc.camera,
                                             lock=shot.imc.lock)

    bool_iter = True
    count_iter = 0
    while bool_iter:
        count_iter +=1
        if method == 0:
            A = mat_obs_rot(xe, ye, ze, imc_adjust)
        elif method == 1:
            A = mat_obs_opk(xe, ye, ze, imc_adjust)
        else:
            raise ValueError("La méthode doit être 0 ou 1")

        c, l = imc_adjust.world_to_image(x, y, z)
        v_res = np.c_[c_obs-c, l_obs-l].reshape(2 * len(xe), 1)

        dx = np.squeeze(np.linalg.lstsq(A, v_res, rcond=None)[0])
        new_x_pos, new_y_pos, new_z_pos = imc_adjust.x_pos + dx[0], imc_adjust.y_pos + dx[1], imc_adjust.z_pos + dx[2]
        if method == 0:
            new_mat_eucli = imc_adjust.mat_eucli + np.squeeze(dx)[3:].reshape(3, 3)
        elif method ==1:
            new_mat_eucli = R.from_euler('xyz', -(imc_adjust.opk_eucli + dx[3:]*180/np.pi), degrees=True).as_matrix()
        else:
            raise ValueError("La méthode doit être 0 ou 1")

        imc_new_adjust = ImageConical.from_mat_eucli(x_pos=new_x_pos, y_pos=new_y_pos, z_pos=new_z_pos,
                                                 mat_eucli=new_mat_eucli, system=shot.imc.system,
                                                 camera=shot.imc.camera, lock=shot.imc.lock)

        dcoord = np.array([imc_new_adjust.sommet]) - np.array([imc_adjust.sommet])
        dopk = np.array([imc_new_adjust.opk]) - np.array([imc_adjust.opk])

        if (np.all(dcoord<10**-3) and np.all(dopk<10**-6)) or count_iter>10:
            bool_iter = False

        imc_adjust = imc_new_adjust

    return imc_adjust

def mat_obs_rot(xe, ye ,ze, imc_adjust):
    A = np.zeros((2 * len(xe), 12))
    dp = np.vstack([xe - imc_adjust.x_pos_eucli, ye - imc_adjust.y_pos_eucli, ze - imc_adjust.z_pos_eucli])
    pnt_cliche = imc_adjust.mat_eucli @ dp

    A[::2, 0] = imc_adjust.camera.focal * (-imc_adjust.mat_eucli[0, 0] * pnt_cliche[2] + imc_adjust.mat_eucli[2, 0] * pnt_cliche[0]) / pnt_cliche[2] ** 2
    A[::2, 1] = imc_adjust.camera.focal * (-imc_adjust.mat_eucli[0, 1] * pnt_cliche[2] + imc_adjust.mat_eucli[2, 1] * pnt_cliche[0]) / pnt_cliche[2] ** 2
    A[::2, 2] = imc_adjust.camera.focal * (-imc_adjust.mat_eucli[0, 2] * pnt_cliche[2] + imc_adjust.mat_eucli[2, 2] * pnt_cliche[0]) / pnt_cliche[2] ** 2
    A[::2, 3] = imc_adjust.camera.focal * dp[0] / pnt_cliche[2]
    A[::2, 4] = imc_adjust.camera.focal * dp[1] / pnt_cliche[2]
    A[::2, 5] = imc_adjust.camera.focal * dp[2] / pnt_cliche[2]
    A[::2, 6] = 0
    A[::2, 7] = 0
    A[::2, 8] = 0
    A[::2, 9] = -imc_adjust.camera.focal * dp[0] * pnt_cliche[0] / pnt_cliche[2] ** 2
    A[::2, 10] = -imc_adjust.camera.focal * dp[1] * pnt_cliche[0] / pnt_cliche[2] ** 2
    A[::2, 11] = -imc_adjust.camera.focal * dp[2] * pnt_cliche[0] / pnt_cliche[2] ** 2
    A[1::2, 0] = imc_adjust.camera.focal * (-imc_adjust.mat_eucli[1, 0] * pnt_cliche[2] + imc_adjust.mat_eucli[2, 0] * pnt_cliche[1]) / pnt_cliche[2] ** 2
    A[1::2, 1] = imc_adjust.camera.focal * (-imc_adjust.mat_eucli[1, 1] * pnt_cliche[2] + imc_adjust.mat_eucli[2, 1] * pnt_cliche[1]) / pnt_cliche[2] ** 2
    A[1::2, 2] = imc_adjust.camera.focal * (-imc_adjust.mat_eucli[1, 2] * pnt_cliche[2] + imc_adjust.mat_eucli[2, 2] * pnt_cliche[1]) / pnt_cliche[2] ** 2
    A[1::2, 3] = 0
    A[1::2, 4] = 0
    A[1::2, 5] = 0
    A[1::2, 6] = imc_adjust.camera.focal * dp[0] / pnt_cliche[2]
    A[1::2, 7] = imc_adjust.camera.focal * dp[1] / pnt_cliche[2]
    A[1::2, 8] = imc_adjust.camera.focal * dp[2] / pnt_cliche[2]
    A[1::2, 9] = -imc_adjust.camera.focal * dp[0] * pnt_cliche[1] / pnt_cliche[2] ** 2
    A[1::2, 10] = -imc_adjust.camera.focal * dp[1] * pnt_cliche[1] / pnt_cliche[2] ** 2
    A[1::2, 11] = -imc_adjust.camera.focal * dp[2] * pnt_cliche[1] / pnt_cliche[2] ** 2
    return A

def mat_obs_opk(xe, ye, ze, imc_adjust):
    dp = np.vstack([xe - imc_adjust.x_pos_eucli, ye - imc_adjust.y_pos_eucli, ze - imc_adjust.z_pos_eucli])
    pnt_cliche = imc_adjust.mat_eucli @ dp
    o, p, k = imc_adjust.opk_eucli * np.pi / 180
    co, so = np.cos(o), np.sin(o)
    cp, sp = np.cos(p), np.sin(p)
    ck, sk = np.cos(k), np.sin(k)

    A = np.zeros((2 * len(xe), 6))
    A[::2, 0] = imc_adjust.camera.focal * (-imc_adjust.mat_eucli[0, 0] * pnt_cliche[2] + imc_adjust.mat_eucli[2, 0] * pnt_cliche[0]) / pnt_cliche[2] ** 2
    A[::2, 1] = imc_adjust.camera.focal * (-imc_adjust.mat_eucli[0, 1] * pnt_cliche[2] + imc_adjust.mat_eucli[2, 1] * pnt_cliche[0]) / pnt_cliche[2] ** 2
    A[::2, 2] = imc_adjust.camera.focal * (-imc_adjust.mat_eucli[0, 2] * pnt_cliche[2] + imc_adjust.mat_eucli[2, 2] * pnt_cliche[0]) / pnt_cliche[2] ** 2
    A[::2, 3] = imc_adjust.camera.focal * (((ck * sp * co - sk * so) * dp[1] + (sk * co + ck * sp * so) * dp[2]) * pnt_cliche[2] + pnt_cliche[0] * (cp * co * dp[1] + cp * so * dp[2])) / pnt_cliche[2] ** 2
    A[::2, 4] = imc_adjust.camera.focal * ((-ck * sp * dp[0] + ck * cp * so * dp[1] - ck * cp * co * dp[2]) * pnt_cliche[2] - pnt_cliche[0] * (cp * dp[0] + sp * so * dp[1] - sp * co * dp[2])) / pnt_cliche[2] ** 2
    A[::2, 5] = imc_adjust.camera.focal * (-sk * cp * dp[0] + (-sk * sp * so + ck * so) * dp[1] + (ck * so + sk * sp * co) * dp[2]) / pnt_cliche[2]
    A[1::2, 0] = imc_adjust.camera.focal * (-imc_adjust.mat_eucli[1, 0] * pnt_cliche[2] + imc_adjust.mat_eucli[2, 0] * pnt_cliche[1]) / pnt_cliche[2] ** 2
    A[1::2, 1] = imc_adjust.camera.focal * (-imc_adjust.mat_eucli[1, 1] * pnt_cliche[2] + imc_adjust.mat_eucli[2, 1] * pnt_cliche[1]) / pnt_cliche[2] ** 2
    A[1::2, 2] = imc_adjust.camera.focal * (-imc_adjust.mat_eucli[1, 2] * pnt_cliche[2] + imc_adjust.mat_eucli[2, 2] * pnt_cliche[1]) / pnt_cliche[2] ** 2
    A[1::2, 3] = imc_adjust.camera.focal * (((-ck * so - sk * sp * co) * dp[1] + (ck * co - sk * sp * so) * dp[2]) * pnt_cliche[2] + pnt_cliche[1] * (cp * co * dp[1] + cp * so * dp[2])) / pnt_cliche[2] ** 2
    A[1::2, 4] = imc_adjust.camera.focal * ((sk * sp * dp[0] - sk * cp * so * dp[1] + sk * cp * co * dp[2]) * pnt_cliche[2] - pnt_cliche[1] * (cp * dp[0] + sp * so * dp[1] - sp * co * dp[2])) / pnt_cliche[2] ** 2
    A[1::2, 5] = imc_adjust.camera.focal * (-ck * cp * dp[0] - sk * co + ck * sp * so * dp[1] - (sk * so - ck * sp * co) * dp[2]) / pnt_cliche[2]
    return A
