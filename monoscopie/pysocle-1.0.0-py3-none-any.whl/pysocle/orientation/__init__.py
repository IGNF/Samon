"""
This package contains class and functions for manipulating orientation models.
"""