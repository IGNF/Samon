"""
A module for computing RPC geometries.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Union, Tuple
if TYPE_CHECKING:
    from pysocle.photogrammetry.shot import Shot

import numpy as np
from pathlib import Path
from osgeo import gdal, gdalconst
from pysocle.altimetry.dem import Dem
from pysocle.utils.diverse import convert, convertback


def setup_matrix_obs(img_norm, x_norm, y_norm, z_norm, polynomial_degree):
    if polynomial_degree == 1:
        A = np.ones((len(img_norm), 7))
        A[:, 1] *= x_norm
        A[:, 2] *= y_norm
        A[:, 3] *= z_norm
        A[:, 4] *= -img_norm * x_norm
        A[:, 5] *= -img_norm * y_norm
        A[:, 6] *= -img_norm * z_norm

    elif polynomial_degree == 2:
        A = np.ones((len(img_norm), 19))
        A[:, 1] *= x_norm
        A[:, 2] *= y_norm
        A[:, 3] *= z_norm
        A[:, 4] *= x_norm * y_norm
        A[:, 5] *= x_norm * z_norm
        A[:, 6] *= y_norm * z_norm
        A[:, 7] *= x_norm * x_norm
        A[:, 8] *= y_norm * y_norm
        A[:, 9] *= z_norm * z_norm
        A[:, 10] *= -img_norm * x_norm
        A[:, 11] *= -img_norm * y_norm
        A[:, 12] *= -img_norm * z_norm
        A[:, 13] *= -img_norm * x_norm * y_norm
        A[:, 14] *= -img_norm * x_norm * z_norm
        A[:, 15] *= -img_norm * y_norm * z_norm
        A[:, 16] *= -img_norm * x_norm * x_norm
        A[:, 17] *= -img_norm * y_norm * y_norm
        A[:, 18] *= -img_norm * z_norm * z_norm

    elif polynomial_degree == 3:
        A = np.ones((len(img_norm), 39))
        A[:, 1] *= x_norm
        A[:, 2] *= y_norm
        A[:, 3] *= z_norm
        A[:, 4] *= x_norm * y_norm
        A[:, 5] *= x_norm * z_norm
        A[:, 6] *= y_norm * z_norm
        A[:, 7] *= x_norm * x_norm
        A[:, 8] *= y_norm * y_norm
        A[:, 9] *= z_norm * z_norm
        A[:, 10] *= x_norm * y_norm * z_norm
        A[:, 11] *= x_norm * x_norm * x_norm
        A[:, 12] *= x_norm * y_norm * y_norm
        A[:, 13] *= x_norm * z_norm * z_norm
        A[:, 14] *= x_norm * x_norm * y_norm
        A[:, 15] *= y_norm * y_norm * y_norm
        A[:, 16] *= y_norm * z_norm * z_norm
        A[:, 17] *= x_norm * x_norm * z_norm
        A[:, 18] *= y_norm * y_norm * z_norm
        A[:, 19] *= z_norm * z_norm * z_norm
        A[:, 20] *= -img_norm * x_norm
        A[:, 21] *= -img_norm * y_norm
        A[:, 22] *= -img_norm * z_norm
        A[:, 23] *= -img_norm * x_norm * y_norm
        A[:, 24] *= -img_norm * x_norm * z_norm
        A[:, 25] *= -img_norm * y_norm * z_norm
        A[:, 26] *= -img_norm * x_norm * x_norm
        A[:, 27] *= -img_norm * y_norm * y_norm
        A[:, 28] *= -img_norm * z_norm * z_norm
        A[:, 29] *= -img_norm * x_norm * y_norm * z_norm
        A[:, 30] *= -img_norm * x_norm * x_norm * x_norm
        A[:, 31] *= -img_norm * x_norm * y_norm * y_norm
        A[:, 32] *= -img_norm * x_norm * z_norm * z_norm
        A[:, 33] *= -img_norm * x_norm * x_norm * y_norm
        A[:, 34] *= -img_norm * y_norm * y_norm * y_norm
        A[:, 35] *= -img_norm * y_norm * z_norm * z_norm
        A[:, 36] *= -img_norm * x_norm * x_norm * z_norm
        A[:, 37] *= -img_norm * y_norm * y_norm * z_norm
        A[:, 38] *= -img_norm * z_norm * z_norm * z_norm
    else:
        raise ValueError("Le degré du polynome doit être 1, 2 ou 3")

    return A


def least_square(img_norm, x_norm, y_norm, z_norm, polynomial_degree):
    A = setup_matrix_obs(img_norm, x_norm, y_norm, z_norm, polynomial_degree)
    x = np.linalg.lstsq(A, img_norm, rcond=None)[0]

    coef_rpc = np.zeros(40)
    if polynomial_degree == 1:
        coef_rpc[0:4] = x[0:4]
        coef_rpc[20] = 1
        coef_rpc[21:24] = x[4:7]

    elif polynomial_degree == 2:
        coef_rpc[0:10] = x[0:10]
        coef_rpc[20] = 1
        coef_rpc[21:30] = x[10:19]

    elif polynomial_degree == 3:
        coef_rpc[0:20] = x[0:20]
        coef_rpc[20] = 1
        coef_rpc[21:40] = x[20:39]

    return coef_rpc


class Rpc:
    """
    A class for computing RPC geometries.

    :param shot: shot.
    :param dem: dem.
    :param size_grid: grid step length in which the RPC parameters will be estimated.
    :param polynomial_degree: polynomial's degree.
    :param true_rpc: RPC in geographical coordinates.


    .. note::
         A RPC is always describing a transformation from geographical coordinates to images coordinates.

    """

    def __init__(self, shot: Shot, dem: Union[Path, str, Dem], size_grid: int, polynomial_degree: int, true_rpc: bool,
                 fact_rpc_carto: Union[float, None] = None):
        self.proj_engine = shot.imc.system.proj_engine
        self.dem = dem if isinstance(dem, Dem) else Dem(dem, cval=0)
        self.true_rpc = true_rpc
        self.fact_rpc_carto = fact_rpc_carto
        self.param_rpc = {"X_num": np.full(20, np.nan), "X_den": np.full(19, np.nan), "Y_num": np.full(20, np.nan),
                          "Y_den": np.full(19, np.nan), "img_scale": np.nan, "img_offset": np.nan, "grd_scale": np.nan,
                          "grd_offset": np.nan}
        self.tag = None
        self.compute_rpc(shot, size_grid, polynomial_degree)

    def compute_rpc(self, shot, size_grid, polynomial_degree):
        x_min, x_max, y_min, y_max = shot.extent.GetEnvelope()
        x, y = np.mgrid[int(x_min):int(x_max)+size_grid:size_grid, int(y_min):int(y_max)+size_grid:size_grid]
        x, y = x.ravel(), y.ravel()
        z = self.dem.get(x, y)
        if self.true_rpc:
            x_geog, y_geog, z_geog = self.proj_engine.carto_to_geog(x, y, z)
        else:
            x_geog, y_geog, z_geog = x*self.fact_rpc_carto, y*self.fact_rpc_carto, z
        col, lin = shot.imc.world_to_image(x, y, z)
        self.solve_coefficient(col, lin, x_geog, y_geog, z_geog, polynomial_degree)

    def solve_coefficient(self, col, lin, x_geog, y_geog, z_geog, polynomial_degree):
        # Linearisation des valeurs images
        col_offset = np.round(np.mean(col))
        col_scale = np.round(np.max(np.absolute(col - col_offset)))
        col_norm = (col - col_offset) / col_scale
        lin_offset = np.round(np.mean(lin))
        lin_scale = np.round(np.max(np.absolute(col - col_offset)))
        lin_norm = (lin - lin_offset) / lin_scale

        # Linearisation des valeurs terrains
        x_offset = np.round(np.mean(x_geog), 5)
        x_scale = max(np.round(np.max(np.absolute(x_geog - x_offset)), 3), 1)
        x_norm = (x_geog - x_offset) / x_scale
        y_offset = np.round(np.mean(y_geog), 5)
        y_scale = max(np.round(np.max(np.absolute(y_geog - y_offset)), 3), 1)
        y_norm = (y_geog - y_offset) / y_scale
        z_offset = np.round(np.mean(z_geog))
        z_scale = max(np.round(np.max(np.absolute(z_geog - z_offset)), 3), 1)
        z_norm = (z_geog - z_offset) / z_scale

        # Compute coefficient
        coeffx = least_square(col_norm, x_norm, y_norm, z_norm, polynomial_degree)
        coeffy = least_square(lin_norm, x_norm, y_norm, z_norm, polynomial_degree)

        X_num = coeffx[0:20]
        X_den = coeffx[20:]
        Y_num = coeffy[0:20]
        Y_den = coeffy[20:]

        self.param_rpc["X_num"] = X_num
        self.param_rpc["X_den"] = X_den
        self.param_rpc["Y_num"] = Y_num
        self.param_rpc["Y_den"] = Y_den
        self.param_rpc["col_scale"] = col_scale
        self.param_rpc["lin_scale"] = lin_scale
        self.param_rpc["x_scale"] = x_scale
        self.param_rpc["y_scale"] = y_scale
        self.param_rpc["z_scale"] = z_scale
        self.param_rpc["col_offset"] = col_offset
        self.param_rpc["lin_offset"] = lin_offset
        self.param_rpc["x_offset"] = x_offset
        self.param_rpc["y_offset"] = y_offset
        self.param_rpc["z_offset"] = z_offset

        self.tag = {"ERR_BIAS": "-1",
                    "ERR_RAND": "-1",
                    "LINE_OFF": str(lin_offset),
                    "SAMP_OFF": str(col_offset),
                    "LAT_OFF": str(y_offset),
                    "LONG_OFF": str(x_offset),
                    "HEIGHT_OFF": str(z_offset),
                    "LINE_SCALE": str(lin_scale),
                    "SAMP_SCALE": str(col_scale),
                    "LAT_SCALE": str(y_scale),
                    "LONG_SCALE": str(x_scale),
                    "HEIGHT_SCALE": str(z_scale),
                    "LINE_NUM_COEFF": " ".join([str(_) for _ in Y_num]),
                    "LINE_DEN_COEFF": " ".join([str(_) for _ in Y_den]),
                    "SAMP_NUM_COEFF": " ".join([str(_) for _ in X_num]),
                    "SAMP_DEN_COEFF": " ".join([str(_) for _ in X_den])}

    def world_to_image(self, x, y, z):
        x_geog, y_geog, z_geog = self.proj_engine.carto_to_geog(x, y, z)
        col, lin = self.eval(x_geog, y_geog, z_geog)
        return col, lin

    def eval(self, x_geog, y_geog, z_geog):
        type_input = type(x_geog)
        x_geog, y_geog, z_geog = convert(x_geog, y_geog, z_geog)

        # normalize pnt
        x_norm = (x_geog - self.param_rpc["x_offset"]) / self.param_rpc["x_scale"]
        y_norm = (y_geog - self.param_rpc["y_offset"]) / self.param_rpc["y_scale"]
        z_norm = (z_geog - self.param_rpc["z_offset"]) / self.param_rpc["z_scale"]

        polynome = np.array([[1, X, Y, Z, X * Y, X * Z, Y * Z, X ** 2, Y ** 2, Z ** 2, X * Y * Z, X ** 3,
                              X * Y ** 2, X * Z ** 2, X ** 2 * Y, Y ** 3, Y * Z ** 2, X ** 2 * Z,
                              Y ** 2 * Z, Z ** 3] for X, Y, Z in zip(x_norm, y_norm, z_norm)]).T

        col_norm = (self.param_rpc["X_num"] @ polynome) / (self.param_rpc["X_den"] @ polynome)
        lin_norm = (self.param_rpc["Y_num"] @ polynome) / (self.param_rpc["Y_den"] @ polynome)
        col = (col_norm * self.param_rpc["col_scale"]) + self.param_rpc["col_offset"]
        lin = (lin_norm * self.param_rpc["lin_scale"]) + self.param_rpc["lin_offset"]

        return convertback(type_input, col, lin)

    def image_to_world(self, c: Union[np.asarray, list, float], l: Union[np.asarray, list, float],
                       dem: Union[Dem, float], prec: int = 0.1, iter_max: int = 20) \
            -> Tuple[Union[np.asarray, list, float], Union[np.asarray, list, float], Union[np.asarray, list, float]]:

        # Change type
        type_input = type(c)
        c, l = convert(c, l)

        # Reference point
        x_ref, y_ref = self.param_rpc["x_offset"], self.param_rpc["y_offset"]
        c_ref, l_ref = self.eval(x_ref, y_ref, 0)

        #  Transform nearby locations to establish affine direction vectors : terrain -> image
        fll_delta = 0.0001
        geo_transform = [0, 0, 0, 0, 0, 0]
        dc, dl = self.eval(x_ref + fll_delta, y_ref, 0)
        geo_transform[1] = (dc - c_ref) / fll_delta
        geo_transform[4] = (dl - l_ref) / fll_delta
        dc, dl = self.eval(x_ref, y_ref + fll_delta, 0)
        geo_transform[2] = (dc - c_ref) / fll_delta
        geo_transform[5] = (dl - l_ref) / fll_delta
        geo_transform[0] = c_ref - geo_transform[1] * x_ref - geo_transform[2] * y_ref
        geo_transform[3] = l_ref - geo_transform[4] * x_ref - geo_transform[5] * y_ref

        # geo transform invert image -> terrain
        geo_transform_inv = [0, 0, 0, 0, 0, 0]
        geo_transform_inv[0] = (geo_transform[5] * geo_transform[0] - geo_transform[3] * geo_transform[2]) / (geo_transform[2] * geo_transform[4] - geo_transform[5] * geo_transform[1])
        geo_transform_inv[1] = - geo_transform[5] / (geo_transform[2] * geo_transform[4] - geo_transform[5] * geo_transform[1])
        geo_transform_inv[2] = geo_transform[2] / (geo_transform[2] * geo_transform[4] - geo_transform[5] * geo_transform[1])
        geo_transform_inv[3] = (geo_transform[4] * geo_transform[0] - geo_transform[3] * geo_transform[1]) / (geo_transform[5] * geo_transform[1] - geo_transform[4] * geo_transform[2])
        geo_transform_inv[4] = -geo_transform[4] / (geo_transform[5] * geo_transform[1] - geo_transform[4] * geo_transform[2])
        geo_transform_inv[5] = geo_transform[1] / (geo_transform[5] * geo_transform[1] - geo_transform[4] * geo_transform[2])

        # initialisation de l'estimation
        x_iter = geo_transform_inv[0] + geo_transform_inv[1] * c + geo_transform_inv[2] * l
        y_iter = geo_transform_inv[3] + geo_transform_inv[4] * c + geo_transform_inv[5] * l

        x_iter_old, y_iter_old = np.full_like(c, 0), np.full_like(c, 0)
        dc_old, dl_old = np.full_like(c, 0), np.full_like(c, 0)

        nbr_iter = 0
        precision_reached = False
        while not precision_reached and nbr_iter < iter_max:
            z = dem.get(*self.proj_engine.carto_to_geog(x_iter, y_iter)) if isinstance(dem, Dem) else np.full_like(c, dem)
            c_iter, l_iter = self.eval(x_iter, y_iter, z)
            dc, dl = c_iter - c, l_iter - l
            x_iter = x_iter - (dc * geo_transform_inv[1] + dl * geo_transform_inv[2])
            y_iter = y_iter - (dc * geo_transform_inv[4] + dl * geo_transform_inv[5])

            # If the error changes sign, we might oscillate forever, so take a mean position as a new guess
            cond = (dc*dc_old < 0) & (dl*dl_old < 0)
            x_iter[cond] = (np.abs(dc[cond]) * x_iter_old[cond] + np.abs(dc_old[cond]) * x_iter[cond]) / (np.abs(dc[cond]) + np.abs(dc_old[cond]))
            y_iter[cond] = (np.abs(dc[cond]) * y_iter_old[cond] + np.abs(dc_old[cond]) * y_iter[cond]) / (np.abs(dc[cond]) + np.abs(dc_old[cond]))

            # Converged
            if np.any(np.abs(dc) < prec) and np.any(np.abs(dl) < prec):
                precision_reached = True

            dc_old, dl_old = dc, dl
            x_iter_old, y_iter_old = x_iter, y_iter
            nbr_iter += 1

        if precision_reached:
            x_iter, y_iter = self.proj_engine.geog_to_carto(x_iter, y_iter)
            return convertback(type_input, x_iter, y_iter)
        else:
            return np.nan, np.nan, np.nan

    def add_tag(self, path_img):
        ds = gdal.Open(str(path_img), gdalconst.GA_Update)
        ds.SetMetadata(self.tag, "RPC")
        del ds

    def export_rpc_txt(self, path_rpc):
        path_rpc = Path(path_rpc)
        list_txt_rpc = ["ERR_BIAS: -1",
                        "ERR_RAND: -1",
                        f"LINE_OFF: {self.param_rpc['lin_offset']}",
                        f"SAMP_OFF: {self.param_rpc['col_offset']}",
                        f"LAT_OFF: {self.param_rpc['y_offset']}",
                        f"LONG_OFF: {self.param_rpc['x_offset']}",
                        f"HEIGHT_OFF: {self.param_rpc['z_offset']}",
                        f"LINE_SCALE: {self.param_rpc['lin_scale']}",
                        f"SAMP_SCALE: {self.param_rpc['col_scale']}",
                        f"LAT_SCALE: {self.param_rpc['y_scale']}",
                        f"LONG_SCALE: {self.param_rpc['x_scale']}",
                        f"HEIGHT_SCALE: {self.param_rpc['z_scale']}"]

        for idx, val in enumerate(self.param_rpc["Y_num"]):
            list_txt_rpc += [f"LINE_NUM_COEFF_{idx + 1}: {val}"]

        for idx, val in enumerate(self.param_rpc["Y_den"]):
            list_txt_rpc += [f"LINE_DEN_COEFF_{idx + 1}: {val}"]

        for idx, val in enumerate(self.param_rpc["X_num"]):
            list_txt_rpc += [f"SAMP_NUM_COEFF_{idx + 1}: {val}"]

        for idx, val in enumerate(self.param_rpc["X_den"]):
            list_txt_rpc += [f"SAMP_DEN_COEFF_{idx + 1}: {val}"]

        path_rpc.write_text("\n".join(list_txt_rpc))
