"""A module for manipulating a conical geometry."""

from __future__ import annotations

from copy import deepcopy
from typing import Union, Tuple

import numpy as np
from pysocle.altimetry.dem import Dem
from pysocle.geodesy.euclidean_matisrtl import EuclideanMatisrtl
from pysocle.geodesy.euclidean_topaero import EuclideanTopaero
from pysocle.utils.diverse import convertback, convert
from pysocle.photogrammetry.camera import Camera
from shapely import Polygon


class ImageConical:
    """
    A class for manipulating a conical geometry.

    .. note::
         :class:`ImageConical` is not supposed to be instantiated directly via :func:`ImageConical`.
         To create a :class:`ImageConical` objects use from methods.

    """

    def __init__(self):
        self.system = None
        self._x_pos = np.nan
        self._y_pos = np.nan
        self._z_pos = np.nan
        self.x_pos_eucli = np.nan
        self.y_pos_eucli = np.nan
        self.z_pos_eucli = np.nan
        self.x_nadir = np.nan
        self.y_nadir = np.nan
        self.z_nadir = np.nan
        self.scale_factor = np.nan
        self.mat = None  # matrice rotation dans le repere carto
        self.mat_eucli = None  # matrice rotation dans le repere euclidien (identique à mat à une convention de
        # signe près si le repère euclidien est centré sur le cliché)
        self.camera = None  # obj camera
        self.lock = 1
        self.dict_syst = None
        self.f_syst = []  # fonction à appliquer dans le repere cliche pour obtenir les coords images
        self.f_syst_inv = []  # fonction à appliquer dans le repere cliche pour obtenir les coords terrains

    @classmethod
    def from_opk(cls, x_pos: float, y_pos: float, z_pos: float, x_nadir: float, y_nadir: float, z_nadir: float,
                 opk: Union[np.array, list], system: Union[EuclideanTopaero, EuclideanMatisrtl],
                 camera: Camera, lock: bool) -> ImageConical:
        """
        Create a conical geometry from an opk (cartographic system).

        :param x_pos: x coordinate of the shot.
        :param y_pos: y coordinate of the shot.
        :param z_pos: z coordinate of the shot.
        :param x_nadir: x coordinate of the nadir.
        :param y_nadir: y coordinate of the nadir.
        :param z_nadir: z coordinate of the nadir.
        :param opk: OPK angles in degres.
        :param system: local Euclidean reference system.
        :param camera: camera of the shot.
        :param lock: Prevent adjustment.

        :return: conical geometry of the object.
        """
        obj = cls()
        obj.system = system
        obj._x_pos, obj._y_pos, obj._z_pos = x_pos, y_pos, z_pos
        obj.x_nadir, obj.y_nadir, obj.z_nadir = x_nadir, y_nadir, z_nadir
        obj.x_pos_eucli, obj.y_pos_eucli, obj.z_pos_eucli = obj.system.world_to_euclidean(x_pos, y_pos, z_pos)
        obj.scale_factor = obj.system.proj_engine.get_scale_factor(x_pos, y_pos)
        obj.mat = obj.system.opk_to_mat(opk)
        obj.mat_eucli = obj.system.mat_to_mat_eucli(x_pos, y_pos, obj.mat)
        obj.camera = camera
        obj.lock = lock
        return obj

    @classmethod
    def from_quaternion(cls, x_pos: float, y_pos: float, z_pos: float, x_nadir: float, y_nadir: float, z_nadir: float,
                        q: Union[np.array, list], system: Union[EuclideanTopaero, EuclideanMatisrtl], camera: Camera,
                        lock: bool, dict_syst: dict) -> ImageConical:
        """
        Create a conical geometry from a quaternion (local Euclidean reference system).

        :param x_pos: x coordinate of the shot.
        :param y_pos: y coordinate of the shot.
        :param z_pos: z coordinate of the shot.
        :param x_nadir: x coordinate of the nadir.
        :param y_nadir: y coordinate of the nadir.
        :param z_nadir: z coordinate of the nadir.
        :param q: quaternion of the shot.
        :param system: local Euclidean reference system
        :param camera: camera of the shot.
        :param lock: prevent adjustment.
        :param dict_syst: model parameters.

        :return: conical geometry of the object.
        """
        obj = cls()
        obj.system = system
        obj._x_pos, obj._y_pos, obj._z_pos = x_pos, y_pos, z_pos
        obj.x_nadir, obj.y_nadir, obj.z_nadir = x_nadir, y_nadir, z_nadir
        obj.x_pos_eucli, obj.y_pos_eucli, obj.z_pos_eucli = obj.system.world_to_euclidean(x_pos, y_pos, z_pos)
        obj.scale_factor = obj.system.proj_engine.get_scale_factor(x_pos, y_pos)
        obj.mat_eucli = obj.system.quaternion_to_mat_eucli(q)
        obj.mat = obj.system.mat_eucli_to_mat(x_pos, y_pos, obj.mat_eucli)
        obj.camera = camera
        obj.lock = lock
        if dict_syst is not None:
            obj.dict_syst = dict_syst
            obj.f_syst += [lambda x_shot, y_shot, z_shot: (x_shot + dict_syst["S2"]*x_shot,
                                                          y_shot + dict_syst["S1"]*x_shot,
                                                          z_shot)]
            obj.f_syst_inv += [lambda x_shot, y_shot, z_shot: (x_shot/(1+dict_syst["S2"]),
                                                               y_shot - dict_syst["S1"]*x_shot/(1+dict_syst["S2"]),
                                                               z_shot)]

        return obj

    @classmethod
    def from_mat(cls, x_pos: float, y_pos: float, z_pos: float, mat: np.asarray,
                 system: Union[EuclideanTopaero, EuclideanMatisrtl], camera: Camera, lock: bool):
        """
        Create a conical geometry from a rotation matrix (cartographic system).

        :param x_pos: x coordinate of the shot.
        :param y_pos: y coordinate of the shot.
        :param z_pos: z coordinate of the shot.
        :param mat: rotation matrix of the shot.
        :param system: local Euclidean reference system.
        :param camera: camera of the shot.
        :param lock: Prevent adjustment.

        :return: conical geometry of the object.
        """
        obj = cls()
        obj.system = system
        obj._x_pos, obj._y_pos, obj._z_pos = x_pos, y_pos, z_pos
        obj.x_pos_eucli, obj.y_pos_eucli, obj.z_pos_eucli = obj.system.world_to_euclidean(x_pos, y_pos, z_pos)
        obj.scale_factor = obj.system.proj_engine.get_scale_factor(x_pos, y_pos)
        obj.mat = mat
        obj.mat_eucli = obj.system.mat_to_mat_eucli(x_pos, y_pos, obj.mat)
        obj.camera = camera
        obj.lock = lock
        return obj

    @classmethod
    def from_mat_eucli(cls, x_pos: float, y_pos: float, z_pos: float, mat_eucli: np.asarray,
                       system: Union[EuclideanTopaero, EuclideanMatisrtl], camera: Camera, lock: bool = 1,
                       dict_syst: dict = None):
        """
        Create a conical geometry from a rotation matrix (local Euclidean reference system).

        :param x_pos: x coordinate of the shot.
        :param y_pos: y coordinate of the shot.
        :param z_pos: z coordinate of the shot.
        :param mat_eucli: rotation matrix of the shot.
        :param system: local Euclidean reference system.
        :param camera: camera of the shot.
        :param lock: prevent adjustment.
        :param dict_syst: model parameters.

        :return: conical geometry of the object.
        """
        obj = cls()
        obj.system = system
        obj._x_pos, obj._y_pos, obj._z_pos = x_pos, y_pos, z_pos
        obj.x_pos_eucli, obj.y_pos_eucli, obj.z_pos_eucli = obj.system.world_to_euclidean(x_pos, y_pos, z_pos)
        obj.scale_factor = obj.system.proj_engine.get_scale_factor(x_pos, y_pos)
        obj.mat_eucli = mat_eucli
        obj.mat = obj.system.mat_eucli_to_mat(x_pos, y_pos, obj.mat_eucli)
        obj.camera = camera
        obj.lock = lock

        if dict_syst is not None:
            obj.dict_syst = dict_syst
            obj.f_syst += [lambda x_shot, y_shot, z_shot: (x_shot + dict_syst["S2"] * x_shot,
                                                           y_shot + dict_syst["S1"] * x_shot,
                                                           z_shot)]
            obj.f_syst_inv += [lambda x_shot, y_shot, z_shot: (x_shot / (1 + dict_syst["S2"]),
                                                               y_shot - dict_syst["S1"] * x_shot / (
                                                                           1 + dict_syst["S2"]),
                                                               z_shot)]
        return obj

    def get_Z_remove_scale_factor(self, dem: Dem) -> float:
        """Return Z after removing the scale factor. The Z of the object is NOT modified."""
        if np.isnan(self.z_nadir):
            self.compute_nadir(dem)
        return (self.z_pos + self.scale_factor * self.z_nadir) / (1 + self.scale_factor)

    def get_Z_add_scale_factor(self, dem: Dem) -> float:
        """
        Return Z after adding the scale factor. The Z of the object is NOT modified.

        :param dem: Dem of the area
        """
        if np.isnan(self.z_nadir):
            self.compute_nadir(dem)
        return self.z_pos + self.scale_factor * (self.z_pos - self.z_nadir)

    def compute_nadir(self, dem: Dem):
        """
        Compute the nadir point of the shot

        :param dem: Dem of the area
        """
        self.x_nadir, self.y_nadir, self.z_nadir = self.image_to_world(self.camera.x_ppa, self.camera.y_ppa, dem)

    def compute_extent(self, dem: Dem, pnt_side: int = 4, prec: float = 1., iter_max: int = 2) -> Polygon:
        """
        Compute the extent of the shot

        :param dem: Dem of the area.
        :param pnt_side: number of point in the extent between two corners.
        :param prec: accuracy.
        :param iter_max: maximum number of iterations.
        """
        # Image coordinates of the border
        c = np.r_[np.linspace(0, self.camera.w, pnt_side), np.full((pnt_side - 2,), self.camera.w),
                  np.linspace(self.camera.w, 0, pnt_side), np.full((pnt_side - 2,), 0)]
        l = np.r_[np.full((pnt_side - 1,), 0), np.linspace(0, self.camera.h, pnt_side),
                  np.full((pnt_side - 2,), self.camera.h), np.linspace(self.camera.h, 0, pnt_side)[:-1]]

        # Ground coordinates of the border
        x_world, y_world, z_world = self.image_to_world(c, l, dem, prec, iter_max)
        poly = Polygon([(x,y) for x, y in zip(x_world, y_world)])

        return poly

    def world_to_image_approx(self, x: Union[np.asarray, list, float], y: Union[np.asarray, list, float],
                              z: Union[np.asarray, list, float], dem: Dem)\
            -> Tuple[Union[np.asarray, list, float], Union[np.asarray, list, float]]:
        """
        Compute the image coordinates of a world point.
        This algorithm is faster but less precise than :func:`world_to_image`.

        :param x: x coordinates of the point
        :param y: y coordinates of the point
        :param z: z coordinates of the point
        :param dem: Dem of the area

        :return: c, l image coordinates
        """
        # Shot coordinates with scale factor correction
        z_pos_cor = self.z_pos + self.scale_factor * (self.z_pos - dem.get(self.x_pos, self.y_pos))

        # Transform M into a pseudo Euclidean system (earth curvature correction)
        earth_ray = 6366000.
        dx = x - self.x_pos
        dy = y - self.y_pos
        TT = (dx ** 2 + dy ** 2) / (4 * earth_ray)
        CC = (earth_ray + z) / (TT + earth_ray)
        x_eucli = dx * CC
        y_eucli = dy * CC
        z_eucli = (earth_ray - TT) * CC - earth_ray

        # Point-Shot vector in the Euclidean system
        dr = np.vstack([x_eucli, y_eucli, z_eucli - z_pos_cor])

        # Transform into image coordinates
        M2 = self.mat @ dr
        k = -self.camera.focal / M2[2]
        c = k * M2[0] + self.camera.x_ppa
        l = self.camera.y_ppa - k * M2[1]

        return c, l

    def world_to_image(self, x_world: Union[np.asarray, list, float], y_world: Union[np.asarray, list, float],
                       z_world: Union[np.asarray, list, float])\
            -> Tuple[Union[np.asarray, list, float], Union[np.asarray, list, float]]:
        """
        Compute the image coordinates of a world point.
        This algorithm is slower but more accurate than :func:`world_to_image_approx`.

        :param x_world: x_world coordinates of the point
        :param y_world: y_world coordinates of the point
        :param z_world: z_world coordinates of the point

        :return: c, l Image coordinates
        """
        type_input = type(x_world)
        x_eucli, y_eucli, z_eucli = self.system.world_to_euclidean(x_world, y_world, z_world)
        x_bundle, y_bundle, z_bundle = self.local_to_bundle(x_eucli, y_eucli, z_eucli)
        x_shot, y_shot, z_shot = self.bundle_to_shot(x_bundle, y_bundle, z_bundle)
        c, l = self.shot_to_image(x_shot, y_shot, z_shot)
        return convertback(type_input, c, l)

    def image_to_world(self, c: Union[np.asarray, list, float], l: Union[np.asarray, list, float], dem: Union[Dem, float],
                       prec: float = 0.1, iter_max: int = 3) -> \
            Tuple[Union[np.asarray, list, float], Union[np.asarray, list, float], Union[np.asarray, list, float]]:
        """
        Compute the world coordinates of (a) image point(s).
        A Dem must be used.

        :param c: column coordinates of image point(s)
        :param l: line coordinates of image point(s)
        :param dem: Dem of the area or constant value
        :param prec: accuracy
        :param iter_max: maximum number of iterations

        :return: x, y, z World coordinates
        """
        # initialisation
        # passage en local en faisant l'approximation z "local" a partir du z "world"
        # La fonction calcule le x et y euclidien correspondant à une coordonnées image et un Z local
        type_input = type(c)
        c, l = convert(c, l)

        z_world = dem.get(self.x_pos, self.y_pos) if isinstance(dem, Dem) else dem
        z_world = np.full_like(c, z_world)
        x_local, y_local, z_local = self.image_z_to_local(c, l, z_world)
        # On a les coordonnées locales approchées (car z non local) on passe en world
        x_world, y_world, _ = self.system.euclidean_to_world(x_local, y_local, z_local)
        precision_reached = False
        nbr_iter = 0

        while not precision_reached and nbr_iter < iter_max:
            z_world = dem.get(x_world, y_world) if isinstance(dem, Dem) else dem
            # On repasse en euclidien avec le bon Zworld , l'approximation plani ayant un impact minime
            x_local, y_local, z_local = self.system.world_to_euclidean(x_world, y_world, z_world)
            # nouvelle transfo avec un zLocal plus precis
            x_local, y_local, z_local = self.image_z_to_local(c, l, z_local)
            # passage en terrain (normalement le zw obtenu devrait être quasiment identique au Z initial)
            x_world_new, y_world_new, z_world_new = self.system.euclidean_to_world(x_local, y_local, z_local)

            dist = ((x_world_new - x_world) ** 2 + (y_world_new - y_world) ** 2 + (z_world_new - z_world) ** 2) ** 0.5
            if np.any(dist < prec):
                precision_reached = True
            x_world, y_world, z_world = x_world_new, y_world_new, z_world_new
            nbr_iter += 1

        return convertback(type_input, x_world, y_world, z_world)

    def image_z_to_local(self, c, l, z):
        x_local_0, y_local_0, z_local_0, x_local_1, y_local_1, z_local_1 = self.image_to_local_vec(c, l)
        lamb = (z - z_local_0) / (z_local_1 - z_local_0)
        x_local = x_local_0 + (x_local_1 - x_local_0) * lamb
        y_local = y_local_0 + (y_local_1 - y_local_0) * lamb
        return x_local, y_local, z

    def image_to_local_vec(self, c, l):
        pass
        # on applique les tranfo 2d qui s'appliquent au repère image (sous ech ou crop par exemple)
        # todo
        # on calcule le faisceau perspectif
        x_bundle_0, y_bundle_0, z_bundle_0 = 0, 0, 0
        x_bundle_1, y_bundle_1, z_bundle_1 = self.shot_to_bundle(*self.image_to_shot(c, l))

        # on passe le faisceau dans le repere local extrinseque
        x_local_0, y_local_0, z_local_0 = self.bundle_to_local(x_bundle_0, y_bundle_0, z_bundle_0)
        x_local_1, y_local_1, z_local_1 = self.bundle_to_local(x_bundle_1, y_bundle_1, z_bundle_1)

        return x_local_0, y_local_0, z_local_0, x_local_1, y_local_1, z_local_1

    def local_to_bundle(self, x_local, y_local, z_local):
        # Repere local euclidien -> repere faisceau
        point_bundle = self.mat_eucli @ np.vstack(
            [x_local - self.x_pos_eucli, y_local - self.y_pos_eucli, z_local - self.z_pos_eucli])
        return point_bundle[0], point_bundle[1], point_bundle[2]

    def bundle_to_shot(self, x_bundle, y_bundle, z_bundle):
        # Repere faisceau -> repere cliche
        x_shot = x_bundle * self.camera.focal / z_bundle
        y_shot = y_bundle * self.camera.focal / z_bundle
        z_shot = z_bundle
        for f in self.f_syst:
            x_shot, y_shot, z_shot = f(x_shot, y_shot, z_shot)
        return x_shot, y_shot, z_shot

    def shot_to_image(self, x_shot, y_shot, _):
        # Repere cliche -> repere image
        c = x_shot + self.camera.x_ppa
        l = y_shot + self.camera.y_ppa
        return c, l

    def image_to_shot(self, c, l):
        # Repere image -> repere cliche
        x_shot = c - self.camera.x_ppa
        y_shot = l - self.camera.y_ppa
        z_shot = np.full_like(x_shot, self.camera.focal)
        return x_shot, y_shot, z_shot

    def shot_to_bundle(self, x_shot, y_shot, z_shot):
        # Repere cliche -> repere faisceau
        for f in self.f_syst_inv:
            x_shot, y_shot, z_shot = f(x_shot, y_shot, z_shot)
        x_bundle = x_shot / self.camera.focal * z_shot
        y_bundle = y_shot / self.camera.focal * z_shot
        z_bundle = z_shot
        return x_bundle, y_bundle, z_bundle

    def bundle_to_local(self, x_bundle, y_bundle, z_bundle):
        # Repere faisceau -> repere local
        point_local = self.mat_eucli.T @ np.vstack([x_bundle, y_bundle, z_bundle]) + np.array(
            [self.x_pos_eucli, self.y_pos_eucli, self.z_pos_eucli]).reshape(-1, 1)
        return point_local[0], point_local[1], point_local[2]

    @property
    def sommet(self):
        return self.x_pos, self.y_pos, self.z_pos

    @property
    def quaternion(self):
        return self.system.mat_eucli_to_quaternion(self.mat_eucli)

    @property
    def opk(self):
        return self.system.mat_to_opk(self.mat)

    @property
    def opk_eucli(self):
        return self.system.mat_to_opk(self.mat_eucli)

    @property
    def x_pos(self):
        return self._x_pos

    @x_pos.setter
    def x_pos(self, x_pos: float):
        self._x_pos = x_pos
        self.x_pos_eucli, self.y_pos_eucli, self.z_pos_eucli = self.system.world_to_euclidean(self.x_pos,
                                                                                              self.y_pos,
                                                                                              self.z_pos)
    @property
    def y_pos(self):
        return self._y_pos

    @y_pos.setter
    def y_pos(self, y_pos: float):
        self._y_pos = y_pos
        self.x_pos_eucli, self.y_pos_eucli, self.z_pos_eucli = self.system.world_to_euclidean(self.x_pos,
                                                                                              self.y_pos,
                                                                                              self.z_pos)
    @property
    def z_pos(self):
        return self._z_pos

    @z_pos.setter
    def z_pos(self, z_pos: float):
        self._z_pos = z_pos
        self.x_pos_eucli, self.y_pos_eucli, self.z_pos_eucli = self.system.world_to_euclidean(self.x_pos,
                                                                                              self.y_pos,
                                                                                              self.z_pos)
    def __deepcopy__(self, memodict):
        cls = self.__class__
        result = cls.__new__(cls)
        memodict[id(self)] = result
        for k, v in self.__dict__.items():
            setattr(result, k, deepcopy(v, memodict))
        return result
