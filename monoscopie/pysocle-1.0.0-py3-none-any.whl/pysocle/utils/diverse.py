from pathlib import Path
from typing import Any

import numpy as np
from osgeo import gdal, ogr


# import pandas as pd

def indent(elem, level=0):
    """Structure the xml file."""

    i = "\n" + level * "  "
    if len(elem):
        if not elem.text or not elem.text.strip():
            elem.text = i + "  "
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
        for elem in elem:
            indent(elem, level + 1)
        if not elem.tail or not elem.tail.strip():
            elem.tail = i
    else:
        if level and (not elem.tail or not elem.tail.strip()):
            elem.tail = i

def indent_ta(elem):
    """Structure the xml file"""
    if len(elem):
        if not elem.text:
            elem.text = "\n"
        if not elem.tail or not elem.tail.strip():
            elem.tail = "\n"
        for elem in elem:
            indent_ta(elem)
        if not elem.tail or not elem.tail.strip():
            elem.tail = "\n"
    else:
        if not elem.tail or not elem.tail.strip():
            elem.tail = "\n"

def etree_to_dict(t, skip_word=None):
    # return {c.tag: c.text if len(c) == 0 else self.etree_to_dict(c) for c in t if c.tag not in skip_word}
    skip_word = [] if skip_word is None else skip_word
    dict_etree = {}
    for c in t:
        if c.tag not in skip_word:
            if len(c) == 0:
                if c.text is not None:
                    dict_etree[c.tag] = c.text.strip()
                # else:
                #     dict[c.tag] = c.text
            else:
                dict_etree[c.tag] = etree_to_dict(c)
    return dict_etree

def convert(*args: Any) -> np.ndarray:
    output = []
    for val in args:
        if np.isscalar(val):
            output.append(np.array([val]))
        elif type(val) == list:
            output.append(np.array(val))
        elif type(val) == np.ndarray:
            output.append(val)
    if len(output) > 1:
        return *output,
    else:
        return output[0]

def convertback(data_type: type, *args: np.ndarray) -> Any:
    # if inputs were lists, tuples or floats, convert back to original type.
    output = []
    for val in args:
        if data_type == list:
            output.append(val.tolist())
        elif data_type == np.ndarray:
            output.append(val)
        # elif data_type == pd.core.series.Series:
        #     output.append(val)
        else:
            output.append(val.item())
    if len(output) > 1:
        return *output,
    else:
        return output[0]

def get_ogr_driver(path_file, name_driver=None):
    # Driver
    path_file = Path(path_file)
    ogr_driver = None
    if name_driver is None:
        extension = path_file.suffix.lower()[1:]
        if extension == "opk":
            ogr_driver = ogr.GetDriverByName("CSV")
        else:
            for i in range(gdal.GetDriverCount()):
                drv = ogr.GetDriver(i)
                if drv.GetMetadataItem(gdal.DMD_EXTENSIONS) is not None and extension in drv.GetMetadataItem(
                        gdal.DMD_EXTENSIONS).lower():
                    ogr_driver = drv
                    break
        if ogr_driver is None:
            raise ValueError(f"Extension {extension} inconnue, veuillez utiliser l'option ogr_driver")

    else:
        ogr_driver = ogr.GetDriverByName(name_driver)
        if ogr_driver is None:
            raise ValueError(f"Driver {name_driver} inconnu")

    return ogr_driver

