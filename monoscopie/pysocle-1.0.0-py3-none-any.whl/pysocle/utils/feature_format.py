from enum import Enum
import json
from osgeo import ogr

FEATURE_FORMAT = {"ID": ogr.OFTString, "FLIGHT": ogr.OFTInteger, "STRIP": ogr.OFTInteger, "SHOT": ogr.OFTInteger,
     "TRANS": ogr.OFTInteger, "X": ogr.OFTReal, "Y": ogr.OFTReal, "Z": ogr.OFTReal,
     "O": ogr.OFTReal, "P": ogr.OFTReal, "K": ogr.OFTReal, "DATE": ogr.OFTString, "TIME": ogr.OFTString,
     "CAMERA": ogr.OFTString, "SHOT_PREV": ogr.OFTString, "SHOT_NEXT": ogr.OFTString,
     "OVERLAP_PREV": ogr.OFTReal, "OVERLAP_NEXT": ogr.OFTReal, "STRIP_PREV": ogr.OFTString,
     "STRIP_NEXT": ogr.OFTString, "SIDELAP_PREV": ogr.OFTReal, "SIDELAP_NEXT": ogr.OFTReal}


class Reader(Enum):
    # Pour x, y et z, la donnée est extraite de la géométrie si None
    default = {"ID": 0, "X": 1, "Y": 2, "Z": 3, "O": 4, "P": 5, "K": 6, "DATE": 7, "TIME": 8, "CAMERA": 9, "SHUTTER": None}
    ori = {"ID": 0, "X": 1, "Y": 2, "Z": 3, "O": 4, "P": 5, "K": 6, "DATE": None, "TIME": None, "CAMERA": 7, "SHUTTER": None}


class Writer(Enum):
    qualita = ["ID", "FLIGHT", "STRIP", "SHOT", "TRANS", "X", "Y", "Z", "O", "P", "K", "DATE", "TIME", "CAMERA",
               "SHOT_PREV", "SHOT_NEXT", "OVERLAP_PREV", "OVERLAP_NEXT", "STRIP_PREV", "STRIP_NEXT", "SIDELAP_PREV",
               "SIDELAP_NEXT"]
    ta = ["ID", "FLIGHT", "STRIP", "SHOT", "TRANS", "X", "Y", "Z", "O", "P", "K", "DATE", "TIME", "CAMERA"]
    opk = ["ID", "X", "Y", "Z", "O", "P", "K", "DATE", "TIME", "CAMERA"]
    ori = ["ID", "X", "Y", "Z", "O", "P", "K", "CAMERA"]


if __name__ == "__main__":
    from osgeo import ogr

    # with open("bla", "r") as f:
    #     pass
    #
    # print(getattr(Reader, "or"))
    p = r"D:\Projet_python\Pysocle_data\pysocle\jeu_test_petit\a.json"
    # # default = {"id": 0, "x": 1, "y": 2, "z": 3, "o": 4, "p": 5, "k": 6, "date": 7, "time": 8, "camera": 9,
    # #            "shutter": None}
    # #
    d = ["t", "p"]
    print(d)
    with open(p, 'w') as outfile:
        json.dump(d, outfile, indent=4)
    #
    # with open(p, 'r') as infile:
    #     a = json.load(infile)
    # print(a)