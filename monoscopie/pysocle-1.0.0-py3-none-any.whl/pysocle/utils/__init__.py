"""
This package contains some useful class and functions.
"""