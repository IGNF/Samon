"""
This package contains class and functions for manipulating elevation files.
"""