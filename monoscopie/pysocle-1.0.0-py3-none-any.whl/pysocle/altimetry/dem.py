"""A module for manipulating a digital elevation model."""

from __future__ import annotations

from pathlib import Path
from typing import Union, Any, Tuple

import numpy as np
from osgeo import gdal
from pysocle.utils.diverse import convertback
from scipy import ndimage
from collections.abc import Iterable

class Dem:
    """
    Represents a digital elevation model.

    :param path_dem: path to the dem file. If None Dem.get() always returns  0.
    :param order: The method of interpolation to perform. 0 : nearest, 1 : slinear, 3 : cubic, 5 : quintic.
    :param cval: Value to fill past edges of dem. if None raise an error for any point outside the dem.
    :param keep_in_memory: Store all data in memory.

    .. note::
        All gdal formats are supported. The file must contain georeferencing information.
    """
    def __init__(self, path_dem: Union[Path, str, None] = None, order: int = 1, cval: Union[int, None] = None,
                 keep_in_memory: bool = False):
        """
        Initiate a Dem object from a file path.

        :param path_dem: path to the dem file. If None Dem.get() always returns  0
        :param order: The method of interpolation to perform. 0:nearest 1:bilinear 3:cubic 5:quintic
        :param cval: Value to fill past edges of dem. if None raise an error for any point outside the dem.
        :param keep_in_memory: Store all image in memory
        """

        gdal.AllRegister()
        self.order = order
        self.keep_in_memory = keep_in_memory
        if path_dem is None or not Path(path_dem).is_file() or gdal.Open(str(path_dem)) is None:
            # Dem 0
            self.path_dem = None
            self.gt = [0, 1, 0, 0, 0, 1]
            self.cval = 0
            self.array = np.array([[]])
        else:
            self.path_dem = Path(path_dem)
            self.dem = gdal.Open(str(path_dem))
            self.rb = self.dem.GetRasterBand(1)
            self.gt = self.dem.GetGeoTransform()
            self.cval = cval if cval is not None else np.nan
            if self.keep_in_memory:
                self.array = self.rb.ReadAsArray()

    def image_to_world(self, c: Union[int, float, list, np.ndarray], l: Union[int, float, list, np.ndarray]) -> Tuple[Any, Any]:
        """
            Compute world coordinates from image coordinates

            :param c: column coordinates
            :param l: line coordinates
            :return: x, y world coordinates
        """
        x = np.array(c) * self.gt[1] + self.gt[0]
        y = np.array(l) * self.gt[5] + self.gt[3]
        return x, y

    def world_to_image(self, x: Union[int, float, list, np.ndarray], y: Union[int, float, list, np.ndarray]) -> Tuple[Any, Any]:
        """
            Compute image coordinates from world coordinates

            :param x: x world coordinate
            :param y: y world coordinate
            :return: image coordinates
        """
        c = (np.array(x) - self.gt[0])/self.gt[1]
        l = (np.array(y) - self.gt[3])/self.gt[5]
        return c, l

    def extract_dem_from_extent(self, path_dem, extent):
        xmin, ymin, xmax, ymax = extent.bounds
        img_dem = gdal.Translate(str(path_dem), self.dem, options=gdal.TranslateOptions(projWin=[xmin, ymax, xmax, ymin]))
        return img_dem

    def get(self, x: Union[int, float, list, np.ndarray], y: Union[int, float, list, np.ndarray]) -> Any:
        """
            Extract value in the Dem

            :param x: x world coordinate
            :param y: y world coordinate
            :return: z value.
        """
        type_input = type(x)
        x, y = np.array(x), np.array(y)
        if self.path_dem is None:
            return convertback(type_input, np.zeros_like(x))
        elif not self.keep_in_memory:
            xmin, ymin = np.min(x), np.min(y)
            xmax, ymax = np.max(x), np.max(y)
            imin, jmin = np.floor(self.world_to_image(xmin, ymax))
            imax, jmax = np.ceil(self.world_to_image(xmax, ymin))
            imin = int(min(max(imin, 0), self.dem.RasterXSize))
            imax = int(min(max(imax, 0), self.dem.RasterXSize - 1))
            jmin = int(min(max(jmin, 0), self.dem.RasterYSize))
            jmax = int(min(max(jmax, 0), self.dem.RasterYSize - 1))
            array = self.rb.ReadAsArray(imin, jmin, imax - imin + 1, jmax - jmin + 1)
            xmin, ymax = self.image_to_world(imin, jmin)
            c = (x - xmin)/self.gt[1]
            l = (y - ymax)/self.gt[5]
            # Les points images sont en col lig mais les np.array sont en lig col
            z = ndimage.map_coordinates(array, np.vstack([l, c]), order=self.order, mode="constant", cval=self.cval)

        else:
            # Les points images sont en col lig mais les np.array sont en lig col
            c, l = self.world_to_image(x, y)
            z = ndimage.map_coordinates(self.array, np.vstack([l, c]), order=self.order, mode="constant", cval=self.cval)

        if np.any(np.isnan(z)):
            raise IndexError("Out dem")
        else:
            return convertback(type(x), np.squeeze(z))