"""
    A package for manipulating an aerial imagery acquisition camera.
"""
from __future__ import annotations

import json
import xml.etree.ElementTree as ET
from copy import deepcopy
from datetime import datetime
from pathlib import Path
from typing import Union

import numpy as np
from pysocle.utils.diverse import indent, etree_to_dict


class Camera:
    """
    Represents an aerial imagery acquisition camera.

    .. note::
        :class:`Camera` is not supposed to be instantiated directly by :func:`Camera`. To create a :class:`Camera` objects use from methods.
    """
    def __init__(self):
        self._name = ""
        self._lens = ""
        self._origin = ""
        self._argentic = False
        self._calibration_date = datetime.strptime("06-07-2020", "%d-%m-%Y")
        self._serial_number = ""
        self._w = np.nan
        self._h = np.nan
        self._x_ppa = np.nan
        self._y_ppa = np.nan
        self._focal = np.nan
        self._pixel_size = 0
        self._orientation = 0
        self._radiometry = {}
        self._dict_cam = {}

    @classmethod
    def from_xml(cls, cam_xml: Union[Path, str, ET.Element]) -> Camera:
        """
        Creates a camera object from a xml

        :param cam_xml: calibration XML (file or etree element)

        :return: A camera object
        """
        if not ET.iselement(cam_xml):
            # Parsing du fichier XML
            cam_xml = Path(cam_xml)
            if not Path(cam_xml).is_file():
                raise ValueError(f"Le fichier de calibration {cam_xml} n'existe pas")
            tree = ET.parse(cam_xml)
            cam_xml = tree.getroot()

        #Create object
        dict_cam = etree_to_dict(cam_xml)
        obj = cls()
        obj.name = dict_cam.get("name", "")
        obj.lens = dict_cam.get("objectif", "")
        obj.origin = dict_cam.get("origine", "")
        obj.argentic = dict_cam.get("argentique", False)
        obj.calibration_date = dict_cam.get("calibration-date", "")
        obj.serial_number = dict_cam.get("serial-number", "")
        obj.w = dict_cam.get("usefull-frame", {}).get("rect", {}).get("w", np.nan)
        obj.h = dict_cam.get("usefull-frame", {}).get("rect", {}).get("h", np.nan)
        obj.x_ppa = dict_cam.get("focal", {}).get("pt3d", {}).get("x", np.nan)
        obj.y_ppa = dict_cam.get("focal", {}).get("pt3d", {}).get("y", np.nan)
        obj.focal = dict_cam.get("focal", {}).get("pt3d", {}).get("z", np.nan)
        obj.pixel_size = dict_cam.get("pixel_size", "")
        obj.orientation = dict_cam.get("orientation", "")
        obj.radiometry = dict_cam.get("radiometry", "")
        obj.dict_cam = dict_cam

        return obj

    @classmethod
    def from_value(cls, name: str, w: int, h: int, x_ppa: float, y_ppa: float, focal: float, pixel_size: float,
                   serial_number: str = "", calibration_date: datetime = datetime.strptime("06-07-2020", "%d-%m-%Y"))\
            -> Camera:
        """
        Creates a camera object from values.

        :param name: the name of the camera
        :param w: the width of the camera sensor in pixel
        :param h: the height of the camera sensor in pixel
        :param x_ppa: the first coordinate of the ppa in pixel
        :param y_ppa: the second coordinate of the ppa in pixel
        :param focal: the focal length in pixel
        :param pixel_size: the size of a pixel in meter
        :param serial_number: the serial number of the camera
        :param calibration_date: the calibration date of the camera


        :return: A camera object
        """
        obj = cls()
        obj.name = name
        obj.origin = name
        obj.w = w
        obj.h = h
        obj.x_ppa = x_ppa
        obj.y_ppa = y_ppa
        obj.focal = focal
        obj.pixel_size = pixel_size
        obj.serial_number = serial_number
        obj.calibration_date = calibration_date
        return obj

    def __getattr__(self, name):
        return self.dict_cam.get(name, "")

    @property
    def name(self) -> str:
        """
        The name of the camera.

        :getter: Returns the Camera name.
        :setter: Sets the Camera name.
        """
        return self._name

    @name.setter
    def name(self, name: str):
        try:
            self._name = str(name)
        except ValueError:
            raise ValueError("Name must be a string")

    @property
    def lens(self) -> str:
        """
        Info about the camera lens.

        :getter: Returns info about the camera lens.
        :setter: Sets info about the camera lens.
        """
        return self._lens

    @lens.setter
    def lens(self, lens: str):
        try:
            self._lens = str(lens)
        except ValueError:
            raise ValueError("Lens must be a str")

    @property
    def origin(self) -> str:
        """
        The origin name of the camera.

        :getter: Returns the camera origin name.
        :setter: Sets the camera origin name.
        """
        return self._origin

    @origin.setter
    def origin(self, origin: str):
        try:
            self._origin = str(origin)
        except ValueError:
            raise ValueError("Origin must be a str")

    @property
    def argentic(self) -> bool:
        """
        False if the camera is a numerical camera
        :getter: Returns the boolean
        :setter: Sets the boolean
        """
        return self._argentic

    @argentic.setter
    def argentic(self, argentic: bool):
        try:
            self._argentic = bool(int(argentic))
        except ValueError:
            raise ValueError("Argentic must be a boolean")

    @property
    def calibration_date(self) -> datetime:
        """
        The calibration date of the camera.

        :getter: Returns the camera calibration date.
        :setter: Sets the camera calibration date.
        """
        return self._calibration_date

    @calibration_date.setter
    def calibration_date(self, calibration_date: str):
        try:
            self._calibration_date = datetime.strptime(calibration_date, "%d-%m-%Y")
        except (TypeError, ValueError):
            pass
            #warnings.warn(f"Camera {self.origine} : Date de calibration incorrecte")

    @property
    def serial_number(self) -> str:
        """
        The serial number of the camera.

        :getter: Returns the camera serial number
        :setter: Sets the camera serial number
        """
        return self._serial_number

    @serial_number.setter
    def serial_number(self, serial_number: str):
        try:
            self._serial_number = str(serial_number)
        except ValueError:
            raise ValueError("Serial number must be a str")

    @property
    def w(self) -> int:
        """
        The width of the camera.

        :getter: Returns the camera width
        :setter: Sets the camera width
        """
        return self._w

    @w.setter
    def w(self, w: int):
        try:
            self._w = int(w)
        except ValueError:
            raise ValueError("The width must be an int")

    @property
    def h(self) -> int:
        """
        The height of the camera.

        :getter: Returns the camera height
        :setter: Sets the camera height
        """
        return self._h

    @h.setter
    def h(self, h: int):
        try:
            self._h = int(h)
        except ValueError:
            raise ValueError("The height must be an int")

    @property
    def x_ppa(self) -> float:
        """
        The x coordinate of the ppa.

        :getter: Returns the x coordinate of the ppa.
        :setter: Sets the x coordinate of the ppa.
        """
        return self._x_ppa

    @x_ppa.setter
    def x_ppa(self, x_ppa: float):
        try:
            self._x_ppa = float(x_ppa)
        except ValueError:
            raise ValueError("The x_ppa must be a float")

    @property
    def y_ppa(self) -> float:
        """
        The y coordinate of the ppa.

        :getter: Returns the y coordinate of the ppa.
        :setter: Sets the y coordinate of the ppa.
        """
        return self._y_ppa

    @y_ppa.setter
    def y_ppa(self, y_ppa: float):
        try:
            self._y_ppa = float(y_ppa)
        except ValueError:
            raise ValueError("The y_ppa must be a float")

    @property
    def focal(self) -> float:
        """
        The focal length of the camera in pixel.

        :getter: Returns the focal length of the camera.
        :setter: Sets the focal length of the camera.
        """
        return self._focal

    @focal.setter
    def focal(self, focal: float):
        try:
            self._focal = float(focal)
        except ValueError:
            raise ValueError("Focal must be a float")

    @property
    def pixel_size(self) -> float:
        """
        The pixel size of the camera in pixel.

        :getter: Returns the  camera pixel size in pixel.
        :setter: Sets the  camera pixel size in pixel.
        """
        return self._pixel_size

    @pixel_size.setter
    def pixel_size(self, pixel_size: float):
        try:
            self._pixel_size = float(pixel_size)
        except ValueError:
            raise ValueError("Pixel size must be a float")

    @property
    def orientation(self) -> int:
        """
        The orientation of the camera.

        :getter: Returns the camera orientation.
        :setter: Sets the camera orientation.
        """
        return self._orientation

    @orientation.setter
    def orientation(self, orientation: int):
        try:
            self._orientation = int(orientation)
        except ValueError:
            raise ValueError("Orientation must be a int")

    @property
    def radiometry(self) -> dict:
        """
        The radiometry of the camera.

        :getter: Returns the camera radiometry.
        :setter: Sets the camera radiometry.
        """
        return self._radiometry

    @radiometry.setter
    def radiometry(self, radiometry: dict):
        try:
            self._radiometry = dict(radiometry)
        except ValueError:
            raise ValueError("Radiometry must be a dict")

    @property
    def dict_cam(self) -> dict:
        """
        The dict of the camera object.

        :getter: Returns the dict of the object.
        :setter: Sets the dict of the camera.
        """

        return self._dict_cam

    @dict_cam.setter
    def dict_cam(self, dict_cam: dict):
        try:
            self._dict_cam = dict(dict_cam)
        except ValueError:
            raise ValueError("Dict_cam must be a int")

    def print(self) -> str:
        """
        Prints information about the camera
        """
        txt = ""
        for key, val in vars(self).items():
            key = key.replace("_", "")
            if key not in ["dict_cam"]:
                txt += "{} : {}\n".format(key, val)
        return txt

    def get_json(self) -> str:
        """
        Returns the info of the camera in a json format

        :return: camera information.
        """
        dict_cam_temp = {}
        for key, val in vars(self).items():
            key = key.replace("_", "")
            if key not in ["dict_cam", "calibrationdate"]:
                dict_cam_temp[key] = val
            elif key == "calibrationdate":
                dict_cam_temp[key] = val.strftime("%d-%m-%Y")
        return json.dumps(dict_cam_temp)

    def to_xml(self, dir_cam: Union[Path, str]) ->None:
        """
        Saves the ta as a light conical file.

        :param dir_cam: path to the calibration directory
        """
        dir_cam = Path(dir_cam)

        # creation XML
        sensor = ET.Element("sensor", {})
        ET.SubElement(sensor, "name").text = self.name
        ET.SubElement(sensor, "objectif").text = self.lens
        ET.SubElement(sensor, "origine").text = self.origin
        ET.SubElement(sensor, "argentique").text = str(int(self.argentic))
        ET.SubElement(sensor, "calibration-date").text = self.calibration_date.strftime("%d-%m-%Y")
        ET.SubElement(sensor, "serial_number").text = str(self.serial_number)

        usefull_frame = ET.SubElement(sensor, "usefull-frame")
        rect = ET.SubElement(usefull_frame, "rect")
        ET.SubElement(rect, "x").text = "0"
        ET.SubElement(rect, "y").text = "0"
        ET.SubElement(rect, "w").text = str(self.w)
        ET.SubElement(rect, "h").text = str(self.h)

        dark_frame = ET.SubElement(sensor, "dark-frame")
        rect = ET.SubElement(dark_frame, "rect")
        ET.SubElement(rect, "x").text = "0"
        ET.SubElement(rect, "y").text = "0"
        ET.SubElement(rect, "w").text = "0"
        ET.SubElement(rect, "h").text = "0"

        focal = ET.SubElement(sensor, "focal")
        pt3d = ET.SubElement(focal, "pt3d")
        ET.SubElement(pt3d, "x").text = str(self.x_ppa)
        ET.SubElement(pt3d, "y").text = str(self.y_ppa)
        ET.SubElement(pt3d, "z").text = str(self.focal)

        ET.SubElement(sensor, "pixel_size").text = str(self.pixel_size)
        ET.SubElement(sensor, "orientation").text = str(self.orientation)

        tree = ET.ElementTree(sensor)
        indent(sensor)
        tree.write(dir_cam.joinpath(self.origine).with_suffix(".xml"))

    def __deepcopy__(self, memodict):
        cls = self.__class__
        result = cls.__new__(cls)
        memodict[id(self)] = result
        for k, v in self.__dict__.items():
            setattr(result, k, deepcopy(v, memodict))
        return result
