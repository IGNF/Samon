"""
This package contains class and functions to manipulate orientation data.
"""