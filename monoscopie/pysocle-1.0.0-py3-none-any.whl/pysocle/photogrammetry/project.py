"""A module for manipulating an aerial imagery acquisition project."""

from __future__ import annotations

import warnings
import itertools
import json
from copy import deepcopy
from pathlib import Path
from typing import Union, Any, Tuple, Callable, Dict, List, Iterator
from shapely.ops import voronoi_diagram, transform
from shapely import Polygon, MultiPoint, MultiPolygon

import numpy as np
import pyproj
from osgeo import gdal, ogr, osr
from pysocle.altimetry.dem import Dem
from pysocle.geodesy.euclidean_topaero import EuclideanTopaero
from pysocle.geodesy.proj_engine import ProjEngine
from pysocle.geodesy.projection_list import ProjectionList
from pysocle.orientation.image_conical import ImageConical
from pysocle.photogrammetry.camera import Camera
from pysocle.photogrammetry.flight import Flight
from pysocle.photogrammetry.shot import Shot
from pysocle.photogrammetry.strip import Strip
from pysocle.utils.diverse import get_ogr_driver


class Project:
    """
    Represents an aerial imagery acquisition project.

    .. note::
        :class:`Project` is not supposed to be instantiated by users. You most likely need to use
        :class:`pysocle.photogrammetry.ta.Ta`.
    """

    def __init__(self):
        self._name = ""
        self._dem = None
        self._z0 = 0.00
        self._drift = 0.00
        self._overlap = 0.00
        self._sidelap = 0.00
        self._resolution = 0.00
        self._sun_height = 0.00
        self._elevation_sys = ""
        self._zi = False
        self._generic_name = ""
        self._designation = ""
        self._saa_number = ""
        self._theme = ""
        self._geographic_theme = ""
        self._sponsor = ""
        self._productor = ""
        self._barycentric_system = None
        self._camera = {}
        self._flight = {}
        self._proj_engine = None
        self._extent = Polygon()
        self._dict_project = {}

    @classmethod
    def from_dict(cls, dict_project: dict, proj_engine: ProjEngine) -> Project:
        """
        Create a project object from a dictionary.

        :param dict_project: dictonary.
        :param proj_engine: proj_engine.

        :return: A project object.
        """
        obj = cls()
        obj._proj_engine = proj_engine
        obj.name = dict_project.get("nom", "")
        obj.add_dem(dict_project.get("MNT", None))
        obj.z0 = dict_project.get("Z0", 0.00)
        obj.drift = dict_project.get("derive", 0.00)
        obj.overlap = dict_project.get("overlap", 0.00)
        obj.sidelap = dict_project.get("sidelap", 0.00)
        obj.resolution = dict_project.get("resolution", 0.00)
        obj.sun_height = dict_project.get("sun_height_min", 0.00)
        obj.elevation_sys = dict_project.get("reference_alti", "")
        obj.zi = dict_project.get("zi", False)
        obj.generic_name = dict_project.get("nom_generique", "")
        obj.designation = dict_project.get("designation", "")
        obj.saa_number = dict_project.get("numero_SAA", "")
        obj.theme = dict_project.get("theme", "")
        obj.geographic_theme = dict_project.get("theme_geographique", "")
        obj.sponsor = dict_project.get("commanditaire", "")
        obj.productor = dict_project.get("producteur", "")
        if "centre_rep_local" in dict_project:
            obj.init_euclidean_topaero(float(dict_project["centre_rep_local"]["pt2d"]["x"]),
                                       float(dict_project["centre_rep_local"]["pt2d"]["y"]))

        obj._dict_project = dict_project
        return obj

    @property
    def name(self) -> str:
        """
        Name of the project.

        :getter: Returns the project name.
        :setter: Sets the project name.
        """
        return self._name

    @name.setter
    def name(self, name: str):
        try:
            self._name = str(name)
        except ValueError:
            raise ValueError("Project name must be a str")

    @property
    def z0(self) -> float:
        """
        Mean level in the project.

        :getter: Returns the mean level of the project.
        :setter: Sets the mean level of the project.
        """
        return self._z0

    @z0.setter
    def z0(self, z0: float):
        try:
            self._z0 = float(z0)
        except ValueError:
            raise ValueError("z0 must be a float")

    @property
    def drift(self) -> float:
        """
        Drift of the project.

        :getter: Returns the project drift.
        :setter: Sets the project drift.
        """
        return self._drift

    @drift.setter
    def drift(self, drift: float):
        try:
            self._drift = float(drift)
        except ValueError:
            raise ValueError("drift must be a float")

    @property
    def overlap(self) -> float:
        """
        Mean overlap of the project.

        :getter: Returns the mean overlap of the project.
        :setter: Sets the mean overlap of the project.
        """
        return self._overlap

    @overlap.setter
    def overlap(self, overlap: float):
        try:
            self._overlap = float(overlap)
        except ValueError:
            raise ValueError("drift must be a float")

    @property
    def sidelap(self) -> float:
        """
        Mean sidelap of the project.

        :getter: Returns the mean sidelap of the project.
        :setter: Sets the mean sidelap of the project.
        """
        return self._sidelap

    @sidelap.setter
    def sidelap(self, sidelap: float):
        try:
            self._sidelap = float(sidelap)
        except ValueError:
            raise ValueError("sidelap must be a float")

    @property
    def resolution(self) -> float:
        """
        Mean resolution of the project.

        :getter: Returns the mean resolution of the project.
        :setter: Sets the mean resolution of the project.
        """
        return self._resolution

    @resolution.setter
    def resolution(self, resolution: float):
        try:
            self._resolution = float(resolution)
        except ValueError:
            raise ValueError("resolution must be a float")

    @property
    def sun_height(self) -> float:
        """
        Minimal sun height of the project.

        :getter: Returns the minimal sun height of the project
        :setter: Sets the minimal sun height of the project
        """
        return self._sun_height

    @sun_height.setter
    def sun_height(self, sun_height: float):
        try:
            self._sun_height = float(sun_height)
        except ValueError:
            raise ValueError("sun height must be a float")

    @property
    def elevation_sys(self) -> str:
        """
        Elevation system of the project.

        :getter: Returns the elevation system of the project
        :setter: Sets the elevation system of the project
        """
        return self._elevation_sys

    @elevation_sys.setter
    def elevation_sys(self, elevation_sys: str):
        try:
            self._elevation_sys = str(elevation_sys)
        except ValueError:
            raise ValueError("elevation system must be a str")

    @property
    def zi(self) -> bool:
        """
        Forbidden area in the project

        :getter: Returns zi
        :setter: Sets zi
        """
        return self._zi

    @zi.setter
    def zi(self, zi: bool):
        try:
            self._zi = bool(int(zi))
        except ValueError:
            raise ValueError("zi must be a bool")

    @property
    def generic_name(self) -> str:
        """
        Generic name of the project

        :getter: Returns generic_name
        :setter: Sets generic_name
        """
        return self._generic_name

    @generic_name.setter
    def generic_name(self, generic_name: str):
        try:
            self._generic_name = str(generic_name)
        except ValueError:
            raise ValueError("Generic name must be a str")

    @property
    def designation(self) -> str:
        """
        Designation of the project

        :getter: Returns designation
        :setter: Sets designation
        """
        return self._designation

    @designation.setter
    def designation(self, designation: str):
        try:
            self._designation = str(designation)
        except ValueError:
            raise ValueError("designation name must be a str")

    @property
    def saa_number(self) -> str:
        """
        Saa number of the project

        :getter: Returns saa_number
        :setter: Sets saa_number
        """
        return self._saa_number

    @saa_number.setter
    def saa_number(self, saa_number: str):
        try:
            self._saa_number = str(saa_number)
        except ValueError:
            raise ValueError("saa number name must be a str")

    @property
    def theme(self) -> str:
        """
        Theme of the project

        :getter: Returns theme
        :setter: Sets theme
        """
        return self._theme

    @theme.setter
    def theme(self, theme: str):
        try:
            self._theme = str(theme)
        except ValueError:
            raise ValueError("theme name must be a str")

    @property
    def geographic_theme(self) -> str:
        """
        Geographic theme of the project

        :getter: Returns geographic_theme
        :setter: Sets geographic_theme
        """
        return self._geographic_theme

    @geographic_theme.setter
    def geographic_theme(self, geographic_theme: str):
        try:
            self._geographic_theme = str(geographic_theme)
        except ValueError:
            raise ValueError("geographic_theme must be a str")

    @property
    def sponsor(self) -> str:
        """
        Sponsor of the project

        :getter: Returns sponsor
        :setter: Sets sponsor
        """
        return self._sponsor

    @sponsor.setter
    def sponsor(self, sponsor: str):
        try:
            self._sponsor = str(sponsor)
        except ValueError:
            raise ValueError("sponsor must be a str")

    @property
    def extent(self) -> Polygon:
        """
        Extent of the project

        :getter: Returns extent
        :setter: Sets extent
        """
        return self._extent

    @extent.setter
    def extent(self, extent: Polygon):
        if isinstance(extent, Polygon) or isinstance(extent, MultiPolygon):
            self._extent = extent
        else:
            raise ValueError(f"Project extent must be a shapely.Polygon not a {type(extent)}")

    @property
    def productor(self) -> str:
        """
        Productor of the project

        :getter: Returns productor
        :setter: Sets productor
        """
        return self._productor

    @productor.setter
    def productor(self, productor: str):
        try:
            self._productor = str(productor)
        except ValueError:
            raise ValueError("productor must be a str")

    @property
    def proj_engine(self) -> ProjEngine:
        """
        ProjEngine of the project

        :getter: Returns ProjEngine
        :setter: Not available
        """
        return self._proj_engine

    @property
    def dem(self) -> Union[Dem, None]:
        """
        The dem of the project

        :getter: Returns the dem of the project
        :setter: Not available
        """
        return self._dem

    @property
    def barycentric_system(self) -> Union[EuclideanTopaero, None]:
        """
        The Euclidean system of the project

        :getter: Returns barycentric_system
        :setter: Not available
        """
        return self._barycentric_system

    @property
    def camera(self) -> Dict[str, Camera]:
        """
        The cameras of the project

        :getter: Returns the cameras of the project
        :setter: Not available, see add_camera
        """
        return self._camera

    @property
    def flight(self) -> Dict[int, Flight]:
        """
        The flights of the project

        :getter: Returns the flights of the project
        :setter: Not available
        """
        return self._flight

    def add_camera(self, camera: Camera) -> None:
        """
        Add a camera to the project.

        :param camera: camera to be added.
        """
        if not isinstance(camera, Camera):
            raise TypeError("Camera must be a Camera")
        else:
            self.camera[camera.origin] = camera

    def remove_camera(self, camera: Union[str, Camera]) -> None:
        """
        Remove a camera from the project.

        :param camera: camera to be removed.
        """
        if isinstance(camera, Camera):
            self.camera.pop(camera.origin, None)
        else:
            self.camera.pop(camera, None)

    def add_flight(self, flight: Flight) -> None:
        """
        Add a Flight to the project.

        :param flight: Flight to be added.
        """
        if not isinstance(flight, Flight):
            raise TypeError("flight must be a Flight")
        else:
            self.flight[flight.number] = flight

    def remove_flight(self, flight: Union[int, Flight]) -> None:
        """
        Remove a Flight from the project.

        :param flight: Flight to be removed.
        """
        if isinstance(flight, Flight):
            self.flight.pop(flight.number, None)
        else:
            self.flight.pop(flight, None)

    def add_dem(self, path_dem: Union[Path, str, None] = None, order: int = 1, cval: Union[int, None] = None,
                keep_in_memory: bool = False):
        """
        Add a dem to the project.

        :param path_dem: path to the dem file. If None Dem.get() always returns  0
        :param order: The method of interpolation to perform. 0:nearest 1:slinear 3:cubic 5:quintic
        :param cval: Value to fill past edges of dem. if None raise an error for any point outside the dem.
        :param keep_in_memory: Store all data in memory
        """
        self._dem = Dem(path_dem=path_dem, order=order, cval=cval, keep_in_memory=keep_in_memory)

    def nbr_shot(self) -> int:
        """
        Compute the number of images in the project.

        :return: the number of images in the project.
        """
        return sum(v.nbr_shot() for v in self.flight.values())

    def nbr_strip(self) -> int:
        """
        Compute the number of strips in the project.

        :return: the number of strips in the project.
        """
        return sum(len(v.strip) for v in self.flight.values())

    def compute_kappa(self):
        """Compute the mean kappa of all strips in the project."""
        for flight in self.flight.values():
            flight.compute_kappa()

    def init_kappa(self):
        """Initiate the kappa of all images in the project."""
        self.compute_kappa()
        for flight in self.flight.values():
            flight.init_kappa()

    def compute_sun_height(self, callback: Union[Callable[[str, float], Any], None] = None) -> None:
        """
        Compute the sun height of all the images in the project.

        :param callback: Progress callback.
        """
        nbr_shot = self.nbr_shot()
        for ind_shot, shot in enumerate(self.get_shots()):
            if callback is not None:
                callback("Calcul de la hauteur solaire", ind_shot / nbr_shot)
            shot.compute_sun_height()

    def compute_extent_shot(self, callback: Union[Callable[[str, float], Any], None] = None) -> None:
        """
        Compute the extent of all images in the project.

        :param callback: Progress callback.
        """
        nbr_shot = self.nbr_shot()
        for ind_shot, shot in enumerate(self.get_shots()):
            if callback is not None:
                callback("Calcul des emprises des images", ind_shot / nbr_shot)
            shot.compute_extent(self.dem, 4, 1, 2)
            ind_shot += 1

    def compute_extent(self, recompute: bool = False, pnt_side: int = 4, prec: float = 1., iter_max: int = 2,
                       callback: Union[Callable[[str, float], Any], None] = None) -> None:
        """
        Compute the extent of the project. If recompute is False, extents are not recomputed if exists.

        :param recompute: recomputre all extent
        :param pnt_side: number of point in the extent between two corners
        :param prec: accuracy
        :param iter_max: maximum number of iterations
        :param callback: Progress callback.
        """
        project_extent = Polygon()
        nbr_flight, nbr_shot = len(self.flight), self.nbr_shot()

        def callback_project(step, _):
            callback_project.ind_shot += 1
            callback(f"Vol {ind_flight + 1}/{nbr_flight} {step}", callback_project.ind_shot / nbr_shot)

        callback_project.ind_shot = 0

        for ind_flight, flight in enumerate(self.flight.values()):
            if flight.extent.is_empty or recompute:
                flight.compute_extent(self.dem, recompute, pnt_side, prec, iter_max,
                                      callback_project if callback is not None else None)
            if project_extent.is_empty:
                project_extent = flight.extent
            else:
                project_extent = project_extent.union(flight.extent)
        self.extent = project_extent

    def compute_nadir(self) -> None:
        """Compute the nadir of all images in the project."""
        for shot in self.get_shots():
            shot.compute_nadir(self.dem)

    def detection_cross_strip(self) -> None:
        """Détection of the cross strips in the project."""
        list_kappa = []
        for flight in self.flight.values():
            for strip in flight.strip.values():
                strip.compute_kappa()
                list_kappa.append(strip.kappa * 180 / np.pi)

        sorted_kappa = sorted(list_kappa)
        val = [len(list(x[1])) for x in itertools.groupby(np.diff(sorted_kappa) < 1)]
        most_kappa = sorted_kappa[sum(val[0:np.argmax(val)])]

        for flight in self.flight.values():
            for strip in flight.strip.values():
                strip.cross = abs(strip.kappa * 180 / np.pi - most_kappa) > 3

    def compute_overlap(self, callback: Union[Callable[[str, float], Any], None] = None) -> None:
        """Compute the overlap in the project."""
        self.estimate_shot_topology()
        nbr_shot = self.nbr_shot()
        for index, shot in enumerate(self.get_shots()):
            if callback is not None:
                callback("Calcul du recouvrement longitudinal", index / nbr_shot)
            if shot.shot_next is not None:
                with warnings.catch_warnings():
                    warnings.filterwarnings("ignore", category=RuntimeWarning, module="shapely")
                    inter = shot.extent.intersection(shot.shot_next.extent)
                    shot.overlap_next = inter.area / shot.extent.area
                    shot.shot_next.overlap_prev = inter.area / shot.shot_next.extent.area

        if callback is not None:
            callback("Calcul du recouvrement longitudinal", 1)

    def compute_sidelap(self, callback: Union[Callable[[str, float], Any], None] = None) -> None:
        """Compute the sidelap of the project."""
        self.estimate_strip_topology()
        index, nbr_shot = 0, self.nbr_shot()
        for flight in self.flight.values():
            for strip in flight.strip.values():
                for shot in strip.shot.values():
                    if callback is not None:
                        callback("Calcul du recouvrement laléral", index / nbr_shot)
                    multipoint_border = MultiPoint(shot.extent.exterior.coords)
                    with warnings.catch_warnings():
                        warnings.filterwarnings("ignore", category=RuntimeWarning, module="shapely")
                        # On ne calcule l'intersection seulement si un nombre suffisant de point du cliché est dans la bande
                        if strip.strip_prev is not None and len(multipoint_border.intersection(strip.strip_prev.extent).geoms) > len(multipoint_border.geoms) / 4 + 1:
                            shot.sidelap_prev = shot.extent.intersection(strip.strip_prev.extent).area / shot.extent.area
                        if strip.strip_next is not None and len(multipoint_border.intersection(strip.strip_next.extent).geoms) > len(multipoint_border.geoms) / 4 + 1:
                            shot.sidelap_next = shot.extent.intersection(strip.strip_next.extent).area / shot.extent.area
                        index += 1

        if callback is not None:
            callback("Calcul du recouvrement laléral", 1)

    def estimate_strip_topology(self) -> None:
        """Estimate the strip topology."""
        self.detection_cross_strip()
        barycenter = self.compute_barycenter()
        list_strip = [strip for flight in self.flight.values() for strip in flight.strip.values() if not strip.cross]
        sorted_strip = sorted(list_strip,
                              key=lambda strip: (strip.param_line[0] * barycenter[0] + strip.param_line[2]) /
                                                strip.param_line[1] if strip.param_line[1] != 0
                              else strip.param_line[2] / strip.param_line[0])

        for ind in range(0, len(sorted_strip)):
            sorted_strip[ind].strip_prev = None
            sorted_strip[ind].strip_next = None
            try:
                for strip in sorted_strip[ind::-1]:
                    if strip.number != sorted_strip[ind].number:
                        sorted_strip[ind].strip_prev = strip
                        break
            except IndexError:
                pass
            try:
                for strip in sorted_strip[ind:]:
                    if strip.number != sorted_strip[ind].number:
                        sorted_strip[ind].strip_next = strip
                        break
            except IndexError:
                pass

    def estimate_shot_topology(self) -> None:
        """Estimate the shot topology."""
        for flight in self.flight.values():
            for strip in flight.strip.values():
                try:
                    sorted_shot = sorted(strip.shot.values(), key=lambda x: x.t)
                except TypeError:
                    sorted_shot = sorted(strip.shot.values(), key=lambda x: x.number)

                for ind in range(0, len(sorted_shot)):
                    try:
                        sorted_shot[ind].shot_prev = sorted_shot[ind - 1]
                    except IndexError:
                        sorted_shot[ind].shot_prev = None
                    try:
                        sorted_shot[ind].shot_next = sorted_shot[ind + 1]
                    except IndexError:
                        sorted_shot[ind].shot_next = None

    def compute_dev_res(self, dir_out: Union[str, Path], step: int = 25,
                        callback: Union[Callable[[str, float], Any], None] = None) -> Tuple[Path, Path]:
        """
        Compute the angle viewing and the resolution in the project.

        :param dir_out: the output directory
        :param step: resolution of images
        :param callback: Progress callback.
        """
        # Creation de la grille
        x_min = np.floor(self.extent.bounds[0] / step) * step
        y_min = np.ceil(self.extent.bounds[1] / step) * step
        x_max = np.floor(self.extent.bounds[2] / step) * step
        y_max = np.ceil(self.extent.bounds[3] / step) * step

        x_size = int((x_max - x_min) / step) + 1
        y_size = int((y_max - y_min) / step) + 1
        array_dev = np.full((y_size, x_size,), np.nan)
        array_res = np.full((y_size, x_size,), np.nan)
        gt = [x_min, step, 0, y_max, 0, -step]

        nbr_shot = self.nbr_shot()
        for ind_shot, shot in enumerate(self.get_shots()):
            if callback is not None:
                callback("Calcul du dévers et résolution", ind_shot / nbr_shot)

            # Limite emprise image
            x_min_shot = np.floor(shot.extent.bounds[0] / step) * step
            y_min_shot = np.ceil(shot.extent.bounds[1] / step) * step
            x_max_shot = np.floor(shot.extent.bounds[2] / step) * step
            y_max_shot = np.ceil(shot.extent.bounds[3] / step) * step

            # grille phasée avec l'image de dévers
            x_grid, y_grid = np.mgrid[x_min_shot:x_max_shot + step:step, y_min_shot:y_max_shot + step:step]
            x_grid = x_grid.ravel()
            y_grid = y_grid.ravel()
            z_grid = self.dem.get(x_grid, y_grid)
            c_grid = np.int_((x_grid - x_min) / step)
            l_grid = np.int_(-(y_grid - y_max) / step)

            # calcul du dévers et de la résolution
            dr = ((x_grid - shot.imc.x_pos) ** 2 + (y_grid - shot.imc.y_pos) ** 2) ** 0.5
            dz = shot.imc.z_pos - z_grid
            dev = 100 * dr / dz
            res = 100 * dz / shot.imc.camera.focal

            # Pour un point terrain donnée, on sélectionne les valeurs (dévers, résolution, ...)
            # issues de l'image avec le devers le plus faible en ce point
            ind_img = (dev == np.fmin(array_dev[l_grid, c_grid], dev))
            array_dev[l_grid[ind_img], c_grid[ind_img]] = dev[ind_img]
            array_res[l_grid[ind_img], c_grid[ind_img]] = res[ind_img]

        dir_out = Path(dir_out)
        path_dev = dir_out.joinpath(self.name + "_dev").with_suffix(".tif")
        path_res = dir_out.joinpath(self.name + "_res").with_suffix(".tif")
        driver = gdal.GetDriverByName("GTiff")

        img_dev = driver.Create(str(path_dev), array_dev.shape[1], array_dev.shape[0], 1, gdal.GDT_Float32)
        img_dev.SetGeoTransform(gt)
        img_dev.SetProjection(self.dem.dem.GetProjection())
        img_dev.GetRasterBand(1).WriteArray(array_dev)
        img_dev.FlushCache()

        img_res = driver.Create(str(path_res), array_res.shape[1], array_res.shape[0], 1, gdal.GDT_Float32)
        img_res.SetGeoTransform(gt)
        img_res.SetProjection(self.dem.dem.GetProjection())
        img_res.GetRasterBand(1).WriteArray(array_res)
        img_res.FlushCache()

        if callback is not None:
            callback("Calcul du dévers et résolution", 1)

        return path_dev, path_res

    def conversion_elevation(self, path_geoid_grid: Union[str, Path], ref_elevation: str) -> None:
        """
        Transforms elevation between ellipsoidal height and physical height.

        :param path_geoid_grid: path to the geoid grid
        :param ref_elevation: "h" to transform data from physical height to ellipsoidal height and "a" for the opposite.
        """
        grille_conv = Dem(path_geoid_grid)
        for shot in self.get_shots():
            if ref_elevation == "h":
                shot.imc.z_pos += grille_conv.get(shot.imc.x_pos, shot.imc.y_pos)
                shot.imc.z_nadir += grille_conv.get(shot.imc.x_pos, shot.imc.y_pos)
            elif ref_elevation == "a":
                shot.imc.z_pos -= grille_conv.get(shot.imc.x_pos, shot.imc.y_pos)
                shot.imc.z_nadir -= grille_conv.get(shot.imc.x_pos, shot.imc.y_pos)

    def add_voronoi_img(self, dir_opi: Union[str, Path], dir_opi_vor: Union[str, Path]) -> None:
        """
        Create mosaic images by adding a transparency band to all images.
        The mosaic is build from the voronoi of the project.

        :param dir_opi: directory of the images to modify
        :param dir_opi_vor: directory where to store modified images
        """
        path_vor = dir_opi.parent.joinpath("voronoi").with_suffix(".shp")
        self.compute_voronoi(path_voronoi=path_vor)
        for path_img in dir_opi.glob("*.tif"):
            name_img = path_img.stem.split("_opi")[0]
            img = self.find_shot(name_img)
            if img is not None:
                path_opi_vor = dir_opi_vor.joinpath(path_img.name)
                img = gdal.Open(str(path_img), gdal.GA_ReadOnly)
                driver = gdal.GetDriverByName("GTiff")
                img_opi_vor = driver.Create(str(path_opi_vor), img.RasterXSize, img.RasterYSize, img.RasterCount + 1,
                                            gdal.GDT_Byte, options=["COMPRESS=LZW"])
                img_opi_vor.SetGeoTransform(img.GetGeoTransform())
                img_opi_vor.SetProjection(img.GetProjection())
                for i in range(1, img.RasterCount + 1):
                    img_opi_vor.GetRasterBand(i).WriteArray(img.GetRasterBand(i).ReadAsArray())
                img_opi_vor.GetRasterBand(img.RasterCount + 1).SetColorInterpretation(gdal.GCI_AlphaBand)
                gdal.Rasterize(img_opi_vor, str(path_vor), options=gdal.RasterizeOptions(bands=[img.RasterCount + 1],
                                                                                         burnValues=255,
                                                                                         where=f"NAME='{name_img}'"))
                img_opi_vor.FlushCache()

    def compute_voronoi_raster(self, path_voronoi: Union[str, Path], step: int = 25,
                               callback: Union[Callable[[str, float], Any], None] = None) -> Tuple[Path, Path]:
        """
        Compute the voronoi of the project.

        :param path_voronoi: voronoi path
        :param step: voronoi resolution
        :param callback: Progress callback.
        """
        # Creation de la grille
        x_min = np.floor(self.extent.bounds[0] / step) * step
        y_min = np.ceil(self.extent.bounds[1] / step) * step
        x_max = np.floor(self.extent.bounds[2] / step) * step
        y_max = np.ceil(self.extent.bounds[3] / step) * step

        x_size = int((x_max - x_min) / step) + 1
        y_size = int((y_max - y_min) / step) + 1
        array_dev = np.full((y_size, x_size,), np.nan)
        array_id = np.full((y_size, x_size,), np.nan)
        gt = [x_min, step, 0, y_max, 0, -step]

        nbr_shot = self.nbr_shot()
        for ind_shot, shot in enumerate(self.get_shots()):
            if callback is not None:
                callback("Calcul du voronoi", ind_shot / nbr_shot)

            # Limite emprise image
            x_min_shot = np.floor(shot.extent.bounds[0] / step) * step
            y_min_shot = np.ceil(shot.extent.bounds[1] / step) * step
            x_max_shot = np.floor(shot.extent.bounds[2] / step) * step
            y_max_shot = np.ceil(shot.extent.bounds[3] / step) * step

            # grille phasée avec l'image finale
            x_grid, y_grid = np.mgrid[x_min_shot:x_max_shot + step:step, y_min_shot:y_max_shot + step:step]
            x_grid = x_grid.ravel()
            y_grid = y_grid.ravel()
            c_grid = np.int_((x_grid - x_min) / step)
            l_grid = np.int_(-(y_grid - y_max) / step)

            # calcul de ls distance plani au nadir et de la résolution
            dr = ((x_grid - shot.imc.x_pos) ** 2 + (y_grid - shot.imc.y_pos) ** 2) ** 0.5

            # Pour un point terrain donnée, on sélectionne les valeurs (dévers, résolution, ...)
            # issues de l'image avec le devers le plus faible en ce point
            ind_img = (dr == np.fmin(array_dev[l_grid, c_grid], dr))
            array_dev[l_grid[ind_img], c_grid[ind_img]] = dr[ind_img]
            array_id[l_grid[ind_img], c_grid[ind_img]] = shot.number

        img_id = gdal.GetDriverByName("GTiff").Create(str(path_voronoi), array_id.shape[1], array_id.shape[0], 1,
                                                      gdal.GDT_Int32)
        img_id.SetGeoTransform(gt)
        img_id.SetProjection(self.dem.dem.GetProjection())
        img_id.GetRasterBand(1).WriteArray(array_id)
        img_id.FlushCache()

        if callback is not None:
            callback("Calcul du voronoi raster", 1)

        return img_id

    def compute_voronoi(self, path_voronoi: Union[str, Path, None] = None, tolerance: int = 0,
                        ogr_driver: Union[str, None] = None) -> ogr.DataSource:
        """
        Compute the voronoi.

        :param path_voronoi: save path of the voronoi. If None the file is only stored in a temporary in-memory format.
        :param tolerance : snapping tolerance.
        :param ogr_driver: name of the driver to use, if not specified, the driver is guessed from the extension.

        :return: voronoi.
        """
        list_shot = list(self.get_shots())
        points = MultiPoint([(obj_shot.imc.x_pos, obj_shot.imc.y_pos) for obj_shot in list_shot])
        list_img = [obj_shot.image for obj_shot in list_shot]

        if len(list_shot) == 1:
            regions = [list_shot[0].extent]
        else:
            regions = voronoi_diagram(points, envelope=self.extent, tolerance=tolerance)

        # Sauvegarde
        driver = ogr.GetDriverByName('MEMORY')
        outDataSource_vor = driver.CreateDataSource('memData')
        dest_srs = osr.SpatialReference()
        dest_srs.ImportFromWkt(self.proj_engine.crs.to_wkt())
        layer_vor = outDataSource_vor.CreateLayer("Voronoi", dest_srs, geom_type=ogr.wkbPolygon)
        field_name = ogr.FieldDefn("Name", ogr.OFTString)
        layer_vor.CreateField(field_name)
        featureDefn = layer_vor.GetLayerDefn()
        for name, geom in zip(list_img, regions.geoms):
            geom = ogr.CreateGeometryFromWkt(geom.wkt)
            feature = ogr.Feature(featureDefn)
            feature.SetField("Name", name)
            feature.SetGeometry(geom)
            layer_vor.CreateFeature(feature)
            break
        if path_voronoi is not None:
            ogr_driver = get_ogr_driver(path_voronoi, ogr_driver)
            source = ogr_driver.CreateDataSource(str(path_voronoi))
            source.CopyLayer(layer_vor, 'Voronoi', ['OVERWRITE=YES'])

        return outDataSource_vor

    def init_euclidean_topaero(self, x_barycenter: float, y_barycenter: float) -> None:
        """
        Initiate a barycentric system

        :param x_barycenter: x coordinate of the barycenter.
        :param y_barycenter: y coordinate of the barycenter.
        """
        self._barycentric_system = EuclideanTopaero(x_barycenter, y_barycenter, self.proj_engine)

    def to_system_barycentrique(self) -> None:
        """Transform the system project into a barycentric system"""
        barycenter = self.compute_barycenter()
        self._barycentric_system = EuclideanTopaero(barycenter[0], barycenter[1], self.proj_engine)
        for shot in self.get_shots():
            shot.imc = ImageConical.from_mat(shot.imc.x_pos, shot.imc.y_pos, shot.imc.z_pos, shot.imc.mat,
                                             self.barycentric_system, shot.imc.camera, shot.imc.lock)

    def compute_barycenter(self) -> Tuple[float, float, float]:
        """Compute the barycentre of the project"""
        barycenter = np.mean(np.array([[shot.imc.x_pos, shot.imc.y_pos, shot.imc.z_pos] for shot in self.get_shots()]),
                             axis=0)
        return barycenter[0], barycenter[1], barycenter[2]

    def transform(self, proj: ProjectionList) -> None:
        """
        Tranform the project to proj coordinate reference system.

        :param proj: Projection.

        """
        if proj is None:
            return

        old_proj_engine = self.proj_engine
        new_proj_engine = ProjEngine(proj)
        pyproj_transform = pyproj.Transformer.from_crs(old_proj_engine.crs, new_proj_engine.crs).transform
        self._proj_engine = new_proj_engine

        # Project
        if self.barycentric_system is not None:
            x_bary, y_bary = pyproj_transform(self.barycentric_system.x_central, self.barycentric_system.y_central)
            self._barycentric_system = EuclideanTopaero(x_bary, y_bary, self.proj_engine)
            if not self.extent.is_empty:
                self.extent = transform(pyproj_transform, self.extent)

        for flight in self.get_flights():
            if not flight.extent.is_empty:
                flight.extent = transform(pyproj_transform, flight.extent)

            for strip in flight.get_strips():
                if not strip.extent.is_empty:
                    strip.extent = transform(pyproj_transform, strip.extent)

                for shot in strip.get_shots():
                    x_pos_new, y_pos_new = pyproj_transform(shot.imc.x_pos, shot.imc.y_pos)
                    x_nadir_new, y_nadir_new = pyproj_transform(shot.imc.x_nadir, shot.imc.y_nadir)
                    system = self.barycentric_system if self.barycentric_system is not None else EuclideanTopaero(
                        x_pos_new, y_pos_new, self.proj_engine)
                    shot.imc.system.rot_to_euclidean_local = system.rot_to_euclidean_local
                    mat_eucli = shot.imc.system.mat_to_mat_eucli(shot.imc.x_pos, shot.imc.y_pos, shot.imc.mat)
                    shot.imc = ImageConical.from_mat_eucli(x_pos_new, y_pos_new, shot.imc.z_pos, mat_eucli, system,
                                                           shot.imc.camera,
                                                           dict_syst=shot.imc.dict_syst)
                    shot.imc.x_nadir = x_nadir_new
                    shot.imc.y_nadir = y_nadir_new
                    if not shot.extent.is_empty:
                        shot.extent = transform(pyproj_transform, shot.extent)

    def remove_scale_factor(self) -> None:
        """Remove factor scale correction"""
        for shot in self.get_shots():
            shot.imc.z_pos = shot.imc.get_Z_remove_scale_factor(self.dem)

    def add_scale_factor(self) -> None:
        """Add factor scale correction"""
        for shot in self.get_shots():
            shot.imc.z_pos = shot.imc.get_Z_add_scale_factor(self.dem)

    def get_shots(self, filter_flight: Union[Callable[[Flight], bool], None] = None,
                  filter_strip: Union[Callable[[Strip], bool], None] = None,
                  filter_shot: Union[Callable[[Shot], bool], None] = None) -> Iterator[Shot]:
        """
        Return an iterator of shots.
        Elements can be filtered with filter_flight, filter_strip and filter_shot functions.

        :param filter_flight: function used to filter a flight
        :param filter_strip: function used to filter a strip
        :param filter_shot: function used to filter a shot

        :return: iterator of shots.
        """

        return (shot for flight in self.get_flights(filter_flight) for shot in
                flight.get_shots(filter_strip, filter_shot))

    def get_flights(self, filter_flight: Union[Callable[[Flight], bool], None] = None) -> Iterator[Flight]:
        """
        Return an iterator of flights.
        Elements can be filtered with filter_flight functions.

        :param filter_flight: function used to filter a flight

        :return: iterator of flights.
        """
        return filter(filter_flight, self.flight.values())

    def find_shot(self, image) -> Shot:
        """
        Return shot corresponding to the name.

        :return: The shot with the wanted name.
        """
        for flight in self.flight.values():
            for strip in flight.strip.values():
                if image in strip.shot:
                    return strip.shot[image]

    def compute_intersection(self, name_shot: List[str], c: Union[List, np.array], l: Union[List, np.array],
                             prec: int = 0.001, iter_max: int = 10):
        """
        Compute the intersection point from image measures.

        :param name_shot: list of image names
        :param c: column coordinates of image points
        :param l: line coordinates of image points
        :param prec: accuracy
        :param iter_max: maximum number of iterations
        """

        # Il faut au moins deux points pour calculer une intersection
        if len(name_shot) < 2:
            return np.nan, np.nan, np.nan

        # Initialisation des coord du point en projetant le point image sur un Z = 0 avec l'orientation de l'image 1
        pt_comp = np.array(self.find_shot(name_shot[0]).imc.image_to_world(c[0], l[0], 0))
        mat_obs = np.empty((len(c) * 2, 3))
        v_res = np.empty(len(c) * 2)
        dx = np.array([10, 10, 10])
        nbr_iter = 0
        while not np.all(abs(dx) < prec) and nbr_iter < iter_max:
            for ind, (img, ci, li) in enumerate(zip(name_shot, c, l)):
                shot = self.find_shot(img)
                pt_img = np.array(shot.imc.world_to_image(*pt_comp))
                dif = pt_comp - shot.imc.sommet
                U = shot.imc.mat_eucli @ dif
                V = np.array([[1, 0, -U[0] / U[2]],
                              [0, 1, -U[1] / U[2]]])
                P1 = V @ shot.imc.mat_eucli
                P1 *= shot.imc.camera.focal / U[2]
                v_res[2 * ind: 2 * ind + 2] = np.array([ci, li]) - pt_img
                mat_obs[2 * ind:2 * ind + 2, :] = P1
            nbr_iter += 1
            dx = np.linalg.lstsq(mat_obs, v_res, rcond=None)[0]
            pt_comp += dx
        return pt_comp[0], pt_comp[1], pt_comp[2]

    def filter(self, filter_flight: Union[Callable[[Flight], bool], None] = None,
               filter_strip: Union[Callable[[Strip], bool], None] = None,
               filter_shot: Union[Callable[[Shot], bool], None] = None) -> None:
        """
        Filter the object from those elements of Ta for which filter_flight, filter_strip
        and filter_shot functions returns true
        The filter_flight function is applied to each filght.
        The filter_strip function is applied to each strip.
        The filter_shot function is applied to each shot.

        :param filter_flight: function used to filter a flight
        :param filter_strip: function used to filter a strip
        :param filter_shot: function used to filter a shot
        """
        if filter_flight is not None:
            for flight in list(self.get_flights(lambda f: not filter_flight(f))):
                self.remove_flight(flight)
        for flight in list(self.get_flights()):
            flight.filter(filter_strip, filter_shot)
            if flight.nbr_strip() == 0:
                self.remove_flight(flight)

    def print(self) -> str:
        """
        Print project information.

        :return: project information.
        """
        txt = ""
        for key, val in vars(self).items():
            key = key.replace("_", "")
            if key not in ["flight", "dict_project", "camera"]:
                txt += "{} : {}\n".format(key, val)
        return txt

    def get_json(self) -> str:
        """
        Return project information in a json format.

        :return: project information.
        """
        dict_temp = {}
        for key, val in vars(self).items():
            key = key.replace("_", "")
            if key not in ["flight", "dict_project", "camera"]:
                dict_temp[key] = val
        return json.dumps(dict_temp)

    def __deepcopy__(self, memodict) -> Project:
        """Create a deepcopy of the Project object."""
        cls = self.__class__
        result = cls.__new__(cls)
        memodict[id(self)] = result
        for k, v in self.__dict__.items():
            if k == "_dem":
                setattr(result, k, v)
            else:
                setattr(result, k, deepcopy(v, memodict))
        return result

    def __getattr__(self, name):
        return self._dict_project.get(name, "")
