"""A module for manipulating an aerial imagery acquisition flight."""

from __future__ import annotations

import json
from copy import deepcopy
from datetime import datetime
from typing import Union, Any, Callable, Dict, Iterator
from shapely import Polygon, MultiPolygon

import numpy as np
from pysocle.photogrammetry.strip import Strip
from pysocle.photogrammetry.shot import Shot
from pysocle.altimetry.dem import Dem


class Flight:
    """
    Represents an aerial imagery acquisition flight.

    .. note::
        :class:`Flight` is not supposed to be instantiated by users. You most likely need to use
        :class:`pysocle.photogrammetry.ta.Ta`.
    """

    def __init__(self):
        self._number = np.nan
        self._logname = ""
        self._mission = ""
        self._date = datetime.strptime("1012020", "%d%m%Y")
        self._active = True
        self._quality = 0
        self._system_sensor = {}
        self._strip = {}
        self._extent = Polygon()
        self._dict_flight = {}

    @classmethod
    def from_dict(cls, dict_flight: dict) -> Flight:
        """
        Create a flight object from a dictionary.

        :param dict_flight: dictonary of the flight.
        :return: A strip object.

        """
        obj = cls()
        obj.number = dict_flight.get("number", np.nan)
        obj.logname = dict_flight.get("logname", "")
        obj.mission = dict_flight.get("mission", "")
        obj.date = dict_flight.get("date", None)
        obj.active = dict_flight.get("actif", True)
        obj.quality = dict_flight.get("qualite", 0)
        obj.system_sensor = {"actif": dict_flight.get("system_sensor", {}).get("actif", ""),
                             "avion": dict_flight.get("system_sensor", {}).get("avion", ""),
                             "omega": dict_flight.get("system_sensor", {}).get("omega", ""),
                             "phi": dict_flight.get("system_sensor", {}).get("phi", ""),
                             "kappa": dict_flight.get("system_sensor", {}).get("kappa", ""),
                             "refraction": dict_flight.get("system_sensor", {}).get("refraction", ""),
                             "trappe": dict_flight.get("system_sensor", {}).get("trappe", ""),
                             "rattachement_antenne": {
                                 "x": dict_flight.get("system_sensor", {}).get("rattachement_antenne", {}).get("pt3d",
                                                                                                               {}).get(
                                     "x", ""),
                                 "y": dict_flight.get("system_sensor", {}).get("rattachement_antenne", {}).get("pt3d",
                                                                                                               {}).get(
                                     "y", ""),
                                 "z": dict_flight.get("system_sensor", {}).get("rattachement_antenne", {}).get("pt3d",
                                                                                                               {}).get(
                                     "z", "")},
                             "sensor": dict_flight.get("system_sensor", {}).get("sensor", {}).get("origine", "")}
        obj.dict_flight = dict_flight
        return obj

    @property
    def number(self) -> int:
        """
        Flight number.

        :getter: Returns the flight number.
        :setter: Sets the flight number.
        """
        return self._number

    @number.setter
    def number(self, number):
        try:
            self._number = int(number)
        except ValueError:
            raise ValueError("Flight number must be a int")

    @property
    def logname(self) -> str:
        """
        Flight logname.

        :getter: Returns the flight logname.
        :setter: Sets the flight logname.
        """
        return self._logname

    @logname.setter
    def logname(self, logname):
        try:
            self._logname = str(logname)
        except ValueError:
            raise ValueError("Flight number must be a str")


    @property
    def mission(self) -> str:
        """
        Flight mission.

        :getter: Returns the flight mission.
        :setter: Sets the flight mission.
        """
        return self._mission

    @mission.setter
    def mission(self, mission):
        try:
            self._mission = str(mission)
        except ValueError:
            raise ValueError("Flight mission must be a str")

    @property
    def date(self) -> datetime:
        """
        The date of the flight.

        :getter: Returns the date of the flight
        :setter: Sets the date of the flight
        """
        return self._date

    @date.setter
    def date(self, date):
        if isinstance(date, datetime) or date is None:
            self._date = date
        else:
            raise ValueError("La date doit être un objet datetime")

    @property
    def active(self) -> int:
        """
        Flight activity.

        :getter: Returns the flight activity.
        :setter: Sets the flight activity.
        """
        return self._active

    @active.setter
    def active(self, active):
        try:
            self._active = bool(int(active))
        except ValueError:
            raise ValueError("Flight active must be a bool")

    @property
    def quality(self) -> int:
        """
        Flight quality.

        :getter: Returns the flight quality.
        :setter: Sets the flight quality.
        """
        return self._quality

    @quality.setter
    def quality(self, quality):
        try:
            self._quality = int(quality)
        except ValueError:
            raise ValueError("Flight quality must be a int")

    @property
    def system_sensor(self) -> dict:
        """
        The sensor system of the flight.

        :getter: Returns the system sensor of the flight
        :setter: Sets the system sensor of the flight
        """
        return self._system_sensor

    @system_sensor.setter
    def system_sensor(self, system_sensor):
        self._system_sensor = dict(system_sensor)

    @property
    def strip(self) -> Dict[int, Strip]:
        """
        The strips of the flight.

        :getter: Returns the strips of the flight
        :setter: Not available
        """
        return self._strip

    def add_strip(self, strip: Strip) -> None:
        """
        Add a strip to the flight.

        :param strip: strip to be added.
        """
        if not isinstance(strip, Strip):
            raise ValueError("La bande doit être du type Strip")
        self.strip[strip.axe] = strip

    def remove_strip(self, strip: Union[int, Strip]) -> None:
        """
        Remove a strip from the flight.

        :param strip: strip to be removed.
        """
        if isinstance(strip, Strip):
            self.strip.pop(strip.axe, None)
        else:
            self.strip.pop(strip, None)

    @property
    def extent(self) -> Polygon:
        """
        Flight extent.

        :getter: Returns the flight extent.
        :setter: Sets the flight extent.
        """
        return self._extent

    @extent.setter
    def extent(self, extent):
        if isinstance(extent, Polygon) or isinstance(extent, MultiPolygon):
            self._extent = extent
        else:
            raise ValueError(f"Flight extent must be a shapely.Polygon not a {type(extent)}")

    def nbr_shot(self) -> int:
        """
        Returns the number of shots in the flight.

        :return: the number of shots in the flight.
        """
        return sum(strip.nbr_shot() for strip in self.strip.values())

    def get_shots(self, filter_strip: Union[Callable[[Strip], bool], None] = None,
               filter_shot: Union[Callable[[Shot], bool], None] = None) -> Iterator[Shot]:
        """
        Return an iterator of shots.
        Elements can be filtered with filter_strip and filter_shot functions.

        :param filter_strip: function used to filter a strip
        :param filter_shot: function used to filter a shot

        :return: iterator of shots.
        """
        return (shot for strip in self.get_strips(filter_strip) for shot in strip.get_shots(filter_shot))

    def get_strips(self, filter_strip: Union[Callable[[Strip], bool], None] = None) -> Iterator[Strip]:
        """
        Return an iterator of strips.
        Elements can be filtered with filter_strip functions.

        :return: iterator of strips.
        """
        return filter(filter_strip, self.strip.values())

    def filter(self, filter_strip: Union[Callable[[Strip], bool], None] = None,
                     filter_shot: Union[Callable[[Shot], bool], None] = None) -> None:
        """
        Filter the object from those elements of Flight for which filter_strip
        and filter_shot functions returns true
        The filter_strip function is applied to each strip.
        The filter_shot function is applied to each shot.

        :param filter_strip: function used to filter a strip
        :param filter_shot: function used to filter a shot
        """
        if filter_strip is not None:
            for strip in list(self.get_strips(lambda s: not filter_strip(s))):
                self.remove_strip(strip)
        for strip in list(self.get_strips()):
            strip.filter(filter_shot)
            if strip.nbr_shot() == 0:
                self.remove_strip(strip)

    def nbr_strip(self) -> int:
        """
        Returns the number of strips in the flight.

        :return: the number of strips in the flight.
        """
        return len(self.strip)

    def change_active(self) -> None:
        """Change the activity of the flight."""
        self.active = not self.active

    def compute_kappa(self) -> None:
        """Compute the kappa of all strips in the flight."""
        for strip in self.strip.values():
            strip.compute_kappa()

    def init_kappa(self) -> None:
        """Initiate the kappa of all images in the flight."""
        for strip in self.strip.values():
            strip.init_kappa()

    def compute_extent(self, dem: Dem, recompute: bool = False, pnt_side: int = 4, prec: float = 1., iter_max: int = 2,
                       callback: Union[Callable[[str, float], Any], None] = None) -> None:
        """
        Compute the flight extent. If recompute is False, extents are not recomputed if exists.

        :param dem: Dem of the area
        :param recompute: recomputre all extent
        :param pnt_side: number of point in the extent between two corners
        :param prec: accuracy
        :param iter_max: number of iterations
        :param callback: Progress callback.
        """
        flight_extent = Polygon()
        nbr_strip = len(self.strip)
        for ind_strip, strip in enumerate(self.strip.values()):
            if strip.extent is None or recompute:
                callback_flight = lambda step, val: callback(f"Bande {ind_strip+1}/{nbr_strip} {step}", val) if callback is not None else None
                strip.compute_extent(dem, recompute, pnt_side, prec, iter_max, callback = callback_flight)
            if flight_extent.is_empty:
                flight_extent = strip.extent
            else:
                flight_extent = flight_extent.union(strip.extent)
        self.extent = flight_extent


    def compute_sun_height(self, callback: Union[Callable[[str, float], Any], None] = None) -> None:
        """
        Compute the sun height of all images in the flight.

        :param callback: Progress callback.
        """
        nbr_shot = self.nbr_shot()
        for ind_shot, shot in enumerate(self.get_shots()):
            if callback is not None:
                callback("Calcul de la hauteur solaire", ind_shot/nbr_shot)
            shot.compute_sun_height()

    def print(self) -> str:
        """
        Print flight information.

        :return: Flight information.
        """
        txt = ""
        for key, val in vars(self).items():
            key = key.replace("_", "")
            if key not in ["strip", "dict_flight"]:
                txt += "{} : {}\n".format(key, val)
        return txt

    def get_json(self) -> str:
        """
        Return flight information in a json format.

        :return: flight information.
        """
        dict_temp = {}
        for key, val in vars(self).items():
            key = key.replace("_", "")
            if key not in ["strip", "dict_flight", "date"]:
                dict_temp[key] = val
            elif key == "date":
                dict_temp[key] = val.strftime("%d-%m-%Y")

        return json.dumps(dict_temp)

    # def __getattr__(self, name):
    #     return self.dict_flight.get(name, "")

    def __deepcopy__(self, memodict) -> Flight:
        """Create a deepcopy of the Project object."""
        cls = self.__class__
        result = cls.__new__(cls)
        memodict[id(self)] = result
        for k, v in self.__dict__.items():
            setattr(result, k, deepcopy(v, memodict))
        return result
