"""A module for manipulating an aerial imagery acquisition strip."""

from __future__ import annotations

import xml.etree.ElementTree as ET
from copy import deepcopy
from datetime import datetime
from pathlib import Path
from typing import Union, Tuple, List
from shapely import Polygon

import numpy as np
from pysocle.altimetry.dem import Dem
from pysocle.geodesy.euclidean_topaero import EuclideanTopaero
from pysocle.geodesy.proj_engine import ProjEngine
from pysocle.geodesy.projection_list import ProjectionList
from pysocle.orientation.image_conical import ImageConical
from pysocle.orientation.rpc import Rpc
from pysocle.orientation.space_resection import space_resection
from pysocle.photogrammetry.camera import Camera
from pysocle.utils.diverse import indent, etree_to_dict
#from pysocle.pysolar.solar import get_altitude


class Shot:
    """
    Represents an aerial imagery acquisition shot.

    .. note:: :class:`Shot` is not supposed to be instantiated by users. You most likely need to use
    :class:`pysocle.photogrammetry.ta.Ta`.
    """

    def __init__(self):
        self._image = ""
        self._number = 0
        self._active = True
        self._zi = False
        self._quality = 0
        self._note = ""
        self._t = datetime.strptime("01/01/2020 00:00:00", "%d/%m/%Y %H:%M:%S")
        self._sun_height = 0
        self._shutter = 0
        self._fnumber = 0
        self._section = 1.
        self._style = 1
        self._resolution_mean = np.nan
        self._resolution_min = np.nan
        self._resolution_max = np.nan
        self._overlap = np.nan
        self._overlap_prev = np.nan
        self._overlap_next = np.nan
        self._sidelap_prev = np.nan
        self._sidelap_next = np.nan
        self._shot_next = None
        self._shot_prev = None
        self._trajecto = (np.nan, np.nan, np.nan)
        self._indicator = {}
        self._platf_info = {}
        self._imc = None
        self._systbde = {}
        self._extent = None
        self._dict_shot = {}

    @classmethod
    def from_dict(cls, dict_shot):
        """
            Create a shot object from a dictionary.

            :param dict_shot: dictonary.
            :type dict_shot: dict
            :return: A shot object.
            :rtype: Shot

        """
        obj = cls()
        obj.image = dict_shot.get("image", "")
        obj.number = dict_shot.get("number", 0)
        obj.active = dict_shot.get("actif", True)
        obj.zi = dict_shot.get("zi", False)
        obj.quality = dict_shot.get("qualite", 0)
        obj.t = dict_shot.get("time", None)
        obj.sun_height = dict_shot.get("sun_height", 0)
        obj.shutter = dict_shot.get("pose", 0)
        obj.fnumber = dict_shot.get("fnumber", 0)
        obj.section = dict_shot.get("section", 0)
        obj.style = dict_shot.get("style", 0)
        obj.resolution_mean = dict_shot.get("resolution_moy", np.nan)
        obj.resolution_min = dict_shot.get("resolution_min", np.nan)
        obj.resolution_max = dict_shot.get("resolution_max", np.nan)
        obj.overlap = dict_shot.get("overlap", np.nan)
        obj.overlap_prev = dict_shot.get("overlap_max", np.nan)
        obj.overlap_next = dict_shot.get("overlap_min", np.nan)
        obj.extent = dict_shot.get("polygon2d", None)
        obj.init_imc({"x_pos": float(dict_shot.get("model", {}).get("pt3d", {}).get("x", np.nan)),
                   "y_pos": float(dict_shot.get("model", {}).get("pt3d", {}).get("y", np.nan)),
                   "z_pos": float(dict_shot.get("model", {}).get("pt3d", {}).get("z", np.nan)),
                   "x_nadir": float(dict_shot.get("nadir", {}).get("pt3d", {}).get("x", np.nan)),
                   "y_nadir": float(dict_shot.get("nadir", {}).get("pt3d", {}).get("y", np.nan)),
                   "z_nadir": float(dict_shot.get("nadir", {}).get("pt3d", {}).get("z", np.nan)),
                   "quaternion": np.array([float(dict_shot.get("model", {}).get("quaternion", {}).get("x", np.nan)),
                                           float(dict_shot.get("model", {}).get("quaternion", {}).get("y", np.nan)),
                                           float(dict_shot.get("model", {}).get("quaternion", {}).get("z", np.nan)),
                                           float(dict_shot.get("model", {}).get("quaternion", {}).get("w", np.nan))]),
                   "opk": np.array([float(dict_shot.get("model", {}).get("opk", {}).get("omega", np.nan)),
                                    float(dict_shot.get("model", {}).get("opk", {}).get("phi", np.nan)),
                                    float(dict_shot.get("model", {}).get("opk", {}).get("kappa", np.nan))]),
                   "proj_engine": dict_shot.get("model", {}).get("proj_engine", None),
                   "repere": dict_shot.get("repere", None),
                   "camera": dict_shot.get("model", {}).get("camera", None),
                   "lock": dict_shot.get("model", {}).get("lock", 1),
                   "syst": dict_shot.get("model", {}).get("systbde", None)})
        obj.trajecto = {"x": dict_shot.get("trajecto", {}).get("pt3d", {}).get("x", np.nan),
                        "y": dict_shot.get("trajecto", {}).get("pt3d", {}).get("y", np.nan),
                        "z": dict_shot.get("trajecto", {}).get("pt3d", {}).get("z", np.nan)}
        obj.indicator = {"value": dict_shot.get("indicator", {}).get("value", "1.00000"),
                         "type": dict_shot.get("indicator", {}).get("type", "")}
        obj.platf_info = {"B": dict_shot.get("platf_info", {}).get("B", ""),
                          "E": dict_shot.get("platf_info", {}).get("E", ""),
                          "D": dict_shot.get("platf_info", {}).get("D", "")}
        obj.dict_shot = dict_shot
        obj.dict_shot = dict_shot
        return obj

    @property
    def image(self) -> str:
        """
        Shot name

        :getter: Returns the shot name
        :setter: Sets the shot name
        :type: str
        """
        return self._image

    @image.setter
    def image(self, image: str):
        try:
            self._image = str(image)
        except ValueError:
            raise ValueError("Image value must be a str")

    @property
    def number(self) -> int:
        """
        Shot number.

        :getter: Returns the shot number.
        :setter: Sets the shot number.
        """
        return self._number

    @number.setter
    def number(self, number: int):
        try:
            self._number = int(number)
        except ValueError:
            raise ValueError("Shot number must be a int")

    @property
    def active(self):
        """
        The activity of the shot.

        :getter: Returns the activity of the shot
        :setter: Sets the activity of the shot
        """
        return self._active

    @active.setter
    def active(self, active):
        try:
            self._active = bool(int(active))
        except ValueError:
            raise ValueError("Active value must be a bool")

    @property
    def zi(self) -> bool:
        """
        True if the shot contains a ZIPVA

        :getter: Returns zi
        :setter: Sets zi
        """
        return self._zi

    @zi.setter
    def zi(self, zi: bool):
        try:
            self._zi = bool(int(zi))
        except ValueError:
            raise ValueError("Zi value must be a bool")

    @property
    def quality(self) -> int:
        """
        The quality of the shot.

        :getter: Returns the quality of the shot
        :setter: Sets the quality of the shot
        :type: int
        """
        return self._quality

    @quality.setter
    def quality(self, quality: int):
        try:
            self._quality = int(quality)
        except ValueError:
            raise ValueError("Quality value must be a int")

    @property
    def note(self) -> str:
        """
        Information about the shot

        :getter: Returns info about the shot
        :setter: Sets info about the shot
        :type: int
        """
        return self._note

    @note.setter
    def note(self, note: str):
        try:
            self._note = str(note)
        except ValueError:
            raise ValueError("Note value must be a str")

    @property
    def t(self) -> datetime:
        """
         Shot time.

        :getter: Returns the shot time.
        :setter: Sets the shot time.
        :type: time
        """
        return self._t

    @t.setter
    def t(self, t: datetime):
        if isinstance(t, datetime) or t is None:
            self._t = t
        else:
            raise ValueError("t value must be a datetime")

    @property
    def sun_height(self) -> float:
        """
         Sun height of the shot

        :getter: Returns the sun height of the shot
        :setter: Sets the sun height of the shot
        """

        return self._sun_height

    @sun_height.setter
    def sun_height(self, sun_height: float):
        try:
            self._sun_height = float(sun_height)
        except ValueError:
            raise ValueError("Sun height must be a float")

    @property
    def shutter(self) -> float:
        """
         Shutter speed of the shot

        :getter: Returns the shutter speed of the shot
        :setter: Sets the shutter speed of the shot
        """
        return self._shutter

    @shutter.setter
    def shutter(self, shutter: float):
        try:
            self._shutter = float(shutter)
        except ValueError:
            raise ValueError("Shutter must be a float")

    @property
    def fnumber(self) -> float:
        """
         The f-number of the shot

        :getter: Returns the f-number of the shot
        :setter: Sets the f-number of the shot
        """
        return self._fnumber

    @fnumber.setter
    def fnumber(self, fnumber: float):
        try:
            self._fnumber = float(fnumber)
        except ValueError:
            raise ValueError("fnumber must be a float")

    @property
    def section(self) -> float:
        """
         The number of section of the shot

        :getter: Returns the number of section of the shot
        :setter: Sets the number of section of the shot
        """
        return self._section

    @section.setter
    def section(self, section : float):
        try:
            self._section = float(section)
        except ValueError:
            raise ValueError("section must be a float")

    @property
    def style(self) -> int:
        """
         The style of the shot

        :getter: Returns the style of the shot
        :setter: Sets the style of the shot
        :type: float
        """
        return self._style

    @style.setter
    def style(self, style : int):
        try:
            self._style = int(style)
        except ValueError:
            raise ValueError("Style must be a int")

    @property
    def resolution_mean(self) -> float:
        """
        The mean resolution of the shot.

        :getter: Returns the mean resolution of the shot
        :setter: Sets the mean resolution of the shot
        """
        return self._resolution_mean

    @resolution_mean.setter
    def resolution_mean(self, resolution_mean: float):
        try:
            self._resolution_mean = float(resolution_mean)
        except ValueError:
            raise ValueError("Mean resolution must be a int")

    @property
    def resolution_min(self) -> float:
        """
        The minimal resolution of the shot.

        :getter: Returns the minimal resolution of the shot
        :setter: Sets the minimal resolution of the shot
        """
        return self._resolution_min

    @resolution_min.setter
    def resolution_min(self, resolution_min: float):
        try:
            self._resolution_min = float(resolution_min)
        except ValueError:
            raise ValueError("Min resolution must be a int")

    @property
    def resolution_max(self) -> float:
        """
        The maximal resolution of the shot.

        :getter: Returns the maximal resolution of the shot
        :setter: Sets the maximal resolution of the shot
        """
        return self._resolution_max

    @resolution_max.setter
    def resolution_max(self, resolution_max: float):
        try:
            self._resolution_max = float(resolution_max)
        except ValueError:
            raise ValueError("Max resolution must be a int")

    @property
    def overlap(self) -> float:
        """
        The mean overlap of the shot.

        :getter: Returns the mean overlap of the shot
        :setter: Sets the mean overlap of the shot
        """
        return self._overlap

    @overlap.setter
    def overlap(self, overlap: float):
        try:
            self._overlap = float(overlap)
        except ValueError:
            raise ValueError("Overlap resolution must be a float")

    @property
    def overlap_prev(self) -> float:
        """
        The overlap of the shot with the previous shot.

        :getter: Returns the overlap of the shot with the previous shot
        :setter: Sets the overlap of the shot with the previous shot
        """
        return self._overlap_prev

    @overlap_prev.setter
    def overlap_prev(self, overlap_prev: float):
        try:
            self._overlap_prev = float(overlap_prev)
        except ValueError:
            raise ValueError("Previous overlap resolution must be a float")

    @property
    def overlap_next(self) -> float:
        """
        The overlap of the shot with the next shot.

        :getter: Returns the overlap of the shot with the next shot
        :setter: Sets the overlap of the shot with the next shot
        """
        return self._overlap_next

    @overlap_next.setter
    def overlap_next(self, overlap_next : float):
        try:
            self._overlap_next = float(overlap_next)
        except ValueError:
            raise ValueError("Next overlap resolution must be a float")

    @property
    def sidelap_prev(self) -> float:
        """
        The sidelap of the shot with the previous strip.

        :getter: Returns the sidelap of the shot with the previous strip.
        :setter: Sets the sidelap of the shot with the previous strip.
        """
        return self._sidelap_prev

    @sidelap_prev.setter
    def sidelap_prev(self, sidelap_prev: float):
        try:
            self._sidelap_prev = float(sidelap_prev)
        except ValueError:
            raise ValueError("Previous sidelap resolution must be a float")

    @property
    def sidelap_next(self) -> float:
        """
        The sidelap of the shot with the next strip.

        :getter: Returns the sidelap of the shot with the next strip
        :setter: Sets the sidelap of the shot with the next strip
        """
        return self._sidelap_next

    @sidelap_next.setter
    def sidelap_next(self, sidelap_next: float):
        try:
            self._sidelap_next = float(sidelap_next)
        except ValueError:
            raise ValueError("Next sidelap resolution must be a float")

    @property
    def shot_next(self) -> Union[Shot, None]:
        """
        The next shot

        :getter: Returns the next shot
        :setter: Sets the next shot
        """
        return self._shot_next

    @shot_next.setter
    def shot_next(self, shot_next: Union[Shot, None]):
        if isinstance(shot_next, Shot) or shot_next is None:
            self._shot_next = shot_next
        else:
            raise ValueError("Next shot must be a Shot")

    @property
    def shot_prev(self) -> Union[Shot, None]:
        """
        The previous shot

        :getter: Returns the previous shot
        :setter: Sets the previous shot
        """
        return self._shot_prev

    @shot_prev.setter
    def shot_prev(self, shot_prev: Union[Shot, None]):
        if isinstance(shot_prev, Shot) or shot_prev is None:
            self._shot_prev = shot_prev
        else:
            raise ValueError("Previous shot must be a Shot")

    @property
    def trajecto(self) -> Tuple[float, float, float]:
        """
        The trajectography of the shot (geographic coordinates)

        :getter: Returns the trajectography of the shot
        :setter: Sets the trajectography of the shot
        """
        return self._trajecto

    @trajecto.setter
    def trajecto(self, trajecto: Tuple[float, float, float]):
        try:
            self._trajecto = tuple(trajecto)
        except ValueError:
            raise ValueError("Trajecto must be a tuple of float")

    @property
    def indicator(self) -> dict:
        """
        The indicator of the shot (??? in the ta.xml)

        :getter: Returns the indicator of the shot
        :setter: Sets the indicator of the shot
        """
        return self._indicator

    @indicator.setter
    def indicator(self, indicator: dict):
        try:
            self._indicator = dict(indicator)
        except ValueError:
            raise ValueError("Indicator must be a dict")

    @property
    def platf_info(self) -> dict:
        """
        The platf info of the shot (??? in the ta.xml)

        :getter: Returns the platf info of the shot
        :setter: Sets platf info of the shot
        """
        return self._platf_info

    @platf_info.setter
    def platf_info(self, platf_info: dict):
        try:
            self._platf_info = dict(platf_info)
        except ValueError:
            raise ValueError("Value info must be a dict")

    @property
    def systbde(self) -> dict:
        """
        The systmetism of the shot

        :getter: Returns the systematism of the shot
        :setter: Sets systematism of the shot
        :type: dict
        """
        return self._systbde

    @systbde.setter
    def systbde(self, systbde : dict):
        try:
            self._systbde = dict(systbde)
        except ValueError:
            raise ValueError("systbde info must be a dict")

    @property
    def extent(self) -> Polygon:
        """
        Extent of the project

        :getter: Returns extent
        :setter: Sets extent
        """
        return self._extent

    @extent.setter
    def extent(self, extent: Polygon):
        if isinstance(extent, Polygon):
            self._extent = extent
        elif isinstance(extent, dict):
            self._extent = Polygon([(x,y) for x, y in extent["emprise"]])

    @property
    def polygon2d(self) -> dict:
        """Return the dict of the extent (ta.xml)"""
        list_point = self.extent.exterior.coords[:-1]
        return {"nb_pt": len(list_point), "emprise": list_point}

    @property
    def imc(self) -> ImageConical:
        """
        The conical geometry of the shot

        :getter: Returns the conical geometry of the shot
        :setter: Sets the conical geometry of the shot
        """
        return self._imc

    @imc.setter
    def imc(self, imc: ImageConical):
        if isinstance(imc, ImageConical):
            self._imc = imc
        else:
            raise ValueError("imc must be a ImageConical")

    def init_imc(self, model: dict) -> None:
        """
        Initate the conical model

        :param model: model
        """
        # On est dans le cas du repère euclidien locale centrée sur le cliché
        if model["repere"] is None:
            system = EuclideanTopaero(model["x_pos"], model["y_pos"], model["proj_engine"])
        else:
            system = model["repere"]

        # Modèle OPK
        if np.any(np.isnan(model["quaternion"])):
            self.imc = ImageConical.from_opk(model["x_pos"], model["y_pos"], model["z_pos"],
                                             model["x_nadir"], model["y_nadir"], model["z_nadir"],
                                             model["opk"], system, model["camera"], model["lock"])

        # Modèle quaternion -> TA.xml
        else:
            if model["syst"] is not None and int(model["syst"]["type"]) == 3:
                dict_syst = {"id": 3, "type": "systematismeCylindriqueTopAero", "isinterne": "true", "C0": "0",
                             "L0": "0", "S1": float(model["syst"]["CylA"]), "S2": float(model["syst"]['CylB'])}
            else:
                dict_syst = None

            self.imc = ImageConical.from_quaternion(model["x_pos"], model["y_pos"], model["z_pos"],
                                                    model["x_nadir"], model["y_nadir"], model["z_nadir"],
                                                    model["quaternion"], system, model["camera"], model["lock"],
                                                    dict_syst)

    def compute_extent(self, dem: Dem, pnt_side: int = 4, prec: float = 1., iter_max: int = 2) -> None:
        """
        Compute the shot extent

        :param dem: Dem of the area.
        :param pnt_side: number of point in the extent between two corners.
        :param prec: accuracy.
        :param iter_max: maximum number of iterations.
        """
        self.extent = self.imc.compute_extent(dem, pnt_side, prec, iter_max)

    def compute_nadir(self, dem: Dem) -> None:
        """
        Compute the shot nadir.

        :param dem: Dem of the area.
        """
        self.imc.compute_nadir(dem)

    def to_absolute(self, dem: Dem, size_grid, method) -> None:
        """
        Estimate the best parameters for the conical model without any systematism.

        :param dem: Dem of the area
        :param size_grid: grid step length in which the ori parameters will be estimated.
        :param method: computing method
        """
        self.imc = space_resection(self, dem, size_grid, method)

    def print(self) -> str:
        """
        Print shot information.

        :return: Shot information.
        """
        txt = ""
        for key, val in vars(self).items():
            key = key.replace("_", "")
            if key not in ["dict_shot"]:
                txt += "{} : {}\n".format(key, val)
        return txt

    def change_active(self) -> None:
        """Change the activity of the shot."""
        self.active = not self.active

    def compute_sun_height(self) -> None:
        """Compute the sun height of the shot."""
        longitude, latitude, _ = self.imc.system.proj_engine.carto_to_geog(self.imc.x_pos, self.imc.y_pos, self.imc.z_pos)
        self.sun_height = get_altitude(latitude, longitude, self.t)*np.pi/180

    @classmethod
    def from_conl(cls, path_conl: Union[Path, str], dem: Union[Dem, Path, str]) -> Shot:
        if not isinstance(dem, Dem):
            dem = Dem(dem)

        tree = ET.parse(path_conl)
        root = tree.getroot()
        dict_conl = etree_to_dict(root)

        try:
            date_shot = datetime.strptime(
                dict_conl["auxiliarydata"]["image_date"]["day"] + "/" + dict_conl["auxiliarydata"]["image_date"][
                    "month"] + "/" + dict_conl["auxiliarydata"]["image_date"]["year"] + " " +
                dict_conl["auxiliarydata"]["image_date"]["hour"] + ":" + dict_conl["auxiliarydata"]["image_date"][
                    "minute"] + ":" + dict_conl["auxiliarydata"]["image_date"]["second"], "%d/%m/%y %H:%M:%S")
        except ValueError:
            date_shot = datetime.strptime("01/01/2020 00:00:00", "%d/%m/%Y %H:%M:%S")

        proj_engine = ProjEngine(
            ProjectionList.from_ta(dict_conl["geometry"]["extrinseque"]["systeme"]["geodesique"].strip()))

        x = float(dict_conl["geometry"]["extrinseque"]["systeme"]["euclidien"]["x"])
        y = float(dict_conl["geometry"]["extrinseque"]["systeme"]["euclidien"]["y"])
        z = float(dict_conl["geometry"]["extrinseque"]["sommet"]["altitude"])

        mat_rot = np.empty((3, 3))
        mat_rot[0][0] = float(dict_conl["geometry"]["extrinseque"]["rotation"]["mat3d"]["l1"]["pt3d"]["x"])
        mat_rot[0][1] = float(dict_conl["geometry"]["extrinseque"]["rotation"]["mat3d"]["l1"]["pt3d"]["y"])
        mat_rot[0][2] = float(dict_conl["geometry"]["extrinseque"]["rotation"]["mat3d"]["l1"]["pt3d"]["z"])
        mat_rot[1][0] = -float(dict_conl["geometry"]["extrinseque"]["rotation"]["mat3d"]["l2"]["pt3d"]["x"])
        mat_rot[1][1] = -float(dict_conl["geometry"]["extrinseque"]["rotation"]["mat3d"]["l2"]["pt3d"]["y"])
        mat_rot[1][2] = -float(dict_conl["geometry"]["extrinseque"]["rotation"]["mat3d"]["l2"]["pt3d"]["z"])
        mat_rot[2][0] = -float(dict_conl["geometry"]["extrinseque"]["rotation"]["mat3d"]["l3"]["pt3d"]["x"])
        mat_rot[2][1] = -float(dict_conl["geometry"]["extrinseque"]["rotation"]["mat3d"]["l3"]["pt3d"]["y"])
        mat_rot[2][2] = -float(dict_conl["geometry"]["extrinseque"]["rotation"]["mat3d"]["l3"]["pt3d"]["z"])

        try:
            calibration_date = datetime.strptime(
                dict_conl["geometry"]["intrinseque"]["sensor"]["calibration_date"]["day"] + "/" +
                dict_conl["geometry"]["intrinseque"]["sensor"]["calibration_date"]["month"] + "/" +
                dict_conl["geometry"]["intrinseque"]["sensor"]["calibration_date"]["year"] + " " +
                dict_conl["geometry"]["intrinseque"]["sensor"]["calibration_date"]["hour"] + ":" +
                dict_conl["geometry"]["intrinseque"]["sensor"]["calibration_date"]["minute"] + ":" +
                dict_conl["geometry"]["intrinseque"]["sensor"]["calibration_date"]["second"], "%d/%m/%Y %H:%M:%S")
        except ValueError:
            calibration_date = datetime.strptime("01/01/2020 00:00:00", "%d/%m/%Y %H:%M:%S")

        cam = Camera.from_value(name=dict_conl["geometry"]["intrinseque"]["sensor"]["name"],
                                w=int(dict_conl["geometry"]["intrinseque"]["sensor"]["sensor_size"]["width"]),
                                h=int(dict_conl["geometry"]["intrinseque"]["sensor"]["sensor_size"]["height"]),
                                x_ppa=float(dict_conl["geometry"]["intrinseque"]["sensor"]["ppa"]["c"]),
                                y_ppa=float(dict_conl["geometry"]["intrinseque"]["sensor"]["ppa"]["l"]),
                                focal=float(dict_conl["geometry"]["intrinseque"]["sensor"]["ppa"]["focale"]),
                                pixel_size=float(dict_conl["geometry"]["intrinseque"]["sensor"]["pixel_size"]),
                                serial_number=dict_conl["geometry"]["intrinseque"]["sensor"]["serial_number"],
                                calibration_date=calibration_date)

        obj = cls()
        obj.image = dict_conl["auxiliarydata"]["image_name"]
        obj.origine = cam.origine
        obj.number = 1
        obj.active = 1
        obj.t = date_shot
        obj.imc = ImageConical.from_mat(x, y, z, mat_rot, EuclideanTopaero(x, y, proj_engine), cam, True)
        obj.imc.z_pos = obj.imc.get_Z_remove_scale_factor(dem)
        return obj

    def to_conl(self, path_conl: Union[Path, str], corlin: bool = True, dem: Union[Dem, Path, str, None] = None):
        """
        Save the shot as light conical file.

        :param path_conl: path to the opk file.
        :param corlin: remove scale factor
        :param dem: dem needed to remove scale factor
        """
        cam_strip = self.imc.camera
        date_now = datetime.now()
        x, y, z = self.imc.sommet

        # Scale factor correction
        if corlin:
            if not isinstance(dem, Dem):
                dem = Dem(dem)
            z = self.imc.get_Z_add_scale_factor(dem)

        # creation XML
        ori = ET.Element("orientation", {})

        ET.SubElement(ori, "lastmodificationbylibori", {'date': date_now.strftime("%Y-%m-%d"),
                                                        "time": date_now.strftime("%H h %M min %S sec")})
        ET.SubElement(ori, "version").text = "1.0"

        auxiliary_data = ET.SubElement(ori, "auxiliarydata")
        ET.SubElement(auxiliary_data, "image_name").text = self.image
        image_date = ET.SubElement(auxiliary_data, "image_date")
        ET.SubElement(image_date, "year").text = str(self.t.strftime("%Y"))
        ET.SubElement(image_date, "month").text = str(self.t.strftime("%m"))
        ET.SubElement(image_date, "day").text = str(self.t.strftime("%d"))
        ET.SubElement(image_date, "hour").text = str(self.t.strftime("%H"))
        ET.SubElement(image_date, "minute").text = str(self.t.strftime("%M"))
        ET.SubElement(image_date, "second").text = str(self.t.strftime("%S"))
        ET.SubElement(image_date, "time_system").text = ""
        ET.SubElement(auxiliary_data, "samples")

        geometry = ET.SubElement(ori, "geometry", {'type': "physique"})
        extrinseque = ET.SubElement(geometry, "extrinseque")
        systeme = ET.SubElement(extrinseque, "systeme")
        euclidien = ET.SubElement(systeme, "euclidien", {'type': "MATISRTL"})
        ET.SubElement(euclidien, "x").text = str(x)
        ET.SubElement(euclidien, "y").text = str(y)
        ET.SubElement(systeme, "geodesique").text = str(self.imc.system.proj_engine.projection_list.value["ta"]).upper()

        ET.SubElement(extrinseque, "grid_alti").text = "UNKNOWN"
        sommet = ET.SubElement(extrinseque, "sommet")
        ET.SubElement(sommet, "easting").text = str(0)
        ET.SubElement(sommet, "northing").text = str(0)
        ET.SubElement(sommet, "altitude").text = str(z)

        rotation = ET.SubElement(extrinseque, "rotation")
        ET.SubElement(rotation, "Image2Ground").text = "false"
        mat3d = ET.SubElement(rotation, "mat3d")
        rotation_matrix = self.imc.mat

        l1 = ET.SubElement(mat3d, "l1")
        l1_pt3d = ET.SubElement(l1, "pt3d")
        ET.SubElement(l1_pt3d, "x").text = str(rotation_matrix[0][0])
        ET.SubElement(l1_pt3d, "y").text = str(rotation_matrix[0][1])
        ET.SubElement(l1_pt3d, "z").text = str(rotation_matrix[0][2])

        l2 = ET.SubElement(mat3d, "l2")
        l2_pt3d = ET.SubElement(l2, "pt3d")
        ET.SubElement(l2_pt3d, "x").text = str(-rotation_matrix[1][0])
        ET.SubElement(l2_pt3d, "y").text = str(-rotation_matrix[1][1])
        ET.SubElement(l2_pt3d, "z").text = str(-rotation_matrix[1][2])

        l3 = ET.SubElement(mat3d, "l3")
        l3_pt3d = ET.SubElement(l3, "pt3d")
        ET.SubElement(l3_pt3d, "x").text = str(-rotation_matrix[2][0])
        ET.SubElement(l3_pt3d, "y").text = str(-rotation_matrix[2][1])
        ET.SubElement(l3_pt3d, "z").text = str(-rotation_matrix[2][2])

        intrinseque = ET.SubElement(geometry, "intrinseque")
        sensor = ET.SubElement(intrinseque, "sensor")
        ET.SubElement(sensor, "name").text = self.origine
        calibration_date = ET.SubElement(sensor, "calibration_date")
        ET.SubElement(calibration_date, "year").text = str(cam_strip.calibration_date.strftime("%Y"))
        ET.SubElement(calibration_date, "month").text = str(cam_strip.calibration_date.strftime("%m"))
        ET.SubElement(calibration_date, "day").text = str(cam_strip.calibration_date.strftime("%d"))
        ET.SubElement(calibration_date, "hour").text = str(0)
        ET.SubElement(calibration_date, "minute").text = str(0)
        ET.SubElement(calibration_date, "second").text = str(0)
        ET.SubElement(calibration_date, "time_system").text = ""

        ET.SubElement(sensor, "serial_number").text = str(cam_strip.serial_number)

        image_size = ET.SubElement(sensor, "image_size")
        ET.SubElement(image_size, "width").text = str(0)
        ET.SubElement(image_size, "height").text = str(0)

        sensor_size = ET.SubElement(sensor, "sensor_size")
        ET.SubElement(sensor_size, "width").text = str(cam_strip.w)
        ET.SubElement(sensor_size, "height").text = str(cam_strip.h)

        ppa = ET.SubElement(sensor, "ppa")
        ET.SubElement(ppa, "c").text = str(cam_strip.x_ppa)
        ET.SubElement(ppa, "l").text = str(cam_strip.y_ppa)
        ET.SubElement(ppa, "focale").text = str(cam_strip.focal)

        if self.imc.dict_syst is not None:
            transfo2d = ET.SubElement(sensor, "transfo2d")
            tr2delem = ET.SubElement(transfo2d, "tr2delem")
            tr2delem.set("Type", self.imc.dict_syst["type"])
            tr2delem.set("isinterne", self.imc.dict_syst["isinterne"])
            tr2delem.set("C0", str(self.imc.dict_syst["C0"]))
            tr2delem.set("L0", str(self.imc.dict_syst["L0"]))
            tr2delem.set("S1", str(self.imc.dict_syst["S1"]))
            tr2delem.set("S2", str(self.imc.dict_syst["S2"]))

        ET.SubElement(sensor, "pixel_size").text = str(cam_strip.pixel_size)

        tree = ET.ElementTree(ori)
        indent(ori)
        tree.write(path_conl, encoding='utf-8', xml_declaration=True)

    def to_ori(self, path_ori: Union[Path, str], corlin: bool = True, dem: Union[Dem, Path, str, None] = None):
        """
        Save the shot as ORI SURE nframes format.

        :param path_ori: path to the ori file.
        :param corlin: remove scale factor.
        :param dem: dem needed to remove scale factor
        """
        cam_strip = self.imc.camera
        date_now = datetime.now()
        x, y, z = self.imc.sommet

        # Scale factor correction
        if corlin:
            if not isinstance(dem, Dem):
                dem = Dem(dem)
            z = self.imc.get_Z_add_scale_factor(dem)

        rotation_matrix = self.imc.mat
        focale = cam_strip.focal
        pixel_size = cam_strip.pixel_size * 10 ** 3
        focale_mm = focale * pixel_size

        txt = \
f"""$ImageID___________________________________________________(ORI_Ver_1.1)
        {self.image}
$IntOri_FocalLength_________________________________________________[mm]
    {focale_mm}
$IntOri_PixelSize______(x|y)________________________________________[mm]
    {pixel_size}	{pixel_size}
$IntOri_SensorSize_____(x|y)_____________________________________[pixel]
    {cam_strip.w} {cam_strip}
$IntOri_PrincipalPoint_(x|y)_____________________________________[pixel]
    {cam_strip.x_ppa}	{cam_strip.y_ppa}
$IntOri_CameraMatrix_____________________________(ImageCoordinateSystem)
    {focale * -1}	0.00000000	{cam_strip.x_ppa}
    0.00000000  {focale}		{cam_strip.y_ppa}
    0.00000000	0.00000000	1.00000000
$ExtOri_RotationMatrix____________________(World->ImageCoordinateSystem)
    {rotation_matrix[0][0]}	{rotation_matrix[0][1]}	{rotation_matrix[0][2]}
    {rotation_matrix[1][0]}	{rotation_matrix[1][1]}	{rotation_matrix[1][2]}
    {rotation_matrix[2][0]}	{rotation_matrix[2][1]}	{rotation_matrix[2][2]}
$ExtOri_TranslationVector________________________(WorldCoordinateSystem)
    {x}	{y}	{z}
$IntOri_Distortion_____(Model|ParameterCount|(Parameters))______________
    NONE	0
"""
        # Ecriture ori
        path_ori.write_text(txt)

    def to_rpc(self, dem: Dem, path_rpc : Union[Path, str] = None, size_grid: int = 100, order: int = 2,
               true_rpc: bool = True, fact_rpc_carto: Union[float, None] = None)\
            -> Rpc:
        """
        Save the shot as rational polynomial coefficients file.

        :param dem: dem of the area
        :param path_rpc: path to the RPC file.
        :param size_grid: grid step length in which the RPC parameters will be estimated.
        :param order: order of the rational polynomials.
        :param true_rpc: whether to compute RPC in geographical coordinates.
        :param fact_rpc_carto: factor to apply to data if rpc in cartographic coordinates.

        :return: A rpc object.
        """
        rpc = Rpc(self, dem, size_grid, order, true_rpc, fact_rpc_carto)
        if path_rpc is not None:
            rpc.export_rpc_txt(path_rpc)
        return rpc

    def to_gcp(self, dem: Union[Path, str, Dem], size_grid: int) -> List[float, float, float, float, float]:
        """
        Save gcp from the shot

        :param dem: dem of the area
        :param size_grid: grid step length in which the gcp parameters will be estimated.

        :return: A list of GCP.
        """
        dem = dem if isinstance(dem, Dem) else Dem(dem)
        x_min, x_max, y_min, y_max = self.extent.GetEnvelope()
        x, y = np.mgrid[int(x_min):int(x_max):size_grid, int(y_min):int(y_max):size_grid]
        x, y = x.ravel(), y.ravel()
        z = dem.get(x, y)
        c, l = self.imc.world_to_image(x, y, z)
        gcp = np.c_[x, y, z, c, l]
        return gcp

    def __getattr__(self, key):
        return self.dict_shot.get(key, "")

    def __deepcopy__(self, memodict) -> Shot:
        """Create a deepcopy of the Project object."""
        cls = self.__class__
        result = cls.__new__(cls)
        memodict[id(self)] = result
        for k, v in self.__dict__.items():
            setattr(result, k, deepcopy(v, memodict))
        return result