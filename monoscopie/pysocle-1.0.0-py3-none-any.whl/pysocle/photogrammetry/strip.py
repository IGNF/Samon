"""A module for manipulating an aerial imagery acquisition strip."""

from __future__ import annotations

import json
import warnings
from copy import deepcopy
from typing import Union, Any, Callable, Dict, List, Iterator
from shapely import Polygon, MultiPolygon

import numpy as np
from osgeo import ogr
from pysocle.altimetry.dem import Dem
from pysocle.photogrammetry.shot import Shot
from scipy import stats


class Strip:
    """
    Represents an aerial imagery acquisition strip.

    .. note::
        :class:`Strip` is not supposed to be instantiated by users. You most likely need to use
        :class:`pysocle.photogrammetry.ta.Ta`.
    """

    def __init__(self):
        # "number" est le numéro  de l'axe de vol indépendamment de la session de vol
        # "axe" est l'identifiant de la bande lors des acquisitions
        # Ainsi une reprise d'axe gargera le "number" mais aura un "axe" différent.
        # D'après le modèle de donnée cela devrait être l'inverse
        self._number = 0
        self._axe = 0
        self._active = True
        self._cross = False
        self._kappa = np.nan
        self._param_line = [np.nan, np.nan, np.nan]
        self._quality = 0
        self._strip_prev = None
        self._strip_next = None
        self._extent = Polygon()
        self._shot = {}
        self._dict = {}

    @classmethod
    def from_dict(cls, dict_strip: dict) -> Strip:
        """
        Create a strip object from a dictionary.

        :param dict_strip: dictionary of the strip.

        :return: A strip object.
        """
        obj = cls()
        obj.number = dict_strip.get("number", 0)
        obj.axe = dict_strip.get("axe", 0)
        obj.active = dict_strip.get("actif", True)
        obj.cross = dict_strip.get("trans", False)
        obj.kappa = dict_strip.get("kappa", np.nan)
        obj.param_line = [dict_strip.get("a", np.nan), dict_strip.get("b", np.nan), dict_strip.get("c", np.nan)]
        obj.nb_section = dict_strip.get("nb_section", 0)
        obj.quality = dict_strip.get("qualite", 0)
        obj.dict_strip = dict_strip
        return obj

    def __getattr__(self, name):
        return self.dict_strip.get(name, "")

    @property
    def number(self) -> int:
        """
        Strip number.

        :getter: Returns the strip number
        :setter: Sets the strip number
        """
        return self._number

    @number.setter
    def number(self, number: int):
        try:
            self._number = int(number)
        except ValueError:
            raise ValueError("Strip number must be a int")

    @property
    def axe(self) -> int:
        """
        Axe number.

        :getter: Returns the axe number
        :setter: Sets the axe number
        """
        return self._axe

    @axe.setter
    def axe(self, axe: int):
        try:
            self._axe = int(axe)
        except ValueError:
            raise ValueError("Axe must be a int")

    @property
    def active(self) -> bool:
        """
        Strip activity.

        :getter: Returns the strip activity
        :setter: Sets the strip activity
        """
        return self._active

    @active.setter
    def active(self, active: bool):
        try:
            self._active = bool(int(active))
        except ValueError:
            raise ValueError("Strip activity must be a bool")

    @property
    def cross(self) -> bool:
        """
        Cross strip.

        :getter: Returns true if the strip is a cross strip
        :setter: Sets the cross strip
        """
        return self._cross

    @cross.setter
    def cross(self, cross: bool):
        try:
            self._cross = bool(int(cross))
        except ValueError:
            raise ValueError("Cross strip must be a bool")

    @property
    def kappa(self) -> float:
        """
        The value of the strip's orientation (kappa angle)

        :getter: Returns the kappa angle of the strip
        :setter: Sets the kappa angle of the strip
        """
        return self._kappa

    @kappa.setter
    def kappa(self, kappa: float):
        try:
            self._kappa = float(kappa)
        except ValueError:
            raise ValueError("Kappa value must be a float")

    @property
    def param_line(self) -> List[Union[int, float]]:
        """
        The strip parametrization values [a, b, c]:
        aX + bY + c = 0

        :getter: Returns the parameters [a, b, c]
        :setter: Sets the parameters [a, b, c]
        """
        return self._param_line

    @param_line.setter
    def param_line(self, param_line: List[Union[int, float]]):
        try:
            self._param_line = [float(x) for x in param_line]
        except ValueError:
            warnings.warn("param_line value must be a list of float or int")

    @property
    def quality(self) -> int:
        """
        The quality of the strip.

        :getter: Returns the quality of the strip
        :setter: Sets the quality of the strip
        """
        return self._quality

    @quality.setter
    def quality(self, quality: int):
        try:
            self._quality = int(quality)
        except ValueError:
            raise ValueError("Quality value must be a int")

    @property
    def strip_prev(self) -> Union[Strip, None]:
        """
        The previous strip.

        :getter: Returns the previous strip
        :setter: Sets the previous strip
        """
        return self._strip_prev

    @strip_prev.setter
    def strip_prev(self, strip_prev: Union[Strip, None]):
        if isinstance(strip_prev, Strip) or strip_prev is None:
            self._strip_prev = strip_prev
        else:
            raise ValueError("Previous strip value must be a Strip")

    @property
    def strip_next(self) -> Union[Strip, None]:
        """
        The next strip.

        :getter: Returns the next strip
        :setter: Sets the next strip
        """
        return self._strip_next

    @strip_next.setter
    def strip_next(self, strip_next: Union[Strip, None]):
        if isinstance(strip_next, Strip) or strip_next is None:
            self._strip_next = strip_next
        else:
            raise ValueError("Next strip must be a int")

    @property
    def extent(self) -> Polygon:
        """
        Strip extent.

        :getter: Returns the strip extent.
        :setter: Sets the strip extent.
        """
        return self._extent

    @extent.setter
    def extent(self, extent: Polygon):
        if isinstance(extent, Polygon) or isinstance(extent, MultiPolygon):
            self._extent = extent
        else:
            raise ValueError(f"Strip extent must be a shapely.Polygon not a {type(extent)}")

    @property
    def shot(self) -> Dict[str, Shot]:
        """
        The images of the flight.

        :getter: Returns the images of the flight
        :setter: not available
        """
        return self._shot

    def add_shot(self, shot: Shot) -> None:
        """
        Add an image to the strip.

        :param shot: shot to be added.
        :type shot: Shot
        """
        self.shot[shot.image] = shot

    def remove_shot(self, shot: Union[str, Shot]) -> None:
        """
        Remove a shot from the strip.

        :param shot: shot to be removed.
        :type shot: Shot
        """
        if isinstance(shot, Shot):
            self.shot.pop(shot.image, None)
        else:
            self.shot.pop(shot, None)

    def nbr_shot(self) -> int:
        """
        Compute the number of images in the strip.

        :return: the number of images in the strip.
        :rtype: int
         """
        return len(self.shot)

    def change_active(self) -> None:
        """Change the activity of the strip."""
        self.active = not self.active

    def change_cross(self) -> None:
        """Change the cross parameter of the strip."""
        self.cross = not self.cross

    def compute_line(self) -> None:
        """Estimate the linear equation of the strips : aX + bY + c = 0."""
        x = [shot.imc.x_pos for shot in self.shot.values()]
        y = [shot.imc.y_pos for shot in self.shot.values()]

        # Droite parfaitement verticale
        if min(x) == max(x) and min(y) != max(y):
            res2 = stats.linregress(y, x)
            a = -1
            b = res2.slope
            c = res2.intercept
        # Droite parfaitement horizontale
        elif min(y) == max(y) and min(x) != max(x):
            res1 = stats.linregress(x, y)
            a = res1.slope
            b = -1
            c = res1.intercept
        # Cas classique
        elif min(y) != max(y) and min(x) != max(x):
            res1 = stats.linregress(x, y)
            res2 = stats.linregress(y, x)
            # On garde la meilleure estimation ie celle qui s'éloigne le plus du cas dégénéré
            if res1.stderr < res2.stderr:
                a = res1.slope
                b = -1
                c = res1.intercept
            else:
                a = -1
                b = res2.slope
                c = res2.intercept
        # Droite de points identiques => erreur de données ?
        else:
            a, b, c = np.nan, np.nan, np.nan
            warnings.warn(f"Tous les sommets de la bande {self.number} sont identiques")

        self.param_line = [a, b, c]

    def compute_kappa(self) -> None:
        """Compute the kappa angle of the strip."""
        if self.nbr_shot() < 2:
            warnings.warn(f"Pas assez d'images dans la bande {self.number} pour estimer une droite")
        else:
            self.compute_line()
            if self.param_line[1] == 0:
                self.kappa = np.pi/2
            else:
                self.kappa = np.arctan(-self.param_line[0]/self.param_line[1])

    def init_kappa(self) -> None:
        """Initiate the kappa of all images in the strip."""
        if np.isnan(self.kappa):
            self.compute_kappa()
        opk = [0, 0, self.kappa * 180 / np.pi + 90]
        for shot in self.shot.values():
            shot.imc.mat = shot.imc.system.opk_to_mat(opk)
            shot.imc.mat_eucli = shot.imc.system.mat_to_mat_eucli(shot.imc.x_pos, shot.imc.y_pos, shot.imc.mat)

    def compute_extent(self, dem: Dem, recompute: bool = False, pnt_side: int = 4, prec: float = 1., iter_max: int = 2,
                       callback: Union[Callable[[str, float], Any], None] = None) -> None:
        """
        Compute the extent of the shot. If recompute is False, extents are not recomputed if exists.

        :param dem: Dem of the area
        :param recompute: recomputre all extent
        :param pnt_side: number of point in the extent between two corners
        :param prec: accuracy
        :param iter_max: maximum number of iterations
        :param callback: Progress callback.
        """

        strip_extent = Polygon()
        nbr_shot = len(self.shot)
        for ind_shot, shot in enumerate(self.shot.values()):
            if shot.extent is None or recompute:
                if callback is not None:
                    callback(f"Shot {ind_shot+1}/{nbr_shot}", round(ind_shot/nbr_shot,2))
                shot.compute_extent(dem, pnt_side, prec, iter_max)
            if strip_extent.is_empty:
                strip_extent = shot.extent
            else:
                strip_extent = strip_extent.union(shot.extent)
        self.extent = strip_extent

    def compute_sun_height(self, callback: Union[Callable[[str, float], Any], None] = None) -> None:
        """
        Compute the sun height of all the images in the strip.

        :param callback: Progress callback.
        """
        nbr_shot = self.nbr_shot()
        for ind_shot, shot in enumerate(self.get_shots()):
            if callback is not None:
                callback("Calcul de la hauteur solaire", ind_shot/nbr_shot)
            shot.compute_sun_height()

    def get_shots(self, filter_shot: Union[Callable[[Shot], bool], None] = None) -> Iterator[shot]:
        """
        Return iterator of shots.
        Elements of Ta can be filtered with filter_shot functions.

        :param filter_shot: function used to filter a shot.

        :return: iterator of shots.
        """
        return filter(filter_shot, self.shot.values())

    def filter(self, filter_shot: Union[Callable[[Shot], bool], None] = None) -> None:
        """
        Filter the object from those elements of Strip for which filter_shot functions returns true
        The filter_shot function is applied to each shot.

        :param filter_shot: function used to filter a shot
        """
        if filter_shot is not None:
            for shot in list(self.get_shots(lambda s: not filter_shot(s))):
                self.remove_shot(shot)

    def print(self) -> str:
        """
        Print strip information.

        :return: Strip information.
        """
        txt = ""
        for key, val in vars(self).items():
            key = key.replace("_", "")
            if key not in ["shot", "dict_strip"]:
                txt += "{} : {}\n".format(key, val)
        return txt

    def get_json(self) -> str:
        """
        Print strip information.

        :return: Strip information.
        """
        dict_temp = {}
        for key, val in vars(self).items():
            key = key.replace("_", "")
            if key not in ["shot", "dict_strip"]:
                dict_temp[key] = val
        return json.dumps(dict_temp)

    def __deepcopy__(self, memodict) -> Strip:
        """Create a deepcopy of the Project object."""
        cls = self.__class__
        result = cls.__new__(cls)
        memodict[id(self)] = result
        for k, v in self.__dict__.items():
            setattr(result, k, deepcopy(v, memodict))
        return result
