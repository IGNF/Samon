

"""A module for reading and generating orientation files."""

from __future__ import annotations

import itertools
import pickle
import json
import xml.etree.ElementTree as ET
from copy import deepcopy
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Union, Any, Callable

import numpy as np
from osgeo import gdal, ogr, osr
from pysocle.geodesy.proj_engine import ProjEngine
from pysocle.geodesy.projection_list import ProjectionList
from pysocle.photogrammetry.camera import Camera
from pysocle.photogrammetry.flight import Flight
from pysocle.photogrammetry.project import Project
from pysocle.photogrammetry.shot import Shot
from pysocle.photogrammetry.strip import Strip
from pysocle.utils.diverse import indent_ta, etree_to_dict, get_ogr_driver
from pysocle.utils.feature_format import Reader, Writer, FEATURE_FORMAT
from scipy.spatial.transform import Rotation as R


class Ta:
    """
    A class for reading and generating orientation files.

    The following formats are supported in reading:

        - XML
        - Ogr format (including OPK format)

    The following formats are supported in writing:

        - XML
        - RPC
        - CONl
        - Ogr format (including OPK format)

    .. note::
        :class:`Ta` is not supposed to be instantiated via :func:`Ta`. To create a :class:`Ta` objects use from methods.
    """

    def __init__(self):
        self._project = None

    @property
    def project(self) -> Project:
        """
        The project object.

        :getter: Returns the project objet.
        :setter: Not available
        """
        return self._project

    @staticmethod
    def from_file(path_ta: Union[str, Path], calib_cam: Union[str, Path, None] = None,
                  proj: ProjectionList = ProjectionList.RGF93LAMB93,
                  path_dem: Union[str, Path] = None, opt: Union[dict, None] = None,
                  callback: Union[Callable[[str, float], Any], None] = None) -> Union[Ta, None]:
        """
        Create an object ta from a file.

        :param path_ta: path to the file.
        :param calib_cam: path to the calibration camera(s).
        :param proj: projection of the project.
        :param path_dem: path to the dem.
        :param opt: Creation options.
        :param callback: Progress callback.

        :return: A Ta object.
        """

        # Options
        opt = {} if opt is None else opt.copy()

        # Lecture du fichier d'orientation
        path_ta = Path(path_ta)
        if path_ta.suffix.lower() == ".xml":
            ta = Ta.from_xml(path_ta, callback=callback)
            ta.project.add_dem(path_dem)
            if path_dem is None:
                callback("DEM non renseigné -> Z = 0", 1)
            if str(opt.get("CORLIN", "FALSE")) == "TRUE":
                ta.project.remove_scale_factor()
                callback("Lecture : Correction d'altération linéaire enlevée", 1)

        else:
            corlin = str(opt.pop("CORLIN", "TRUE")) == "TRUE"
            ta = Ta.from_ogr(path_ta=path_ta, calib_cam=calib_cam,
                             ogr_driver=opt.pop("OGR_DRIVER", None), reader=opt.pop("READER", "default"),
                             shift_kappa=opt.pop("KAPPA", 0), seq_angle=opt.pop("SEQ_ANGLE", "xyz"),
                             format_datetime=opt.pop("DATETIME", "%d/%m/%Y %H:%M:%S"),
                             open_options=opt, proj=proj, callback=callback)
            ta.project.add_dem(path_dem)
            if path_dem is None:
                callback("DEM non renseigné -> Z = 0", 1)

            if corlin:
                ta.project.remove_scale_factor()
                callback("Lecture : Correction d'altération linéaire enlevée", 1)

        return ta

    @classmethod
    def from_xml(cls, path_ta: Union[str, Path], callback: Union[Callable[[str, float], Any], None] = None) -> Ta:
        """
        Read a TA in XML format.

        :param path_ta: path to the xml file.
        :param callback: Progress callback.

        :return: A Ta object.
        """
        obj = cls()
        obj.path_ta = Path(path_ta)

        # Parsing du fichier XML
        tree = ET.parse(obj.path_ta)
        root = tree.getroot()

        # Recuperation des infos de project
        project = root.find("chantier")
        proj = ProjectionList.from_ta(project.find("projection").text.strip())
        proj_engine = ProjEngine(proj)
        dict_project = etree_to_dict(project, ["vol"])
        nbr_shot, ind_shot = sum(1 for _ in root.iter("cliche")), 0
        obj._project = Project.from_dict(dict_project, proj_engine)
        obj._project._proj_engine = proj_engine

        # Recuperation des infos des cameras
        for cam in root.iter("sensor"):
            camera = Camera.from_xml(cam)
            obj._project.add_camera(camera)

        # Récupération des differents flights
        for flight in root.iter("vol"):
            dict_flight = etree_to_dict(flight, ["bande"])
            dict_flight["date"] = datetime.strptime(dict_flight["date"], "%d%m%Y")
            obj_flight = Flight.from_dict(dict_flight)

            # Récupération des différentes strips
            for strip in flight.findall("bande"):
                dict_strip = etree_to_dict(strip, ["cliche"])
                obj_strip = Strip.from_dict(dict_strip)

                # Récupération des différentes images
                for shot in strip.findall("cliche"):
                    if callback is not None:
                        callback("Lecture XML", ind_shot / nbr_shot)
                    ind_shot += 1
                    dict_shot = etree_to_dict(shot, ["polygon2d", "modhs"])

                    # cas particulier de la balise polygon du ta, plusieurs balises de même nom
                    polygon = shot.find("polygon2d")
                    nb_pt_polygon = polygon.find("nb_pt").text.strip()
                    extent_polygon = [(float(x.text.strip()), float(y.text.strip())) for x, y in
                                      zip(polygon.findall("x"), polygon.findall("y"))]
                    dict_shot["time"] = dict_shot["time"].split(".")[0] if "." in dict_shot["time"] else dict_shot[
                        "time"]
                    dict_shot["time"] = "0" * (6 - len(dict_shot["time"])) + dict_shot["time"]
                    dict_shot["time"] = datetime.combine(dict_flight["date"],
                                                         datetime.strptime(dict_shot["time"], "%H%M%S").time(),
                                                         tzinfo=timezone.utc)
                    dict_shot["polygon2d"] = {"nb_pt": nb_pt_polygon, "emprise": extent_polygon}
                    dict_shot["repere"] = obj._project.barycentric_system
                    dict_shot["model"]["proj_engine"] = obj._project.proj_engine
                    dict_shot["model"]["camera"] = obj._project.camera[dict_shot["origine"]]

                    # cas particulier de la balise modhs du ta, plusieurs balises de même nom
                    modhs = shot.find("modhs")
                    try:
                        type_modhs = modhs.find("type").text.strip()
                    except (ValueError, AttributeError):
                        type_modhs = ""
                    try:
                        paramshs = {params.find("channel").text.strip(): etree_to_dict(params) for params in
                                    modhs.findall("paramshs")}
                    except (ValueError, AttributeError):
                        paramshs = {}
                    dict_shot["modhs"] = {"type": type_modhs, "paramshs": paramshs}
                    obj_shot = Shot.from_dict(dict_shot)
                    obj_strip.add_shot(obj_shot)
                obj_flight.add_strip(obj_strip)
            obj._project.add_flight(obj_flight)
        return obj

    @classmethod
    def from_ogr(cls, path_ta: Union[str, Path], calib_cam: Union[str, Path, None] = None,
                 ogr_driver: Union[str, None] = None, reader: Union[str, dict] = "default",
                 shift_kappa: int = 0, seq_angle: str = "xyz", format_datetime: str = "%d/%m/%Y %H:%M:%S",
                 open_options: Union[dict, None] = None, proj: ProjectionList = ProjectionList.RGF93LAMB93,
                 callback: Union[Callable[[str, float], Any], None] = None) -> Ta:
        """
        Read a TA in ogr format.

        :param path_ta: path to the ogr file.
        :param calib_cam: the path to the calibration file(s).
        :param ogr_driver: name of the driver to use, if not specified, the driver is guessed from the extension
        :param reader: name of the reader to use.
        :param shift_kappa: shift to apply on the kappa angle.
        :param seq_angle: specifies sequence of axes for rotations.
        :param format_datetime: datetime format.
        :param open_options: open options from gdal
        :param proj: projection of the project.
        :param callback: Progress callback.

        :return: A Ta object.
        """
        obj = cls()
        obj.path_ta = Path(path_ta)

        # Reader
        if isinstance(reader, str):
            try:
                reader = getattr(Reader, reader).value
            except AttributeError:
                try:
                    with open(reader, 'r') as file:
                        reader = json.load(file)
                except FileNotFoundError:
                    raise ValueError("le reader n'est ni un reader par défaut ni un chemin valide")

        # Projection
        proj_engine = ProjEngine(proj)

        # Creation project
        dict_project = {"nom": obj.path_ta.stem}
        obj._project = Project.from_dict(dict_project, proj_engine)

        dict_cam = {}
        # Fausse camera
        if calib_cam is False:
            cam = Camera.from_value("Default", 20000, 1500, 10000, 7500, 20000, 4 * 10 ** -6)
            dict_cam[cam.origin] = cam
        else:
            # Import Camera, get list of the file if path
            if isinstance(calib_cam, str) or isinstance(calib_cam, Path):
                if Path(calib_cam).is_file():
                    calib_cam = [calib_cam]
                elif Path(calib_cam).is_dir():
                    calib_cam = list(calib_cam.glob("*.xml"))

            # Read camera file
            if isinstance(calib_cam, list):
                for file_cam in calib_cam:
                    try:
                        cam = Camera.from_xml(file_cam)
                        dict_cam[cam.origin] = cam
                    except TypeError as e:
                        raise ValueError(f"Erreur lors de la lecture de la calibration {calib_cam}") from e

        open_options = {} if open_options is None else open_options
        if obj.path_ta.suffix.lower() == ".opk":
            ogr_driver = "CSV"
        if ogr_driver is None:
            dataSource = gdal.OpenEx(str(obj.path_ta), 0,
                                     open_options=[f"{key}={value}" for key, value in open_options.items()])
        else:
            dataSource = gdal.OpenEx("CSV:" + str(obj.path_ta), 0, allowed_drivers=[ogr_driver],
                                     open_options=[f"{key}={value}" for key, value in open_options.items()])

        layer = dataSource.GetLayer()
        nbr_shot = layer.GetFeatureCount()
        dict_date = {}
        list_cam = []
        for ind_shot, img in enumerate(layer):
            if callback is not None:
                callback("Lecture OGR", ind_shot / nbr_shot)

            try:
                img_id = img.GetField(reader["ID"]).split(".")[0]
                img_num = int(img_id.split("_")[1])
                int(img_id.split("_")[0].split("x")[1]) if "x" in img_id else int(img_id.split("_")[0])
            except (KeyError, ValueError, IndexError) as e:
                raise ValueError(
                    f"Nom de l'image incorrect ligne={ind_shot} position={reader['ID']}") from e

            try:
                x = float(img.GetField(reader["X"])) if reader.get("X",
                                                                   None) is not None else img.GetGeometryRef().GetX()
            except (IndexError, ValueError) as e:
                raise ValueError(f"X incorrect ligne={ind_shot} position={reader['X']}") from e

            try:
                y = float(img.GetField(reader["Y"])) if reader.get("Y",
                                                                   None) is not None else img.GetGeometryRef().GetY()
            except (IndexError, ValueError) as e:
                raise ValueError(f"Y incorrect ligne={ind_shot} position={reader['Y']}") from e

            try:
                z = float(img.GetField(reader["Z"])) if reader.get("Z",
                                                                   None) is not None else img.GetGeometryRef().GetZ()
            except (IndexError, ValueError) as e:
                raise ValueError(f"Z incorrect ligne={ind_shot} position={reader['Z']}") from e

            try:
                o = float(img.GetField(reader["O"])) if reader.get("O", None) is not None else 0
            except (IndexError, ValueError) as e:
                raise ValueError(f"o incorrect ligne={ind_shot} position={reader['O']}") from e

            try:
                p = float(img.GetField(reader["P"])) if reader.get("P", None) is not None else 0
            except (IndexError, ValueError) as e:
                raise ValueError(f"p incorrect ligne={ind_shot} position={reader['P']}") from e

            try:
                k = float(img.GetField(reader["K"])) if reader.get("K", None) is not None else np.nan
            except (IndexError, ValueError) as e:
                raise ValueError(f"k incorrect ligne={ind_shot} position={reader['K']}") from e

            k += shift_kappa
            if seq_angle == "yxz":
                o, p, k = -R.from_euler(seq_angle, -np.array([p, o, k]), degrees=True).as_euler("xyz", degrees=True)
            elif seq_angle != "xyz":
                raise ValueError(f"La convention angulaire doit être xyz ou yxz")

            try:
                shutter = img.GetField(reader["SHUTTER"])
            except TypeError as e:
                shutter = 0
                if "SHUTTER" in reader and reader["SHUTTER"] is not None:
                    raise ValueError(f"Shutter incorrect ligne={ind_shot} position={reader['SHUTTER']}") from e

            try:
                camera = img.GetField(reader["CAMERA"]) if calib_cam is not False else "Default"
            except (IndexError, KeyError) as e:
                raise ValueError(f"CAMERA incorrect ligne={ind_shot} position={reader['CAMERA']}") from e

            try:
                dict_cam[camera]
            except KeyError as e:
                raise ValueError(f"La caméra {camera} ne fait pas partie des caméras reconnues :"
                                 f" {list(dict_cam.keys())}") from e

            try:
                date_time = datetime.strptime(img.GetField(reader["DATE"]) + " " + img.GetField(reader["TIME"]),
                                              format_datetime).replace(tzinfo=timezone.utc)
            except (TypeError, IndexError) as e:
                if "DATE" not in reader or reader["DATE"] is None:
                    if camera not in list_cam:
                        list_cam += [camera]
                    date_time = datetime(2000, list_cam.index(camera) + 1, 1) + timedelta(seconds=ind_shot)
                else:
                    raise ValueError(
                       f"DATE et TIME incorrect ligne={ind_shot} position={reader['DATE']} et {reader['TIME']} ") from e

            if camera not in obj._project.camera:
                obj._project.add_camera(dict_cam[camera])

            dict_shot = {"image": img_id, "number": img_num, "time": date_time, "shutter": shutter,
                         "model": {"pt3d": {"x": x, "y": y, "z": z}, "opk": {"omega": o, "phi": p, "kappa": k},
                                   "proj_engine": proj_engine, "camera": dict_cam[camera]},
                         "origine": camera, "repere": obj._project.barycentric_system}
            obj_shot = Shot.from_dict(dict_shot)

            if date_time not in dict_date:
                dict_date[date_time] = obj_shot
            else:
                print("Attention, deux clichés ont la même datetime, l'un des deux sera ignoré !")
                print(img_id, dict_date[date_time].image)

        # Detection des flights
        datetime_sorted = sorted(dict_date.keys())
        list_flight = [[(datetime_sorted[0], dict_date[datetime_sorted[0]])]]
        for date_time in datetime_sorted[1:]:
            if date_time - list_flight[-1][-1][0] > timedelta(hours=1):
                list_flight.append([(date_time, dict_date[date_time])])
            else:
                list_flight[-1].append((date_time, dict_date[date_time]))

        num_axe = 1
        for index, flight in enumerate(list_flight):
            dict_flight = {"number": index + 1, "logname": flight[0][0].strftime("%d%m%Y") + "_" + str(index + 1),
                           "system_sensor": {"sensor": {"origine": flight[0][1].imc.camera.origin}},
                           "date": flight[0][0]}
            obj_flight = Flight.from_dict(dict_flight)

            # Détection des strips
            dict_all_strip = {}
            for img in flight:
                try:
                    strip = int(img[1].image.split("_")[0].split("x")[1])
                except IndexError:
                    strip = int(img[1].image.split("_")[0])

                if strip in dict_all_strip:
                    dict_all_strip[strip].append(img[1])
                else:
                    dict_all_strip[strip] = [img[1]]

            for strip in dict_all_strip:
                dict_strip = {"number": strip, "axe": num_axe}
                obj_strip = Strip.from_dict(dict_strip)
                num_axe += 1
                for shot in dict_all_strip[strip]:
                    obj_strip.add_shot(shot)
                obj_flight.add_strip(obj_strip)
            obj._project.add_flight(obj_flight)

        # Vertical shooting like flight plan
        if reader.get("K", None) is None:
            obj.project.init_kappa()

        return obj

    @classmethod
    def from_topoflight(cls, path_topoflight: Union[str, Path], calib_cam: Union[str, Path, None] = None,
                        proj: ProjectionList = ProjectionList.RGF93LAMB93,
                        callback: Union[Callable[[str, float], Any], None] = None) -> Ta:
        """
        Read a TA in ogr format.

        :param path_topoflight: path to the topoflight directory.
        :param calib_cam: path to the calibration file.
        :param proj: projection of the project.
        :param callback: Progress callback.

        :return: A Ta object.
        """

        obj = cls()

        # Path topoflight
        path_topoflight = Path(path_topoflight)
        path_flighlines = path_topoflight.joinpath("FlightLines.shp")
        path_imagecenters = path_topoflight.joinpath("ImageCenters.shp")

        # Projection
        proj_engine = ProjEngine(proj)

        # Creation project
        dict_project = {"nom": path_topoflight.stem}
        obj._project = Project.from_dict(dict_project, proj_engine)

        # Import Camera
        try:
            cam = Camera.from_xml(calib_cam)
            obj._project.add_camera(cam)
        except TypeError as e:
            raise ValueError(f"Erreur lors de la lecture de la calibration {calib_cam}") from e

        # Flight
        dict_flight = {"number": 1, "logname": "1",
                       "system_sensor": {"sensor": {"origine": cam.origin}},
                       "date": None}
        obj_flight = Flight.from_dict(dict_flight)
        obj._project.add_flight(obj_flight)

        # Strip
        dict_line = {}
        ds_flightlines = gdal.OpenEx(str(path_flighlines), 0)
        layer = ds_flightlines.GetLayer()
        nbr_line = layer.GetFeatureCount()
        for ind_line, line in enumerate(layer):
            if callback is not None:
                callback("Lecture flightLines", ind_line / nbr_line)
            strip_id = int(line.GetField("NR"))
            dict_line[line.GetField("ID")] = strip_id
            dict_strip = {"number": strip_id, "axe": strip_id}
            obj_strip = Strip.from_dict(dict_strip)
            obj_flight.add_strip(obj_strip)

        # Shot
        ds_imagecenters = gdal.OpenEx(str(path_imagecenters), 0)
        layer = ds_imagecenters.GetLayer()
        nbr_shot = layer.GetFeatureCount()
        for ind_shot, shot in enumerate(layer):
            if callback is not None:
                callback("Lecture shots", ind_shot / nbr_shot)
            strip_id = dict_line[shot.GetField("LINEUID")]
            shot_num = ind_shot + 1
            shot_id = f"{strip_id}_{shot_num}"
            x = shot.GetGeometryRef().GetX()
            y = shot.GetGeometryRef().GetY()
            z = shot.GetField("HEIGHT")
            date_time = None

            dict_shot = {"image": shot_id, "number": shot_num, "time": date_time, "shutetr": 0,
                         "model": {"pt3d": {"x": x, "y": y, "z": z}, "opk": {"omega": 0, "phi": 0, "kappa": np.nan},
                                   "proj_engine": proj_engine, "camera": cam},
                         "origine": cam.origin, "repere": obj._project.barycentric_system}
            obj_shot = Shot.from_dict(dict_shot)
            obj_flight.strip[strip_id].add_shot(obj_shot)

        obj.project.init_kappa()
        return obj

    @classmethod
    def from_dict(cls, dict_ta: dict, callback: Union[Callable[[str, float], Any], None] = None) -> Ta:
        """
        Create a Ta object from a dict.

        :param dict_ta: dictionaries of the data.
        :param callback: Progress callback.

        :return: A Ta object.
        """
        # Projection
        proj_engine = ProjEngine(ProjectionList.from_auth(dict_ta["proj"].authid()))
        obj = cls()
        obj.path_ta = dict_ta["path_ta"]

        # Creation project
        dict_project = {"nom": dict_ta.get("nom", ""), "MNT": dict_ta["dem"]}
        obj._project = Project.from_dict(dict_project, proj_engine)

        # Import caméra
        dict_cam = {}
        for name, file_cam in dict_ta["cam"].items():
            cam = Camera.from_xml(file_cam)
            obj._project.add_camera(cam)
            dict_cam[name] = cam

        dict_date = {}
        nbr_shot = len(dict_ta["img"])
        for ind_shot, img in enumerate(dict_ta["img"]):
            if callback is not None:
                callback("Lecture dict", ind_shot / nbr_shot)
            dict_shot = {"image": img["id"], "number": img["num"], "time": img["date_time"].time(), "pose": 0,
                         "model": {"pt3d": {"x": img["pos"][0], "y": img["pos"][1], "z": img["pos"][2]},
                                   "opk": {"omega": img["ori"][0], "phi": img["ori"][1],
                                           "kappa": img["ori"][2] + dict_ta["biais"]},
                                   "proj_engine": proj_engine, "camera": dict_cam[img["cam"]]},
                         "origine": img["cam"], "repere": obj._project.barycentric_system}
            obj_shot = Shot.from_dict(dict_shot)

            if img["date_time"] not in dict_date:
                dict_date[img["date_time"]] = [obj_shot, img["strip"]]
            else:
                print("Attention, deux clichés ont la même datetime, l'un des deux sera ignoré !")
                print(dict_date[img["date_time"]])

        # Detection des flights
        datetime_sorted = sorted(dict_date.keys())
        list_flight = [[(datetime_sorted[0], dict_date[datetime_sorted[0]])]]
        for date_time in datetime_sorted[1:]:
            if date_time - list_flight[-1][-1][0] > timedelta(hours=1):
                list_flight.append([(date_time, dict_date[date_time])])
            else:
                list_flight[-1].append((date_time, dict_date[date_time]))

        for index, flight in enumerate(list_flight):
            dict_flight = {"number": index + 1, "logname": str(index + 1),
                           "system_sensor": {"sensor": {"origine": flight[0][1][0].origine}},
                           "date": flight[0][0]}
            obj_flight = Flight.from_dict(dict_flight)

            # Détection des strips
            dict_all_strip = {}
            for img in flight:
                strip = img[1][1]
                if strip in dict_all_strip:
                    dict_all_strip[strip].append(img[1][0])
                else:
                    dict_all_strip[strip] = [img[1][0]]

            for strip in dict_all_strip:
                dict_strip = {"number": strip, "axe": strip}
                obj_strip = Strip.from_dict(dict_strip)
                for shot in dict_all_strip[strip]:
                    obj_strip.add_shot(shot)
                obj_flight.add_strip(obj_strip)
            obj._project.add_flight(obj_flight)
        obj._project.init_imc_kappa()

        if dict_ta["alt"]:
            obj._project.remove_alt_lin()

        return obj

    def filter(self, filter_flight: Union[Callable[[Flight], bool], None] = None,
               filter_strip: Union[Callable[[Strip], bool], None] = None,
               filter_shot: Union[Callable[[Shot], bool], None] = None, make_copy: bool = True) -> Ta:
        """
        Filter the object from those elements of Ta for which filter_flight, filter_strip
        and filter_shot functions returns true
        The filter_flight function is applied to each filght.
        The filter_strip function is applied to each strip.
        The filter_shot function is applied to each shot.
        If make_copy is True, a new Ta object is created, filtered and returned.

        :param filter_flight: function used to filter a flight
        :param filter_strip: function used to filter a strip
        :param filter_shot: function used to filter a shot
        :param make_copy : return a new ta object

        :return: A Ta object.
        """
        ta = deepcopy(self) if make_copy else self
        ta.project.filter(filter_flight, filter_strip, filter_shot)
        return ta

    def to_xml(self, path_out: Union[str, Path], filter_flight: Union[Callable[[Flight], bool], None] = None,
               filter_strip: Union[Callable[[Strip], bool], None] = None,
               filter_shot: Union[Callable[[Shot], bool], None] = None,
               callback: Union[Callable[[str, float], Any], None] = None) -> None:
        """
        Save the Ta as XML file.
        Ta elements can be filtered with filter_flight, filter_strip and filter_shot functions.

        :param path_out: path to the XML file.
        :param filter_flight: function used to filter a flight
        :param filter_strip: function used to filter a strip
        :param filter_shot: function used to filter a shot
        :param callback: Progress callback.
        """
        nbr_shot = len(list(self.project.get_shots(filter_flight, filter_strip, filter_shot)))
        ind_shot = 0

        # creation XML
        root = ET.Element("TA", {})

        # project
        project = ET.SubElement(root, "chantier")
        ET.SubElement(project, "nom").text = str(self.project.nom)
        ET.SubElement(project, "projection").text = str(self.project.proj_engine.projection_list.value["ta"])
        ET.SubElement(project, "MNT").text = str(self.project.dem.path_dem) if self.project.dem is not None else ""
        ET.SubElement(project, "Z0").text = str(self.project.z0)
        ET.SubElement(project, "derive").text = str(self.project.drift)
        ET.SubElement(project, "overlap").text = str(self.project.overlap)
        ET.SubElement(project, "sidelap").text = str(self.project.sidelap)
        ET.SubElement(project, "resolution").text = str(self.project.resolution)
        ET.SubElement(project, "overlap_delta").text = str(self.project.overlap_delta)
        ET.SubElement(project, "sidelap_delta").text = str(self.project.sidelap_delta)
        ET.SubElement(project, "resolution_delta").text = str(self.project.resolution_delta)
        ET.SubElement(project, "sun_height_min").text = str(self.project.sun_height)
        ET.SubElement(project, "reference_alti").text = str(self.project.elevation_sys)

        # centre repere local
        if self.project.barycentric_system is not None:
            centre_rep_local = ET.SubElement(project, "centre_rep_local")
            pt2d_centre_rep_local = ET.SubElement(centre_rep_local, "pt2d")
            ET.SubElement(pt2d_centre_rep_local, "x").text = str(self.project.barycentric_system.x_central)
            ET.SubElement(pt2d_centre_rep_local, "y").text = str(self.project.barycentric_system.y_central)
            ET.SubElement(centre_rep_local, "proj").text = str(self.project.proj_engine.projection_list.value["ta"])
            ET.SubElement(centre_rep_local, "projTopAero").text = str(
                self.project.proj_engine.projection_list.value["ta"])

        # project suite
        ET.SubElement(project, "nom_generique").text = str(self.project.generic_name)
        ET.SubElement(project, "designation").text = str(self.project.designation)
        ET.SubElement(project, "numero_SAA").text = str(self.project.saa_number)
        ET.SubElement(project, "theme").text = str(self.project.theme)
        ET.SubElement(project, "theme_geographique").text = str(self.project.geographic_theme)
        ET.SubElement(project, "commanditaire").text = str(self.project.sponsor)
        ET.SubElement(project, "producteur").text = str(self.project.productor)
        ET.SubElement(project, "style").text = str(self.project.style)
        ET.SubElement(project, "emulsion").text = str(self.project.emulsion)
        ET.SubElement(project, "support").text = str(self.project.support)
        ET.SubElement(project, "qualite").text = str(self.project.quality)
        ET.SubElement(project, "annee_debut").text = str(self.project.annee_debut)
        ET.SubElement(project, "note").text = str(self.project.note)
        ET.SubElement(project, "qualite_pva").text = str(self.project.qualite_pva)

        list_flight = []
        for obj_flight in self.project.get_flights(filter_flight):
            list_strip = []
            for obj_strip in obj_flight.get_strips(filter_strip):
                list_shot = []
                for obj_shot in obj_strip.get_shots(filter_shot):
                    if callback is not None:
                        callback("XML", ind_shot / nbr_shot)
                    ind_shot += 1
                    shot = ET.Element("cliche", {})
                    ET.SubElement(shot, "image").text = str(obj_shot.image)
                    ET.SubElement(shot, "origine").text = str(obj_shot.imc.camera.origin)
                    ET.SubElement(shot, "nb_canaux").text = str(obj_shot.nb_canaux)
                    ET.SubElement(shot, "number").text = str(obj_shot.number)
                    # ET.SubElement(shot, "lot").text = str(obj_shot.lot)
                    # Param modhs plus utilisé
                    # modhs = ET.SubElement(shot, "modhs")
                    # ET.SubElement(modhs, "type").text = str(obj_shot.modhs.get("type", ""))
                    # ET.SubElement(modhs, "version").text = str(obj_shot.modhs.get("version", ""))
                    # paramshs_red = ET.SubElement(modhs, "paramshs")
                    # ET.SubElement(paramshs_red, "chanel").text = str(
                    #     obj_shot.modhs.get("paramshs", {}).get("Rouge", {}).get("channel", "Rouge"))
                    # ET.SubElement(paramshs_red, "k").text = str(
                    #     obj_shot.modhs.get("paramshs", {}).get("Rouge", {}).get("k", ""))
                    # ET.SubElement(paramshs_red, "e").text = str(
                    #     obj_shot.modhs.get("paramshs", {}).get("Rouge", {}).get("e", ""))
                    # ET.SubElement(paramshs_red, "a").text = str(
                    #     obj_shot.modhs.get("paramshs", {}).get("Rouge", {}).get("a", ""))
                    # ET.SubElement(paramshs_red, "hsmin").text = str(
                    #     obj_shot.modhs.get("paramshs", {}).get("Rouge", {}).get("hsmin", ""))
                    # paramshs_green = ET.SubElement(modhs, "paramshs")
                    # ET.SubElement(paramshs_green, "chanel").text = str(
                    #     obj_shot.modhs.get("paramshs", {}).get("Vert", {}).get("channel", "Vert"))
                    # ET.SubElement(paramshs_green, "k").text = str(
                    #     obj_shot.modhs.get("paramshs", {}).get("Vert", {}).get("k", ""))
                    # ET.SubElement(paramshs_green, "e").text = str(
                    #     obj_shot.modhs.get("paramshs", {}).get("Vert", {}).get("e", ""))
                    # ET.SubElement(paramshs_green, "a").text = str(
                    #     obj_shot.modhs.get("paramshs", {}).get("Vert", {}).get("a", ""))
                    # ET.SubElement(paramshs_green, "hsmin").text = str(
                    #     obj_shot.modhs.get("paramshs", {}).get("Vert", {}).get("hsmin", ""))
                    # paramshs_blue = ET.SubElement(modhs, "paramshs")
                    # ET.SubElement(paramshs_blue, "chanel").text = str(
                    #     obj_shot.modhs.get("paramshs", {}).get("Bleu", {}).get("channel", "Bleu"))
                    # ET.SubElement(paramshs_blue, "k").text = str(
                    #     obj_shot.modhs.get("paramshs", {}).get("Bleu", {}).get("k", ""))
                    # ET.SubElement(paramshs_blue, "e").text = str(
                    #     obj_shot.modhs.get("paramshs", {}).get("Bleu", {}).get("e", ""))
                    # ET.SubElement(paramshs_blue, "a").text = str(
                    #     obj_shot.modhs.get("paramshs", {}).get("Bleu", {}).get("a", ""))
                    # ET.SubElement(paramshs_blue, "hsmin").text = str(
                    #     obj_shot.modhs.get("paramshs", {}).get("Bleu", {}).get("hsmin", ""))
                    # paramshs_ir = ET.SubElement(modhs, "paramshs")
                    # ET.SubElement(paramshs_ir, "chanel").text = str(
                    #     obj_shot.modhs.get("paramshs", {}).get("IR", {}).get("channel", "IR"))
                    # ET.SubElement(paramshs_ir, "k").text = str(
                    #     obj_shot.modhs.get("paramshs", {}).get("IR", {}).get("k", ""))
                    # ET.SubElement(paramshs_ir, "e").text = str(
                    #     obj_shot.modhs.get("paramshs", {}).get("IR", {}).get("e", ""))
                    # ET.SubElement(paramshs_ir, "a").text = str(
                    #     obj_shot.modhs.get("paramshs", {}).get("IR", {}).get("a", ""))
                    # ET.SubElement(paramshs_ir, "hsmin").text = str(
                    #     obj_shot.modhs.get("paramshs", {}).get("IR", {}).get("hsmin", ""))

                    ET.SubElement(shot, "actif").text = str(int(obj_shot.active))
                    ET.SubElement(shot, "zi").text = str(int(obj_shot.zi))
                    ET.SubElement(shot, "qualite").text = str(obj_shot.quality)
                    ET.SubElement(shot, "note").text = str(obj_shot.note)
                    ET.SubElement(shot, "time").text = str(obj_shot.t.strftime("%H%M%S"))
                    ET.SubElement(shot, "sun_height").text = str(obj_shot.sun_height)
                    ET.SubElement(shot, "pose").text = str(obj_shot.shutter)
                    ET.SubElement(shot, "tdi").text = str(obj_shot.tdi)
                    ET.SubElement(shot, "fnumber").text = str(obj_shot.fnumber)
                    ET.SubElement(shot, "section").text = str(obj_shot.section)
                    ET.SubElement(shot, "style").text = str(obj_shot.style)
                    ET.SubElement(shot, "resolution_moy").text = str(obj_shot.resolution_mean)
                    ET.SubElement(shot, "resolution_min").text = str(obj_shot.resolution_min)
                    ET.SubElement(shot, "resolution_max").text = str(obj_shot.resolution_max)
                    ET.SubElement(shot, "overlap").text = str(obj_shot.overlap)
                    ET.SubElement(shot, "overlap_max").text = str(min(obj_shot.overlap_prev, obj_shot.overlap_next))
                    ET.SubElement(shot, "overlap_min").text = str(max(obj_shot.overlap_prev, obj_shot.overlap_next))

                    polygon2d = ET.SubElement(shot, "polygon2d")
                    ET.SubElement(polygon2d, "nb_pt").text = str(obj_shot.polygon2d.get("nb_pt", "0"))
                    for x, y in obj_shot.polygon2d.get("emprise", []):
                        ET.SubElement(polygon2d, "x").text = str(x)
                        ET.SubElement(polygon2d, "y").text = str(y)

                    model = ET.SubElement(shot, "model")
                    pt3d = ET.SubElement(model, "pt3d")
                    ET.SubElement(pt3d, "x").text = str(obj_shot.imc.x_pos)
                    ET.SubElement(pt3d, "y").text = str(obj_shot.imc.y_pos)
                    ET.SubElement(pt3d, "z").text = str(obj_shot.imc.z_pos)
                    quaternion = ET.SubElement(model, "quaternion")
                    qx, qy, qz, qw = obj_shot.imc.quaternion
                    ET.SubElement(quaternion, "x").text = str(qx)
                    ET.SubElement(quaternion, "y").text = str(qy)
                    ET.SubElement(quaternion, "z").text = str(qz)
                    ET.SubElement(quaternion, "w").text = str(qw)
                    ET.SubElement(model, "lock").text = str(obj_shot.imc.lock)
                    if obj_shot.imc.dict_syst is not None:
                        syst_bde = ET.SubElement(model, "systbde")
                        ET.SubElement(syst_bde, "type").text = str(obj_shot.imc.dict_syst["id"])
                        ET.SubElement(syst_bde, "CylA").text = str(obj_shot.imc.dict_syst["S1"])
                        ET.SubElement(syst_bde, "CylB").text = str(obj_shot.imc.dict_syst["S2"])

                    nadir = ET.SubElement(shot, "nadir")
                    pt3d = ET.SubElement(nadir, "pt3d")
                    ET.SubElement(pt3d, "x").text = str(round(obj_shot.imc.x_nadir, 3))
                    ET.SubElement(pt3d, "y").text = str(round(obj_shot.imc.y_nadir, 3))
                    ET.SubElement(pt3d, "z").text = str(round(obj_shot.imc.z_nadir, 3))
                    # trajecto = ET.SubElement(shot, "trajecto")
                    # pt3d = ET.SubElement(trajecto, "pt3d")
                    # ET.SubElement(pt3d, "x").text = str(obj_shot.trajecto.get("x", ""))
                    # ET.SubElement(pt3d, "y").text = str(obj_shot.trajecto.get("y", ""))
                    # ET.SubElement(pt3d, "z").text = str(obj_shot.trajecto.get("z", ""))
                    indicator = ET.SubElement(shot, "indicator")
                    ET.SubElement(indicator, "value").text = str(obj_shot.indicator.get("value", ""))
                    ET.SubElement(indicator, "type").text = str(obj_shot.indicator.get("type", ""))
                    platf_info = ET.SubElement(shot, "platf_info")
                    ET.SubElement(platf_info, "B").text = str(obj_shot.platf_info.get("value", "B"))
                    ET.SubElement(platf_info, "E").text = str(obj_shot.platf_info.get("value", "E"))
                    ET.SubElement(platf_info, "D").text = str(obj_shot.platf_info.get("value", "D"))
                    list_shot += [shot]

                # strip
                if len(list_shot) == 0:
                    continue
                strip = ET.Element("bande", {})
                ET.SubElement(strip, "axe").text = str(obj_strip.axe)
                ET.SubElement(strip, "number").text = str(obj_strip.number)
                ET.SubElement(strip, "actif").text = str(int(obj_strip.active))
                ET.SubElement(strip, "trans").text = str(int(obj_strip.cross))
                ET.SubElement(strip, "kappa").text = str(obj_strip.kappa)
                ET.SubElement(strip, "a").text = str(obj_strip.param_line[0])
                ET.SubElement(strip, "b").text = str(obj_strip.param_line[1])
                ET.SubElement(strip, "c").text = str(obj_strip.param_line[2])
                ET.SubElement(strip, "nb_section").text = str(obj_strip.nb_section)
                strip.extend(list_shot)
                list_strip += [strip]

            # flight
            if len(list_strip) == 0:
                continue
            flight = ET.Element("vol", {})
            ET.SubElement(flight, "number").text = str(obj_flight.number)
            ET.SubElement(flight, "logname").text = str(obj_flight.logname)
            ET.SubElement(flight, "mission").text = str(obj_flight.mission)
            ET.SubElement(flight, "date").text = str(obj_flight.date.strftime("%d%m%Y"))
            ET.SubElement(flight, "actif").text = str(int(obj_flight.active))
            ET.SubElement(flight, "qualite").text = str(obj_flight.quality)
            flight.extend(list_strip)
            system_sensor = ET.SubElement(flight, "system_sensor")
            ET.SubElement(system_sensor, "actif").text = obj_flight.system_sensor.get("actif", "")
            ET.SubElement(system_sensor, "avion").text = obj_flight.system_sensor.get("avion", "")
            ET.SubElement(system_sensor, "omega").text = obj_flight.system_sensor.get("omega", "")
            ET.SubElement(system_sensor, "phi").text = obj_flight.system_sensor.get("phi", "")
            ET.SubElement(system_sensor, "kappa").text = obj_flight.system_sensor.get("kappa", "")
            ET.SubElement(system_sensor, "refraction").text = obj_flight.system_sensor.get("refraction", "")
            ET.SubElement(system_sensor, "trappe").text = obj_flight.system_sensor.get("trappe", "")
            ratachement_antenne = ET.SubElement(system_sensor, "ratachement_antenne")
            pt3d = ET.SubElement(ratachement_antenne, "pt3d")
            ET.SubElement(pt3d, "x").text = obj_flight.system_sensor.get("rattachement_antenne", {}).get("x", "")
            ET.SubElement(pt3d, "y").text = obj_flight.system_sensor.get("rattachement_antenne", {}).get("x", "")
            ET.SubElement(pt3d, "z").text = obj_flight.system_sensor.get("rattachement_antenne", {}).get("x", "")

            sensor = ET.SubElement(system_sensor, "sensor")
            cam_flight = self.project.camera[obj_flight.system_sensor.get("sensor", "")]
            ET.SubElement(sensor, "name").text = str(cam_flight.name)
            ET.SubElement(sensor, "objectif").text = str(cam_flight.lens)
            ET.SubElement(sensor, "origine").text = str(cam_flight.origin)
            ET.SubElement(sensor, "argentique").text = str(int(cam_flight.argentic))
            ET.SubElement(sensor, "calibration_date").text = str(cam_flight.calibration_date.strftime("%d-%m-%Y"))
            ET.SubElement(sensor, "serial_number").text = str(cam_flight.serial_number)
            usefull_frame = ET.SubElement(sensor, "usefull-frame")
            rect = ET.SubElement(usefull_frame, "rect")
            ET.SubElement(rect, "x").text = "0"
            ET.SubElement(rect, "y").text = "0"
            ET.SubElement(rect, "w").text = str(cam_flight.w)
            ET.SubElement(rect, "h").text = str(cam_flight.h)
            dark_frame = ET.SubElement(sensor, "dark-frame")
            rect = ET.SubElement(dark_frame, "rect")
            ET.SubElement(rect, "x").text = "0"
            ET.SubElement(rect, "y").text = "0"
            ET.SubElement(rect, "w").text = "0"
            ET.SubElement(rect, "h").text = "0"
            ET.SubElement(dark_frame, "apply_zone").text = ""
            focal = ET.SubElement(sensor, "focal")
            pt3d = ET.SubElement(focal, "pt3d")
            ET.SubElement(pt3d, "x").text = str(cam_flight.x_ppa)
            ET.SubElement(pt3d, "y").text = str(cam_flight.y_ppa)
            ET.SubElement(pt3d, "z").text = str(cam_flight.focal)
            ET.SubElement(sensor, "pixel_size").text = str(cam_flight.pixel_size)
            ET.SubElement(sensor, "orientation").text = str(cam_flight.orientation)
            list_flight += [flight]

        project.extend(list_flight)
        tree = ET.ElementTree(root)
        indent_ta(root)
        tree.write(str(path_out), encoding='ISO-8859-1', xml_declaration=True)

    def to_ogr(self, path_out: Union[str, Path], corlin: bool = True, ogr_driver: Union[str, None] = None,
               writer: Union[str, dict] = "ori", creation_options: Union[dict, None] = None,
               shift_kappa: int = 0, seq_angle: str = "xyz", format_datetime: str = "%d/%m/%Y %H:%M:%S",
               extent: bool = False,
               filter_flight: Union[Callable[[Flight], bool], None] = None,
               filter_strip: Union[Callable[[Strip], bool], None] = None,
               filter_shot: Union[Callable[[Shot], bool], None] = None,
               callback: Union[Callable[[str, float], Any], None] = None) -> None:
        """
        Save the Ta as vector file.
        Ta elements can be filtered with filter_flight, filter_strip and filter_shot functions.

        :param path_out: path to the vector file
        :param corlin: remove scale factor
        :param ogr_driver: name of the driver to use, if not specified, the driver is guessed from the extension
        :param writer: name of the writer to use
        :param creation_options: creation options https://gdal.org/drivers/vector/index.html
        :param shift_kappa: shift to apply on the kappa angle
        :param seq_angle: specifies sequence of axes for rotations
        :param format_datetime: datetime format
        :param extent: geometry as shot extent
        :param filter_flight: function used to filter a flight
        :param filter_strip: function used to filter a strip
        :param filter_shot: function used to filter a shot
        :param callback: Progress callback
        """

        path_out = Path(path_out)
        # Writer
        if isinstance(writer, str):
            try:
                writer = getattr(Writer, writer).value
            except AttributeError:
                try:
                    with open(writer, 'r') as file:
                        writer = json.load(file)
                except FileNotFoundError:
                    raise ValueError("le writer n'est ni un writer par défaut ni un chemin valide")

        # Camera
        dir_cam = path_out.parent.joinpath("camera")
        dir_cam.mkdir(exist_ok=True)
        for cam in self.project.camera.values():
            cam.to_xml(dir_cam)

        # Creation vector file
        dest_srs = osr.SpatialReference()
        dest_srs.ImportFromWkt(self.project.proj_engine.crs.to_wkt())
        memdriver = ogr.GetDriverByName('MEMORY')
        mem_dataSource = memdriver.CreateDataSource('memData')
        if not extent:
            layer_data = mem_dataSource.CreateLayer("Ta", dest_srs, geom_type=ogr.wkbPoint)
        else:
            layer_data = mem_dataSource.CreateLayer("Ta", dest_srs, geom_type=ogr.wkbPolygon)
        for key in writer:
            field = ogr.FieldDefn(key, FEATURE_FORMAT[key])
            layer_data.CreateField(field)
        featureDefn = layer_data.GetLayerDefn()
        list_shot = list(self.project.get_shots(filter_flight, filter_strip, filter_shot))
        nbr_shot, ind_shot = len(list_shot), 0
        for flight in self.project.get_flights(filter_flight):
            for strip in flight.get_strips(filter_strip):
                for shot in strip.get_shots(filter_shot):
                    if callback is not None:
                        callback("OGR", ind_shot / nbr_shot)
                    ind_shot += 1
                    x, y, z = shot.imc.sommet
                    o, p, k = shot.imc.opk

                    if seq_angle == "yxz":
                        p, o, k = -R.from_euler("xyz", -np.array([o, p, k]), degrees=True).as_euler(seq_angle,
                                                                                                    degrees=True)
                    elif seq_angle != "xyz":
                        raise ValueError(f"La convention angulaire doit être xyz ou yxz")

                    k += shift_kappa

                    # Scale factor correction
                    z = shot.imc.get_Z_add_scale_factor(self.project.dem) if corlin else z

                    feature = ogr.Feature(featureDefn)
                    if not extent:
                        geom = ogr.Geometry(ogr.wkbPoint)
                        geom.AddPoint(x, y)
                    else:
                        geom = ogr.CreateGeometryFromWkt(shot.extent.wkt)
                    feature.SetGeometry(geom)
                    if "ID" in writer:
                        feature.SetField("ID", shot.image)
                    if "FLIGHT" in writer:
                        feature.SetField("FLIGHT", flight.number)
                    if "STRIP" in writer:
                        feature.SetField("STRIP", strip.number)
                    if "SHOT" in writer:
                        feature.SetField("SHOT", shot.number)
                    if "TRANS" in writer:
                        feature.SetField("TRANS", strip.cross)
                    if "X" in writer:
                        feature.SetField("X", round(x, 3))
                    if "Y" in writer:
                        feature.SetField("Y", round(y, 3))
                    if "Z" in writer:
                        feature.SetField("Z", round(z, 3))
                    if "O" in writer:
                        feature.SetField("O", round(o, 5))
                    if "P" in writer:
                        feature.SetField("P", round(p, 5))
                    if "K" in writer:
                        feature.SetField("K", round(k, 5))
                    if "DATE" in writer:
                        feature.SetField("DATE",
                                         shot.t.strftime(format_datetime.split()[0]) if shot.t is not None else None)
                    if "TIME" in writer:
                        feature.SetField("TIME",
                                         shot.t.strftime(format_datetime.split()[1]) if shot.t is not None else None)
                    if "CAMERA" in writer:
                        feature.SetField("CAMERA", shot.imc.camera.origin)
                    if "SHOT_PREV" in writer:
                        feature.SetField("SHOT_PREV", getattr(shot.shot_prev, "image", "NONE"))
                    if "SHOT_NEXT" in writer:
                        feature.SetField("SHOT_NEXT", getattr(shot.shot_next, "image", "NONE"))
                    if "OVERLAP_PREV" in writer:
                        feature.SetField("OVERLAP_PREV", round(100 * shot.overlap_prev, 2))
                    if "OVERLAP_NEXT" in writer:
                        feature.SetField("OVERLAP_NEXT", round(100 * shot.overlap_next, 2))
                    if "STRIP_PREV" in writer:
                        feature.SetField("STRIP_PREV", getattr(strip.strip_prev, "number", "NONE"))
                    if "STRIP_NEXT" in writer:
                        feature.SetField("STRIP_NEXT", getattr(strip.strip_next, "number", "NONE"))
                    if "SIDELAP_PREV" in writer:
                        feature.SetField("SIDELAP_PREV", round(100 * shot.sidelap_prev, 2))
                    if "SIDELAP_NEXT" in writer:
                        feature.SetField("SIDELAP_NEXT", round(100 * shot.sidelap_next, 2))
                    layer_data.CreateFeature(feature)

        # Save
        creation_options = {} if creation_options is None else creation_options
        ogr_driver = get_ogr_driver(path_out, ogr_driver)
        name_driver = ogr_driver.GetName()
        path_out.unlink(missing_ok=True)
        if name_driver == "CSV" and path_out.suffix.lower() != ".csv":
            creation_options.setdefault("SEPARATOR", "SPACE")
            path_csv = path_out.with_suffix(".csv")
            path_csv.unlink(missing_ok=True)
            dataSource = ogr_driver.CreateDataSource(str(path_csv))
            dataSource.CopyLayer(layer_data, new_name="Ta",
                                 options=[f"{key}={value}" for key, value in creation_options.items()])
            del dataSource
            path_csv.rename(path_out)
        else:
            dataSource = ogr_driver.CreateDataSource(str(path_out))
            dataSource.CopyLayer(layer_data, new_name="Ta",
                                 options=[f"{key}={value}" for key, value in creation_options.items()])
            del dataSource


    def to_ori(self, dir_ori: Union[str, Path], corlin: bool = True,
                filter_flight: Union[Callable[[Flight], bool], None] = None,
                filter_strip: Union[Callable[[Strip], bool], None] = None,
                filter_shot: Union[Callable[[Shot], bool], None] = None,
                callback: Union[Callable[[str, float], Any], None] = None) -> None:

        """
        Save the Ta as vector file.
        Ta elements can be filtered with filter_flight, filter_strip and filter_shot functions.

        :param dir_ori: path to the ori directory
        :param corlin: remove scale factor
        :param filter_flight: function used to filter a flight
        :param filter_strip: function used to filter a strip
        :param filter_shot: function used to filter a shot
        :param callback: Progress callback
        """
        dir_ori = Path(dir_ori)
        list_shot = list(self.project.get_shots(filter_flight, filter_strip, filter_shot))
        nbr_shot = len(list_shot)
        for ind_shot, shot in enumerate(list_shot):
            if callback is not None:
                callback("ORI", ind_shot / nbr_shot)
            path_ori = dir_ori.joinpath(shot.image).with_suffix(".ori")
            shot.to_ori(path_ori, corlin=corlin, dem=self.project.dem)

    def to_eo(self, path_out: Union[str, Path], corlin: bool = True,
              filter_flight: Union[Callable[[Flight], bool], None] = None,
              filter_strip: Union[Callable[[Strip], bool], None] = None,
              filter_shot: Union[Callable[[Shot], bool], None] = None,
              callback: Union[Callable[[str, float], Any], None] = None) -> None:
        """
        Save the Ta as eo file (UltraMap).
        Ta elements can be filtered with filter_flight, filter_strip and filter_shot functions.

        :param path_out: path to the XML file.
        :param corlin: remove scale factor.
        :param filter_flight: function used to filter a flight
        :param filter_strip: function used to filter a strip
        :param filter_shot: function used to filter a shot
        :param callback: Progress callback.
        """
        path_out = Path(path_out)
        date_now = datetime.now()
        list_txt = ["#Exterior Orientations \n#Software: UltraMap Aerial v5.4 (Build 37.0.2112.2001) \n#© Vexcel "
                    f"Imaging GmbH. All rights reserved. \n#Date: {date_now.strftime('%Y-%m-%d')}"
                    f" \n#Time: {date_now.strftime('%H:%M:%S')} \n\n[PARAMETERS] \n"
                    "FILE_VERSION;1 \nUNIT_SYMBOL;m \nUNIT_CONVERSION_FACTOR;1 \nEPSG_CODE;2154 \n\n[Events]\n"
                    ]
        list_txt += [f"#{'NR':>6};", f"{'X':>21};", f"{'Y':>21};", f"{'Z':>21};", f"{'Rot_X':>21};", f"{'Rot_Y':>21};",
                     f"{'Rot_Z':>21};"]
        list_pnt = []
        list_shot = list(self.project.get_shots(filter_flight, filter_strip, filter_shot))
        nbr_shot = len(list_shot)
        for ind_shot, shot in enumerate(list_shot):
            if callback is not None:
                callback("EO", ind_shot / nbr_shot)
            x, y, z = shot.imc.sommet
            pok = -R.from_matrix(shot.imc.mat).as_euler("yxz", degrees=True)

            # Scale factor correction
            if corlin:
                z = shot.imc.get_Z_add_scale_factor(self.project.dem)
            list_pnt += [["\n" + f"{shot.number:7}", f"{x:21}", f"{y:21}", f"{z:21}", f"{pok[1]:21}",
                          f"{pok[0]:21}", f"{pok[2]:21}"]]

        path_out.write_text("".join(list_txt) + ";".join(itertools.chain(*sorted(list_pnt, key=lambda p: int(p[0])))))

    def to_conl(self, dir_conl: Union[str, Path], corlin: bool = True,
                filter_flight: Union[Callable[[Flight], bool], None] = None,
                filter_strip: Union[Callable[[Strip], bool], None] = None,
                filter_shot: Union[Callable[[Shot], bool], None] = None,
                callback: Union[Callable[[str, float], Any], None] = None) -> None:
        """
        Save the Ta as light conical file (IGN).
        Ta elements can be filtered with filter_flight, filter_strip and filter_shot functions.

        :param dir_conl: path to the conl directory.
        :param corlin: remove scale factor.
        :param filter_flight: function used to filter a flight
        :param filter_strip: function used to filter a strip
        :param filter_shot: function used to filter a shot
        :param callback: Progress callback.
        """
        dir_conl = Path(dir_conl)
        list_shot = list(self.project.get_shots(filter_flight, filter_strip, filter_shot))
        nbr_shot = len(list_shot)
        for ind_shot, shot in enumerate(list_shot):
            if callback is not None:
                callback("CONl", ind_shot / nbr_shot)
            path_conl = dir_conl.joinpath(shot.image).with_suffix(".CON")
            shot.to_conl(path_conl, corlin=corlin, dem=self.project.dem)

    def to_rpc(self, dir_rpc: Union[str, Path], size_grid: int = 100, order: int = 2,
               true_rpc: bool = True, fact_rpc_carto: Union[float, None] = None,
               filter_flight: Union[Callable[[Flight], bool], None] = None,
               filter_strip: Union[Callable[[Strip], bool], None] = None,
               filter_shot: Union[Callable[[Shot], bool], None] = None,
               callback: Union[Callable[[str, float], Any], None] = None) -> None:
        """
        Save the Ta as rational polynomial coefficients files.

        :param dir_rpc: path to the RPC directory.
        :param size_grid: grid step length in which the RPC parameters will be estimated.
        :param order: order of the rational polynomials.
        :param true_rpc: whether to compute RPC in geographical coordinates.
        :param fact_rpc_carto: factor to apply to data if rpc in cartographic coordinates.
        :param filter_flight: function used to filter a flight.
        :param filter_strip: function used to filter a strip.
        :param filter_shot: function used to filter a shot.
        :param callback: Progress callback.
        """
        dir_rpc = Path(dir_rpc)
        list_shot = list(self.project.get_shots(filter_flight, filter_strip, filter_shot))
        nbr_shot = len(list_shot)
        for ind_shot, shot in enumerate(list_shot):
            if callback is not None:
                callback("RPC", ind_shot / nbr_shot)
            path_rpc = dir_rpc.joinpath(shot.image + "_RPC").with_suffix(".txt")
            shot.to_rpc(self.project.dem, path_rpc, size_grid, order, true_rpc, fact_rpc_carto)

    def to_gcp(self, path_gcp: Union[str, Path], size_grid: int = 100,
               filter_flight: Union[Callable[[Flight], bool], None] = None,
               filter_strip: Union[Callable[[Strip], bool], None] = None,
               filter_shot: Union[Callable[[Shot], bool], None] = None,
               callback: Union[Callable[[str, float], Any], None] = None) -> None:
        """
        Save the Ta as GCP file.

        :param path_gcp: path to the GCP file.
        :param size_grid: grid step length in which the GCP will be extracted.
        :param filter_flight: function used to filter a flight.
        :param filter_strip: function used to filter a strip.
        :param filter_shot: function used to filter a shot.
        :param callback: Progress callback.
        """
        dict_gcp = {}
        list_shot = list(self.project.get_shots(filter_flight, filter_strip, filter_shot))
        nbr_shot = len(list_shot)
        for ind_shot, shot in enumerate(list_shot):
            if callback is not None:
                callback("GCP", ind_shot / nbr_shot)
            dict_gcp[shot.image] = shot.to_gcp(self.project.dem, size_grid)
        with open(path_gcp, "wb") as f:
            pickle.dump(dict_gcp, f)

    def to_absolute(self, size_grid: int = 100, method: int = 1,
                    filter_flight: Union[Callable[[Flight], bool], None] = None,
                    filter_strip: Union[Callable[[Strip], bool], None] = None,
                    filter_shot: Union[Callable[[Shot], bool], None] = None,
                    callback: Union[Callable[[str, float], Any], None] = None) -> None:
        """
        Space resection of each image.

        :param size_grid: grid step length in which the ori parameters will be estimated.
        :param method: computing method
        :param filter_flight: function used to filter a flight.
        :param filter_strip: function used to filter a strip.
        :param filter_shot: function used to filter a shot.
        :param callback: Progress callback.
        """
        list_shot = list(self.project.get_shots(filter_flight, filter_strip, filter_shot))
        nbr_shot = len(list_shot)
        for ind_shot, shot in enumerate(list_shot):
            if callback is not None:
                callback("Absolute", ind_shot / nbr_shot)
            shot.to_absolute(self.project.dem, size_grid, method)

    def save_extent_shot(self, path_extent: Union[str, Path], ogr_driver: Union[str, None] = None) -> None:
        """
        Save image extents.

        :param path_extent: path to the shp file.
        :param ogr_driver: name of the driver to use, if not specified, the driver is guessed from the extension
        """
        dest_srs = osr.SpatialReference()
        dest_srs.ImportFromWkt(self.project.proj_engine.crs.to_wkt())
        ogr_driver = get_ogr_driver(path_extent, ogr_driver)

        memdriver = ogr.GetDriverByName('MEMORY')
        mem_dataSource = memdriver.CreateDataSource('memData')
        layer_extent = mem_dataSource.CreateLayer("Emprise", dest_srs, geom_type=ogr.wkbPolygon)
        field_name = ogr.FieldDefn("Name", ogr.OFTString)
        layer_extent.CreateField(field_name)
        featureDefn = layer_extent.GetLayerDefn()
        for shot in self.project.get_shots():
            feature = ogr.Feature(featureDefn)
            feature.SetField("Name", shot.image)
            feature.SetGeometry(ogr.CreateGeometryFromWkt(shot.extent.wkt))
            layer_extent.CreateFeature(feature)

        # Save
        ogr_driver.CopyDataSource(mem_dataSource, str(path_extent))

    def save_extent_strip(self, path_extent: Union[str, Path], ogr_driver: Union[str, None] = None) -> None:
        """
        Save strip extents.

        :param path_extent: path to the shp file.
        :param ogr_driver: name of the driver to use, if not specified, the driver is guessed from the extension
        """
        ogr_driver = get_ogr_driver(path_extent, ogr_driver)
        memdriver = ogr.GetDriverByName('MEMORY')
        mem_dataSource = memdriver.CreateDataSource('memData')
        layer_extent = mem_dataSource.CreateLayer("Emprise", geom_type=ogr.wkbPolygon)
        featureDefn = layer_extent.GetLayerDefn()
        for flight in self.project.flight.values():
            for strip in flight.strip.values():
                feature = ogr.Feature(featureDefn)
                feature.SetGeometry(ogr.CreateGeometryFromWkt(strip.extent.wkt))
                layer_extent.CreateFeature(feature)

        # Save
        ogr_driver.CopyDataSource(mem_dataSource, str(path_extent))

    def save_extent_project(self, path_extent: Union[str, Path], ogr_driver: Union[str, None] = None) -> None:
        """
        Save project extent.

        :param path_extent: path to the shp file.
        :param ogr_driver: name of the driver to use, if not specified, the driver is guessed from the extension
        """
        ogr_driver = get_ogr_driver(path_extent, ogr_driver)
        memdriver = ogr.GetDriverByName('MEMORY')
        mem_dataSource = memdriver.CreateDataSource('memData')
        layer_extent = mem_dataSource.CreateLayer("Emprise", geom_type=ogr.wkbPolygon)
        featureDefn = layer_extent.GetLayerDefn()
        feature = ogr.Feature(featureDefn)
        feature.SetGeometry(ogr.CreateGeometryFromWkt(self.project.extent.wkt))
        layer_extent.CreateFeature(feature)

        # Save
        ogr_driver.CopyDataSource(mem_dataSource, str(path_extent))

    def __deepcopy__(self, memodict: dict) -> Ta:
        """Create a deepcopy of the Ta object."""
        cls = self.__class__
        result = cls.__new__(cls)
        memodict[id(self)] = result
        for k, v in self.__dict__.items():
            setattr(result, k, deepcopy(v, memodict))
        return result


if __name__ == "__main__":
    pass

