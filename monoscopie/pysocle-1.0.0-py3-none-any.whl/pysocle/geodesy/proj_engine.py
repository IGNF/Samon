"""
    A module for manipulating a cartographic system.
"""

import numpy as np
import pyproj
from typing import Union, List
from pysocle.geodesy.projection_list import ProjectionList


class ProjEngine:
    """
    This class provides functions for using a cartographic system.

    :param proj: projection

    .. note::
        pyproj is required.

    """
    def __init__(self, proj: ProjectionList=ProjectionList.RGF93LAMB93):
        self.projection_list = proj
        self.crs = pyproj.CRS.from_string(proj.value["auth"])
        self.crs_geoc = pyproj.CRS.from_epsg(proj.value["epsg_geoc"])
        self.crs_geog = pyproj.CRS.from_epsg(proj.value["epsg_geog"])
        self.proj = pyproj.Proj(self.crs)

        # Transform cartographic coordinates to geographic coordinates
        self.carto_to_geog = pyproj.Transformer.from_crs(self.crs, self.crs_geog).transform
        # Transform geographic coordinates to cartographic coordinates
        self.geog_to_carto = pyproj.Transformer.from_crs(self.crs_geog, self.crs).transform
        # Transform cartographic coordinates to geocentric coordinates
        self.carto_to_geoc = pyproj.Transformer.from_crs(self.crs, self.crs_geoc).transform
        # Transform geocentric coordinates to cartographic coordinates
        self.geoc_to_carto = pyproj.Transformer.from_crs(self.crs_geoc, self.crs).transform


    def get_scale_factor(self, x_carto: Union[np.array, List[float], float],
                         y_carto: Union[np.array, List[float], float]) -> np.array:
        """
            Compute scale factor.
            Values are extracted from pyproj.

            :param x_carto: x cartographic coordinates
            :param y_carto: y cartographic coordinates

            :return: scale factor and meridian convergence
        """
        x_geog, y_geog = self.carto_to_geog(x_carto, y_carto)
        return np.array(self.proj.get_factors(x_geog, y_geog).meridional_scale) - 1

    def get_meridian_convergence(self, x_carto: Union[np.array, List[float], float],
                                 y_carto: Union[np.array, List[float], float]) -> float:
        """
            Compute meridian convergence.
            Values are extracted from pyproj.

            :param x_carto: x cartographic coordinates
            :param y_carto: y cartographic coordinates

            :return: meridian convergence in degree
        """
        x_geog, y_geog = self.carto_to_geog(x_carto, y_carto)
        return -np.array(self.proj.get_factors(x_geog, y_geog).meridian_convergence)