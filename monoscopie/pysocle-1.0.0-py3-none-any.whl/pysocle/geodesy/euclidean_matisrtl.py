"""
    A module for manipulating a Euclidean Matis system.
"""
import numpy as np


class EuclideanMatisrtl:
    """
    This class represents a Euclidean Matis system.

    .. note::
        A euclidean Matis system is an approximate local Euclidean reference system.
        Such a system has the major advantage of not being dependant of a cartographic system.
        The development of cartographic projections library as PROJ tends to make this system obsolete.
        In most cases, it is better to use :class:`pysocle.geodesy.euclidean_topaero`.

    """
    def __init__(self, x_central, y_central):
        """
            Initiate a Euclidean system object.

        :param x_central: x coordinate of the central point of the Euclidean system
        :type x_central: float
        :param y_central: y coordinate of the central point of the Euclidean system
        :type y_central: float
        """
        self.x_central = x_central
        self.y_central = y_central
        self.r = 6366000  # rayon de la terre

    def world_to_euclidean(self, x, y, z):
        """
        Transform a point from the world coordinate reference system into the Euclidean coordinate reference system

       :param x: x coordinate of the point
       :type x: float, np.array, list
       :param y: y coordinate of the point
       :type y: float, np.array, list
       :param z: z coordinate of the point
       :type z: float, np.array, list

       :return: point in the Euclidean coordinate reference system
       :rtype: ([np.array, float], [np.array, float], [np.array, float])
        """
        x, y, z = np.array(x), np.array(y), np.array(z)
        dx = x - self.x_central
        dy = y - self.y_central
        tt = (dx ** 2 + dy ** 2) / (4 * self.r)
        cc = (self.r + z) / (tt + self.r)
        xe = dx * cc
        ye = dy * cc
        ze = ((self.r - tt) * cc) - self.r
        return xe, ye, ze

    def eucli_to_wordl(self, xe, ye, ze):
        """
        Transform a point from the Euclidean coordinate reference system into the world coordinate reference system.

       :param xe: x coordinate of the point
       :type xe: float, np.array, list
       :param ye: y coordinate of the point
       :type ye: float, np.array, list
       :param ze: z coordinate of the point
       :type ze: float, np.array, list

       :return: point in the Euclidean coordinate reference system
       :rtype: ([np.array, float], [np.array, float], [np.array, float])
        """
        xe, ye, ze = np.array(xe), np.array(ye), np.array(ze)
        rz = self.r + ze
        rh = (rz**2 + xe**2 + ye**2)**0.5
        rz = (2*self.r)/(rz + rh)
        x = self.x_central + (xe * rz)
        y = self.y_central + (ye * rz)
        z = rh - self.r
        return x, y, z
