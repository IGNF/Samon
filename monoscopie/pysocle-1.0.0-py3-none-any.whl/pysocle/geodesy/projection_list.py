"""A module with the list of the cartographic system allowed."""

from enum import Enum


class ProjectionList(Enum):
    """This class provides the list of the cartographic system allowed."""

    RGF93LAMB93 = {"auth": "IGNF:RGF93LAMB93", "ta": "Lambert93", "MatchAT": "RGF93\ /\ Lambert-93", "PMS3D": "L-93 :",
                   "epsg_geoc": 4964, "epsg_geog": 7084, "geoid": "RAF20"}
    """Projection de la métropole : Système=RGF93 - Projection=Lambert93"""

    RGF93CC42 = {"auth": "IGNF:RGF93CC42", "ta": "LAMBERT_CC42", "MatchAT": "", "PMS3D": "",
                 "epsg_geoc": 4964, "epsg_geog": 7084, "geoid": None}
    """Projection de la métropole : Système=RGF93 - Projection=CC42"""

    RGF93CC43 = {"auth": "IGNF:RGF93CC43", "ta": "LAMBERT_CC43", "MatchAT": "", "PMS3D": "",
                 "epsg_geoc": 4964, "epsg_geog": 7084, "geoid": None}
    """Projection de la métropole : Système=RGF93 - Projection=CC43"""

    RGF93CC44 = {"auth": "IGNF:RGF93CC44", "ta": "LAMBERT_CC44", "MatchAT": "", "PMS3D": "",
                 "epsg_geoc": 4964, "epsg_geog": 7084, "geoid": None}
    """Projection de la métropole : Système=RGF93 - Projection=CC44"""

    RGF93CC45 = {"auth": "IGNF:RGF93CC45", "ta": "LAMBERT_CC45", "MatchAT": "", "PMS3D": "",
                 "epsg_geoc": 4964, "epsg_geog": 7084, "geoid": None}
    """Projection de la métropole : Système=RGF93 - Projection=CC45"""

    RGF93CC46 = {"auth": "IGNF:RGF93CC46", "ta": "LAMBERT_CC46", "MatchAT": "", "PMS3D": "",
                 "epsg_geoc": 4964, "epsg_geog": 7084, "geoid": None}
    """Projection de la métropole : Système=RGF93 - Projection=CC46"""

    RGF93CC47 = {"auth": "IGNF:RGF93CC47", "ta": "LAMBERT_CC47", "MatchAT": "", "PMS3D": "",
                 "epsg_geoc": 4964, "epsg_geog": 7084, "geoid": None}
    """Projection de la métropole : Système=RGF93 - Projection=CC47"""

    RGF93CC48 = {"auth": "IGNF:RGF93CC48", "ta": "LAMBERT_CC48", "MatchAT": "", "PMS3D": "",
                 "epsg_geoc": 4964, "epsg_geog": 7084, "geoid": None}
    """Projection de la métropole : Système=RGF93 - Projection=CC48"""

    RGF93CC49 = {"auth": "IGNF:RGF93CC49", "ta": "LAMBERT_CC49", "MatchAT": "", "PMS3D": "",
                 "epsg_geoc": 4964, "epsg_geog": 7084, "geoid": None}
    """Projection de la métropole : Système=RGF93 - Projection=CC49"""

    RGF93CC50 = {"auth": "IGNF:RGF93CC50", "ta": "LAMBERT_CC50", "MatchAT": "", "PMS3D": "",
                 "epsg_geoc": 4964, "epsg_geog": 7084, "geoid": None}
    """Projection de la métropole : Système=RGF93 - Projection=CC50"""

    RGAF09UTM20 = {"auth": "IGNF:RGAF09UTM20", "ta": "UTM_WGS84_20nord", "MatchAT": r"WGS\ 84\ /\ UTM\ zone\ 20N", "PMS3D": "",
                   "epsg_geoc": 5487, "epsg_geog": 7086, "geoid": None}
    """Projection des Antilles : Système=RGAF09 - Projection=UTM20N"""

    RGFG95UTM22 = {"auth": "IGNF:RGFG95UTM22", "ta": "UTM_WGS84_f22nord", "MatchAT": "RGFG95\ /\ UTM\ zone\ 22N", "PMS3D": "",
                   "epsg_geoc": 4966, "epsg_geog": 7041, "geoid": None}
    """Projection de la Guyane : Système=RGFG95 - Projection=UTM22N"""

    RGR92UTM40S = {"auth": "IGNF:RGR92UTM40S", "ta": "UTM_WGS84_f40sud", "MatchAT": "", "PMS3D": "",
                   "epsg_geoc": 4970, "epsg_geog": 7037, "geoid": None}
    """Projection de la Réunion : Système=RGR92 - Projection=UTM40S"""

    RGSPM06U21 = {"auth": "IGNF:RGSPM06U21", "ta": "UTM_WGS84_f21nord", "MatchAT": "", "PMS3D": "",
                  "epsg_geoc": 4465, "epsg_geog": 7035, "geoid": None}
    """Projection de Saint Pierre et Miquelon : Système=RGSPM06- Projection=UTM21N"""

    RGM04UTM38S = {"auth": "IGNF:RGM04UTM38S", "ta": "UTM_WGS84_f38sud", "MatchAT": "", "PMS3D": "",
                   "epsg_geoc": 4468,"epsg_geog": 7039, "geoid": None}
    """Projection de Mayotte : Système=RGM04- Projection=UTM38S"""

    @classmethod
    def from_auth(cls, name):
        """
        Get the projection from id.

        :param name: id of the projection.
        :type name: str
        :return: Projection.
        :rtype: ProjectionList
        """
        for i in cls:
            if i.value["auth"] == name:
                return i
        raise ValueError(f"{name} n'est pas un id de projection valide")


    @classmethod
    def from_ta(cls, name):
        """
        Get the projection from ta id (IGN).

        :param name: ta id of the projection.
        :type name: str
        :return: Projection.
        :rtype: ProjectionList
        """
        for i in cls:
            if i.value["ta"].lower() == name.lower():
                return i
        raise ValueError(f"{name} n'est pas un id de projection valide")

    @classmethod
    def from_match_at(cls, name):
        """
        Get the projection from MatchAt id.

        :param name: MatchAt id of the projection.
        :type name: str
        :return: Projection.
        :rtype: ProjectionList
        """
        for i in cls:
            if i.value["MatchAT"] == name:
                return i
        raise ValueError(f"{name} n'est pas un id de projection valide")

    @classmethod
    def from_pms3d(cls, name):
        """
        Get the projection from PMS3D id.

        :param name: PMS3d id of the projection.
        :type name: str
        :return: Projection.
        :rtype: ProjectionList
        """
        for i in cls:
            if i.value["PMS3D"] == name:
                return i
        raise ValueError(f"{name} n'est pas un id de projection valide")


