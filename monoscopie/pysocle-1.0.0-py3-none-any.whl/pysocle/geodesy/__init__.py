"""
This package contains class and functions for manipulating geodesic system.
"""