"""A module for manipulating an euclidean Topaero system."""

import numpy as np
from scipy.spatial.transform import Rotation as R
from typing import Union, List, Tuple
from pysocle.geodesy.proj_engine import ProjEngine

class EuclideanTopaero:
    """
    This class represents a Euclidean Topaero system.

    :param x_central: x coordinate of the central point of the Euclidean system
    :param y_central: y coordinate of the central point of the Euclidean system
    :param proj_engine: kernel of geodesy calculation

    .. note::
        A Euclidean Topaero system is a local Euclidean reference system in which the collinear equation is valid.
        The cartographic system parameters must be known.

    """

    def __init__(self, x_central: float, y_central: float, proj_engine: ProjEngine):
        self.x_central = x_central
        self.y_central = y_central
        self.z_central = 0
        self.proj_engine = proj_engine
        self.rot_to_euclidean_local = self.topaero_matrix(self.x_central, self.y_central)

    def topaero_matrix(self, x: float, y:float) -> np.array:
        """
        Compute the transition matrix between the world system and the Euclidean system centred on a point.

        :param x: x coordinate of the central point of the Euclidean system
        :param y: y coordinate of the central point of the Euclidean system

        :return: transition matrix
        """
        lon, lat = self.proj_engine.carto_to_geog(x, y)
        gamma = self.proj_engine.get_meridian_convergence(x, y)

        # rot_to_euclidean_local = R.from_euler("z", -(90+gamma), degrees=True) *\
        #                          R.from_euler("y", -(90-lat), degrees=True) *\
        #                          R.from_euler("z", -lon, degrees=True)

        # Matrice de passage en coordonnees cartesiennes locales
        sl = np.sin(lon * np.pi/180)
        sp = np.sin(lat * np.pi/180)
        sg = np.sin(gamma * np.pi/180)
        cl = np.cos(lon * np.pi/180)
        cp = np.cos(lat * np.pi/180)
        cg = np.cos(gamma * np.pi/180)
        rot_to_euclidean_local = np.zeros((3, 3))
        rot_to_euclidean_local[0, 0] = -cg * sl - sg * sp * cl
        rot_to_euclidean_local[0, 1] = cg * cl - sg * sp * sl
        rot_to_euclidean_local[0, 2] = sg * cp
        rot_to_euclidean_local[1, 0] = sg * sl - cg * sp * cl
        rot_to_euclidean_local[1, 1] = -sg * cl - cg * sp * sl
        rot_to_euclidean_local[1, 2] = cg * cp
        rot_to_euclidean_local[2, 0] = cp * cl
        rot_to_euclidean_local[2, 1] = cp * sl
        rot_to_euclidean_local[2, 2] = sp
        return rot_to_euclidean_local

    @staticmethod
    def quaternion_to_mat_eucli(q: Union[List[float], np.array]) -> np.array:
        """
        Transform quaternions into a rotation matrix (TOPAERO convention)

        :param q: quaternion
        :type q: np.array, list

        :return: rotation matrix
        :rtype: np.array
        """
        mat = R.from_quat(q).as_matrix()
        # passage en convention TOPAERO
        # axe Z dans l'autre sens donc *-1 sur la dernière colonne
        mat = mat*np.array([1, 1, -1])
        # Inversion des deux premières colonnes + transposition
        mat = mat[:, [1, 0, 2]].T
        return mat

    @staticmethod
    def mat_eucli_to_quaternion(mat_eucli: np.array) -> np.array:
        """
        Transform rotation matrix (TOPAERO convention) into quaternions

        :param mat_eucli: quaternion

        :return: quaternion
        """
        # Passage en convention classique
        # Transposition + inversion des deux premières colonnes
        mat = mat_eucli.T[:, [1, 0, 2]]
        # axe Z dans l'autre sens donc *-1 sur la dernière colonne
        mat = mat*np.array([1, 1, -1])
        q = R.from_matrix(mat).as_quat()
        return q

    @staticmethod
    def opk_to_mat(opk: Union[List[float], np.array]) -> np.array:
        """
       Transform the OPK angles (World system) into rotation matrix (World system)

       :param opk: opk

       :return: rotation matrix
        """
        mat = R.from_euler('xyz', -np.array(opk), degrees=True).as_matrix()
        return mat

    @staticmethod
    def mat_to_opk(mat: np.array) -> np.array:
        """
       Transform the rotation matrix (World system) in the OPK angles (World system)

       :param mat: rotation matrix (World system)
       :type mat: matrix

       :return: opk
       :rtype: array
        """
        opk = -R.from_matrix(mat).as_euler("xyz", degrees=True)
        return opk

    def mat_to_mat_eucli(self, x: float, y: float, mat: np.array) -> np.array:
        """
       Transform the rotation matrix (World system) into rotation matrix (TOPAERO convention)

       :param x: x coordinate of the point
       :type x: float
       :param y: y coordinate of the point
       :type y: float
       :param mat: rotation matrix (World system)
       :type mat: array

       :return: rotation matrix (TOPAERO cnvention)
       :rtype: matrix
        """

        # *-1 sur les deux dernières lignes
        mat = mat*np.array([1, -1, -1]).reshape(-1, 1)

        # On est dans le repère de la projection, on passe dans le repere tangeant local
        matecef_to_rtl = self.topaero_matrix(x, y)
        mat_eucli = mat @ matecef_to_rtl @ self.rot_to_euclidean_local.T
        return mat_eucli

    def mat_eucli_to_mat(self, x:float, y:float, mat_eucli: np.array) -> np.array:
        """
        Transform the rotation matrix (TOPAERO cnvention) into rotation matrix (World system)

        :param x: x coordinate of the point
        :param y: y coordinate of the point
        :param mat_eucli: rotation matrix (TOPAERO cnvention)

        :return: rotation matrix (World system)
        """

        # On est dans le repère euclidien, on passe dans le repere de projection
        # Dans le repere tangeant local centré sur le sommet du cliché (xw, yw) RTL, les angles sont, par construction,
        # identiques à ceux du repere de projection (à un ajustement d'axe près, voir convention TopAERO).
        # Néanmoins, les angles sont souvent exprimées dans le repère local barycentrique (x_origin, y_origin),
        # il faut donc passé de l'un à l'autre.

        matecef_to_rtl = self.topaero_matrix(x, y)
        mat = mat_eucli @ self.rot_to_euclidean_local @ matecef_to_rtl.T

        # *-1 sur les deux dernières lignes
        mat = mat * np.array([1, -1, -1]).reshape(-1, 1)
        return mat

    def quaternion_to_opk(self, x: float, y: float, q: Union[List, np.array]) -> np.array:
        """
        Transform the quaternions (Euclidean system) into OPK angles (World system).

        :param x: x coordinate of the point
        :param y: y coordinate of the point
        :param q: quaternion

        :return: OPK angles
        """

        mat_eucli = self.quaternion_to_mat_eucli(q)
        mat = self.mat_eucli_to_mat(x, y, mat_eucli)
        opk = self.mat_to_opk(mat)
        return opk

    def opk_to_quaternion(self, x: float, y: float, opk: Union[List[float], np.array]) -> np.array:
        """
        Transform the OPK angles (World system) into quaternions (euclidean system).

        :param x: x coordinate of the point
        :param y: y coordinate of the point
        :param opk: opk angle

        :return: quaternion
        """
        mat = self.opk_to_mat(opk)
        mat_eucli = self.mat_to_mat_eucli(x, y, mat)
        q = self.mat_eucli_to_quaternion(mat_eucli)
        return q

    def world_to_euclidean(self, x: Union[float, List[float], np.array], y: Union[float, List[float], np.array],
                           z: Union[float, List[float], np.array]) \
            -> Tuple[Union[np.asarray, List[float], float], Union[np.asarray, List[float], float], Union[np.asarray, List[float], float]]:
        """
        Transform a point from the world coordinate reference system into the Euclidean coordinate reference system

        :param x: x coordinate of the point
        :param y: y coordinate of the point
        :param z: z coordinate of the point

        :return: x, y, z in the Euclidean coordinate reference system
        """
        x_geoc, y_geoc, z_geoc = self.proj_engine.carto_to_geoc(np.array(x), np.array(y), np.array(z))
        x_central_geoc, y_central_geoc, z_central_geoc = self.proj_engine.carto_to_geoc(self.x_central, self.y_central,
                                                                                        self.z_central)
        dr = np.vstack([x_geoc-x_central_geoc, y_geoc-y_central_geoc, z_geoc-z_central_geoc])
        point_eucli = (self.rot_to_euclidean_local @ dr) + \
                      np.array([self.x_central, self.y_central, self.z_central]).reshape(-1, 1)
        return np.squeeze(point_eucli[0]), np.squeeze(point_eucli[1]), np.squeeze(point_eucli[2])

    def euclidean_to_world(self, x_eucli: Union[float, List[float], np.array],
                           y_eucli: Union[float, List[float], np.array],
                           z_eucli: Union[float, List[float], np.array]) \
        -> Tuple[Union[np.asarray, List[float], float], Union[np.asarray, List[float], float], Union[np.asarray, List[float], float]]:
        """
        Transform a point from the Euclidean coordinate reference system into the world coordinate reference system.

        :param x_eucli: x coordinate of the point
        :param y_eucli: y coordinate of the point
        :param z_eucli: y coordinate of the point

        :return: x, y, z in the world coordinate reference system
        """
        x_eucli, y_eucli, z_eucli = np.array(x_eucli), np.array(y_eucli), np.array(z_eucli)
        x_central_geoc, y_central_geoc, z_central_geoc = self.proj_engine.carto_to_geoc(np.array([self.x_central]),
                                                                                        np.array([self.y_central]),
                                                                                        np.array([self.z_central]))

        dr = np.vstack([x_eucli - self.x_central, y_eucli - self.y_central, z_eucli - self.z_central])
        point_geoc = (self.rot_to_euclidean_local.T @ dr) + \
                     np.array([x_central_geoc, y_central_geoc, z_central_geoc]).reshape(-1, 1)
        return self.proj_engine.geoc_to_carto(point_geoc[0], point_geoc[1], point_geoc[2])

if __name__ == "__main__":
    from pysocle.geodesy.proj_engine import ProjEngine
    s = EuclideanTopaero(554879.204, 6924210.113, ProjEngine())
    s.quaternion_to_mat_eucli([0,0,0,1])